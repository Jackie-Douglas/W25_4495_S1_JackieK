Rails.application.config.session_store :cookie_store, :key => '_planted_meals_session', :domain => "all", tld_length: 2
