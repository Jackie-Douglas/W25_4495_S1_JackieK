require 'rufus-scheduler'

scheduler = Rufus::Scheduler.new

# scheduler.every '3s' do
#   puts 'Hello... Rufus'
# end


# require 'rufus-scheduler'

# Rufus::Scheduler.singleton.cron '00 12 L * * America/Vancouver' do
#   if ENV["DYNO"]&.include?("worker")
#     SubscriptionWorker.new.perform
#   end
# end

# Rufus::Scheduler.singleton.cron '0 12 * * 1-5 America/Vancouver' do
#   if ENV["DYNO"]&.include?("worker")
#     SystemLog.create(log: "running refus scheduler for upload pad and upload dd")
#     UploadPadWorker.new.perform
#     UploadDdWorker.new.perform
#   end
# end




# Every Saturday

# Rufus::Scheduler.singleton.cron '00 16 L * 6 America/Vancouver' do
#   if ENV["DYNO"]&.include?("worker")
#     SubscriptionWorker.new.perform
#   end
# end

Rufus::Scheduler.singleton.cron '32 17 L * 6 America/Vancouver' do
#   if ENV["DYNO"]&.include?("worker")
#     SubscriptionWorker.new.perform
#   end
puts "hello this is from rufus"
puts "#{DateTime.now}"

AutomationMailer.send_menu_recommendation.deliver_now

end


# Every Monday
# SendEmailWorker.new.send_weekly_menu


# Every Wednesday
# SendEmailWorker.new.send_weekly_menu
