Rails.application.routes.draw do
  
  require 'sidekiq/web'

  authenticate :user, lambda { |u| u.is_admin } do
    mount Sidekiq::Web => '/sidekiq'
  end
  
  ################### subdomain routes #####################

        # namespace :api, default: { format: :json } do
        #   namespace :v1 do
        #     post "webhook" => "stripe#webhook"
        #   end
        # end

      constraints subdomain: 'delivery' do
        resources :bag_trackers
        resources :vendor_deliveries
        patch 'toggle_checked/:id' => "vendor_deliveries#toggle_checked", as: :toggle_checked
      end

      constraints subdomain: 'offer' do
        resources :fair_offers
      end

      constraints subdomain: 'inventory' do
        resources :ingredients
        resources :ingredient_categories
        resources :ingredient_groups
        get "download_inventory_csv" => "ingredients#download_inventory_csv"
        get "/all_ingredient_lists" => "ingredients#all_ingredient_lists_index"
        get "/reset_ingredient" => "ingredients#reset_ingredient"
        get "/toggle_flag" => "ingredients#toggle_flag"
        get "/all_ingredients" => "ingredients#all_ingredients"
      end

      constraints subdomain: 'shop' do
        resources :products
        resources :orders
        resources :customers
        resources :stripes
        resources :one_time_purchases
        get 'choose_plan' => "products#choose_plan"
        get 'delivery' => "products#delivery"
        get 'review_checkout' => "products#review_checkout"
        get 'checkout' => "products#checkout"
        get 'validate_coupon' => "products#validate_coupon"
        get 'check_coupon' => "products#check_coupon"

        get '/new_referral' => "referrals#new_referral"
        post '/create_customer_from_referral' => "referrals#create_customer_from_referral"
        resources :thank_you, only: :index
        resources :gift_cards

        resources :gift_cards, only: [] do 
          post :charge_gift_card_payment, on: :collection, as: :card_payment
        end

        resources :menus, only: [:index]

        # post 'create_customer_from_one_time_purchase', action: :create_customer_from_one_time_purchase, controller: 'customers'
        
      end

      constraints subdomain: "portal" do
        devise_for :users, :controllers => { :registrations => :registrations }

        resources :users, only: [:index, :create] do
          post :impersonate, on: :member
          post :stop_impersonating, on: :collection
          post :custom_user_create, on: :collection
          post :resend_user_confirmation_email, on: :collection
        end

        resources :users, only: [] do
          resources :wallets
        end
        resources :member_weekly_menus
        resources :member_gift_cards
        resources :customer_dashboards
        resources :vendor_dashboards
        resources :manager_dashboards
        get "/vendor_review_order" => "vendor_dashboards#review_order"
        get "/vendor_order_history" => "vendor_dashboards#vendor_order_history"
        get "/vendor_confirm_order" => "vendor_dashboards#confirm_order"

        resources :dashboards, only: :index
        resources :tv_dashboards, only: :index
        resources :tv_prep_status_dashboards, only: :index
        resources :sms_messages
        resources :customers do
          resources :allergies
        end

        get '/plating_allergies' => "plating_guides#allergie_index_for_plating"

        resources :products
        get 'send_sms' => "sms_messages#twilio_send_sms"
        get 'member_review_checkout' => "member_weekly_menus#review_checkout"

        resources :orders, only: [:index, :show]
          
        resources :foods do
          resources :recipes
          resources :plating_guides
          resources :allergies, only: [:index]
        end

        resources :plating_guides, only: [:index, :show] do
          resources :plating_stats
        end

        post "add_bag_counter" => "plating_stats#add_bag_counter"
        post "subtract_bag_counter" => "plating_stats#subtract_bag_counter"

        resources :plating_components do
          resources :recipe_ingredients
          resources :ingredient_informations
        end

        resources :recipes do
          resources :recipe_ingredients
          resources :recipe_instructions
        end

        resources :recipe_ingredients

        resources :prep_tasks

        resources :employee_prep_tasks

        namespace :weekly_menus do
          get "create_menu_email_template"
        end

        resources :weekly_menus
        
        resources :coupons
        resources :customer_orders
        root to: 'welcome#index'
        resources :settings
        get "/delivery_edit" => "settings#delivery_edit"
        patch "/delivery_update" => "settings#delivery_update"
        get "/billing_edit" => "settings#billing_edit"
        patch "/billing_update" => "settings#billing_update"
        post "import_csv" => "orders#import_csv"
        get "/customer/:id/edit" => "users#customer_edit", as: "customer_edit"
        patch "/customer/:id" => "users#customer_update", as: "update"
        delete "/delete_customer/:id" => "users#customer_delete", as: "customer_delete"

        resources :admin_orders
        resources :admin_customers
        resources :employees

        resources :employees, only: [] do
          resources :employee_prep_tasks
        end

        resources :wage_informations, only: [:index]

        resources :employees, only: [] do
          resources :wage_informations
        end

        resources :work_schedules


        resources :temp_orders do
          get :invoice_status
        end
        resources :vendors do
          post :vendor_user, on: :collection, as: :create_user_for_vendor
        end

        resources :vendors, only: [] do
          resources :temp_orders
        end

        resources :em_vendors 

        resources :em_vendors, only: [] do
          resources :temp_orders
        end

        resources :invoices
        get "/create_charge" => "member_weekly_menus#create_charge"
        resources :employees, only: [] do
          resources :work_hours
          get '/admin_work_hours/new' => "work_hours#admin_work_hour_new"
          get "/admin_work_hours/:id/edit/" => "work_hours#admin_work_hour_edit", as: "admin_work_hour_edit"
          get '/clock_lunch_break' => "work_hours#clock_lunch_break"
          get '/employee_work_hour_log' => "work_hours#employee_work_hour_log"
        end

        resources :work_hours, only: [:index]

        get "/employees_index" => "work_hours#employees_index"

        resources :users, only: [] do
          resources :referrals
        end

        resources :referrals
        get 'member_validate_coupon' => "member_weekly_menus#validate_coupon"
        post 'member_apply_credit' => "member_weekly_menus#apply_credit"
        post 'member_apply_gift_card_credit' => "member_weekly_menus#apply_gift_card_credit"
        get 'charge_member' => "member_weekly_menus#charge_member"
        get 'update_credit_card_info' => "settings#update_credit_card_info"
        
        resources :analytics
        get '/coupon_usage' => "analytics#coupon_usage"
        get '/generate_pdf' => "vendors#generate_pdf"
        get '/generate_em_invoice_pdf' => "em_vendors#generate_em_invoice_pdf"
        get 'get_processed_dataset', to: 'users#get_processed_dataset'
        get 'invoice_index' => "invoices#invoice_index"

        resources :weekly_menus, only: [] do
          resources :food_items
          get "/vendor_order_list" => "weekly_menus#vendor_order_list"
        end

        resources :emails do
         get '/send_email' => "emails#send_email"
        end

        resources :driver_deliveries

        get '/all_drivers' => "driver_deliveries#driver_index"
        get '/vendor_drivers' => "driver_deliveries#vendor_driver_index"
        get '/vendor_driver/:id' => "driver_deliveries#vendor_driver_show", as: "vendor_driver_show"
        
        get '/assign_driver' => "driver_deliveries#assign_driver"
        get '/remove_driver' => "driver_deliveries#remove_driver"

        get '/assign_vendor_driver' => "driver_deliveries#assign_vendor_driver"
        get '/remove_vendor_driver' => "driver_deliveries#remove_vendor_driver"

        get '/download_delivery_csv' => "driver_deliveries#download_csv"
        get '/import_delivery_ids' => "driver_deliveries#import_delivery_id_from_last_week"
        get '/import_from_cigo' => "driver_deliveries#import_from_cigo"

        resources :pdfs
        get '/print_sun' => 'pdfs#print_sun'
        resources :plans
        resources :labour_targets
        resources :admin_bag_trackers
        resources :food_groups
        resources :subscription_prices
        resources :admin_referrals
        resources :admin_gift_cards
        resources :eating_instructions
        resources :food_categories
        resources :notices
        resources :monthly_reports
        resources :ingredient_categories
        resources :ingredients
        resources :shopping_lists
        resources :vendor_ingredient_orders
        resources :food_reviews
        resources :foods, only: [] do
          resources :food_reviews
        end

        resources :admin_food_reviews

        
        get "/weekly_food_review" => "food_reviews#weekly_food_review"
        get "/admin_gift_cards_resend" => "admin_gift_cards#resend_email"
        get "/update_special_order" => "admin_orders#update_special_order"
        get '/send_schedule_text' => "work_schedules#send_text"
        get '/show_employee_work_schedules' => "work_schedules#show_employee_work_schedules"
        get "/choose_employee" => "prep_handlers#choose_employee"
        get "/show_assigned_prep_tasks" => "prep_handlers#assigned_prep_task", as: :show_assigned_prep_tasks
        get "/all_assigned_prep_tasks" => "prep_handlers#all_assigned_prep_tasks", as: :all_assigned_prep_tasks
        get "/prep_task_toggle_status/:id" => "prep_handlers#prep_task_toggle_status", as: :prep_task_toggle_status
        get "/task_prioritize_toggle/:id" => "prep_handlers#task_prioritize_toggle", as: :task_prioritize_toggle
        get "/other_task_prioritize_toggle/:id" => "prep_handlers#other_task_prioritize_toggle", as: :other_task_prioritize_toggle
        get "/reset_prep_task/:id" => "prep_handlers#reset_prep_task", as: :reset_prep_task
        get "/menu" => "menu#index"
      end

  ##########################################################

  get 'test' => "welcome#delivery_test"
  post 'tracking' => "welcome#tracking"
end
