class AddStationFieldToRecipeIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :recipe_ingredients, :veggie_station, :boolean, default: false
    add_column :recipe_ingredients, :cook_station, :boolean, default: false
    add_column :recipe_ingredients, :sauce_station, :boolean, default: false
  end
end
