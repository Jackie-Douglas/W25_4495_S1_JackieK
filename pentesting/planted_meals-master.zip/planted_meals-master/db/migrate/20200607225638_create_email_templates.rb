class CreateEmailTemplates < ActiveRecord::Migration[5.2]
  def change
    create_table :email_templates do |t|
      t.text :html_code
      t.boolean :sent
      t.string :email_type

      t.timestamps
    end
    add_reference :email_templates, :weekly_menu, foreign_key: true
  end
end
