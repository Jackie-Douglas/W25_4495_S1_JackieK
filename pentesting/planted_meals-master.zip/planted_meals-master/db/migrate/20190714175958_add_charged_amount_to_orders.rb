class AddChargedAmountToOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :charged_amount, :decimal
  end
end
