class CreateTransactions < ActiveRecord::Migration[5.1]
  def change
    create_table :transactions do |t|
      t.string :charge_id
      t.integer :amount
      t.string :failure_code
      t.string :failure_message
      t.boolean :livemode
      t.integer :transaction_created_at

      t.timestamps
    end
  end
end
