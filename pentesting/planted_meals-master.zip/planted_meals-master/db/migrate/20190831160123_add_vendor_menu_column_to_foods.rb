class AddVendorMenuColumnToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :vendor_menu, :boolean, default: false
  end
end
