class AddGlutenWiseOptionColumnToLineItems < ActiveRecord::Migration[5.2]
  def change
    add_column :line_items, :gluten_wise_option, :boolean
  end
end
