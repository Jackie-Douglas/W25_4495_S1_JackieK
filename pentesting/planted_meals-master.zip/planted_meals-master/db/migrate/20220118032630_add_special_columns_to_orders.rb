class AddSpecialColumnsToOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :special, :boolean, default: false
  end
end
