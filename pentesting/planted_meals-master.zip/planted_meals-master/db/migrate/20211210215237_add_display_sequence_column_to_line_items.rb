class AddDisplaySequenceColumnToLineItems < ActiveRecord::Migration[5.2]
  def change
    add_column :line_items, :display_sequence, :integer
  end
end
