class AddInvoiceNumberToTempOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :temp_orders, :invoice_number, :string
  end
end
