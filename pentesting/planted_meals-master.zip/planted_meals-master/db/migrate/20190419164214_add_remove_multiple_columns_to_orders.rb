class AddRemoveMultipleColumnsToOrders < ActiveRecord::Migration[5.2]
  def change
    remove_column :orders, :product_id, :integer
    remove_column :orders, :cookie_type, :string
    rename_column :orders, :cookie, :single_cookie
    add_column    :orders, :bundle_cookie, :integer, default: 0 
    add_column    :orders, :ricotta, :integer, default: 0
  end
end
