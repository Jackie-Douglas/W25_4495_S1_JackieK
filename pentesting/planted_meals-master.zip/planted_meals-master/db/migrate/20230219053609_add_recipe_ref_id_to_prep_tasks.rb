class AddRecipeRefIdToPrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :prep_tasks, :recipe_ref_id, :bigint
  end
end
