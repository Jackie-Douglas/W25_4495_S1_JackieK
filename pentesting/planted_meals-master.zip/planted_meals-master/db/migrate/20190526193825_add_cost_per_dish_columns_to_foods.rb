class AddCostPerDishColumnsToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :cost_per_dish, :decimal
  end
end
