class CreateFoodItems < ActiveRecord::Migration[5.2]
  def change
    create_table :food_items do |t|

      t.timestamps
    end
    add_reference :food_items, :weekly_menu, foreign_key: true
    add_reference :food_items, :food, foreign_key: true
  end
end
