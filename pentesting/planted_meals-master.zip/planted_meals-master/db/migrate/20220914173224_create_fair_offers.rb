class CreateFairOffers < ActiveRecord::Migration[5.2]
  def change
    create_table :fair_offers do |t|
      t.string :email
      t.string :fair_name
      t.string :coupon_code

      t.timestamps
    end
  end
end
