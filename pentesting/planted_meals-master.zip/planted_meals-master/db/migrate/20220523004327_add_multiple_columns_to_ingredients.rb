class AddMultipleColumnsToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :unit, :string
    add_column :ingredients, :base_qty, :decimal
    add_column :ingredients, :on_hand, :decimal
    add_column :ingredients, :total_on_hand, :decimal
  end
end
