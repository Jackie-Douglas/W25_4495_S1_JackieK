class CreateSmsMessages < ActiveRecord::Migration[5.1]
  def change
    create_table :sms_messages do |t|
      t.text :message
      t.timestamps
    end
  end
end
