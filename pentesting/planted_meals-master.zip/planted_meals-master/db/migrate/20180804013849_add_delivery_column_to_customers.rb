class AddDeliveryColumnToCustomers < ActiveRecord::Migration[5.1]
  def change
    add_column :customers, :delivery, :string
  end
end
