class AddSalePriceToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :sale_price, :decimal
  end
end
