class AddEatingInstructionsColumnToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :eating_instructions, :text
  end
end
