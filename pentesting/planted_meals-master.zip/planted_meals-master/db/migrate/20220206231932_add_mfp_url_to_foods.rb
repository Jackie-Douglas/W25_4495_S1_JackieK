class AddMfpUrlToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :mfp_url, :string
  end
end
