class CreatePlatingComponents < ActiveRecord::Migration[5.2]
  def change
    create_table :plating_components do |t|
      t.string :name
      t.string :tool
      t.decimal :portion
      t.string :ingredient_type
      t.references :plating_guide, foreign_key: true

      t.timestamps
    end
  end
end
