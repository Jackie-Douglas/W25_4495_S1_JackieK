class CreatePlatingStats < ActiveRecord::Migration[5.2]
  def change
    create_table :plating_stats do |t|
      t.bigint :weekly_menu_id
      t.bigint :food_item_id
      t.datetime :start_time
      t.datetime :end_time
      t.references :plating_guide, foreign_key: true

      t.timestamps
    end
  end
end
