class AddOrderReferenceIdToCouponUsages < ActiveRecord::Migration[5.2]
  def change
    add_column :coupon_usages, :order_ref_id, :integer
  end
end
