class CreateEatingInstructions < ActiveRecord::Migration[5.2]
  def change
    create_table :eating_instructions do |t|
      t.text :instructions

      t.timestamps
    end
  end
end
