class AddIsPackAndPackBaseQtyToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :is_pack, :boolean
    add_column :ingredients, :pack_base_qty, :decimal
  end
end
