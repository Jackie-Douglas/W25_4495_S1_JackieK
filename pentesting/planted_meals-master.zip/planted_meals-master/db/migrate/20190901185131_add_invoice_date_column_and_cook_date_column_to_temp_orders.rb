class AddInvoiceDateColumnAndCookDateColumnToTempOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :temp_orders, :invoice_date, :date
    add_column :temp_orders, :cook_on, :date
  end
end
