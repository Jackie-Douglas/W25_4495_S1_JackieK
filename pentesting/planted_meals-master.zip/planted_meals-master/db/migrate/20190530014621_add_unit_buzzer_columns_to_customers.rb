class AddUnitBuzzerColumnsToCustomers < ActiveRecord::Migration[5.2]
  def change
    add_column :customers, :unit, :string
    add_column :customers, :buzzer, :string
  end
end
