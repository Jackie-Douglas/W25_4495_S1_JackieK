class CreateTempOrders < ActiveRecord::Migration[5.2]
  def change
    create_table :temp_orders do |t|
      t.integer :order_number
      t.datetime :order_date
      t.decimal :subtotal, default: 0.0
      t.bigint :customer_id
      t.integer :total_meal_count, default: 0
      t.text :comment
      t.boolean :purchased, default: false
      t.string :purchase_type
      t.bigint :weekly_menu_id
      t.decimal :charged_amount
      t.string :po_number

      t.timestamps
    end
    add_reference :line_items, :temp_order, foreign_key: true
  end
end



      
    
