class AddUuidToEmployees < ActiveRecord::Migration[5.2]
  def change
    add_column :employees, :uuid, :string
  end
end
