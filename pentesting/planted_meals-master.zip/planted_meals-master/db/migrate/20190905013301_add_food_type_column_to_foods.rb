class AddFoodTypeColumnToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :food_type, :string
  end
end
