class CreateTrackers < ActiveRecord::Migration[5.2]
  def change
    create_table :trackers do |t|
      t.string :action
      t.integer :count, default: 0

      t.timestamps
    end
  end
end
