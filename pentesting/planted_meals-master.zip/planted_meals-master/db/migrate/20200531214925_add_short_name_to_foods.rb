class AddShortNameToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :short_name, :string
  end
end
