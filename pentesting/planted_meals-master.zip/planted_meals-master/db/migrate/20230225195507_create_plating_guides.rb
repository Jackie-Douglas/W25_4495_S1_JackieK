class CreatePlatingGuides < ActiveRecord::Migration[5.2]
  def change
    create_table :plating_guides do |t|
      t.references :food, foreign_key: true

      t.timestamps
    end
  end
end
