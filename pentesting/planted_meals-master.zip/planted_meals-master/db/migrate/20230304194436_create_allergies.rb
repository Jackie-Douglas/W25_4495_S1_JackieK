class CreateAllergies < ActiveRecord::Migration[5.2]
  def change
    create_table :allergies do |t|
      t.belongs_to :food, index: true, foreign_key: true
      t.belongs_to :customer, index: true, foreign_key: true
      
      t.timestamps
    end
  end
end
