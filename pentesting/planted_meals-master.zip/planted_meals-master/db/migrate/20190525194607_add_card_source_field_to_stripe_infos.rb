class AddCardSourceFieldToStripeInfos < ActiveRecord::Migration[5.2]
  def change
    add_column :stripe_infos, :default_source, :string
    remove_column :stripe_infos, :email, :string
    remove_column :stripe_infos, :first_name, :string
    remove_column :stripe_infos, :last_name, :string
    remove_column :stripe_infos, :description, :string
    remove_column :stripe_infos, :subscribed, :boolean
  end
end
