class AddUnitColumnsToFoodsAndLineItems < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :unit, :integer, default: 1
    add_column :line_items, :unit, :integer, default: 1
  end
end
