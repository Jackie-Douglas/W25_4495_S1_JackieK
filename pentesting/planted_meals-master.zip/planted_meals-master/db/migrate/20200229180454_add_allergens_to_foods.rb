class AddAllergensToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :allergens, :string
  end
end
