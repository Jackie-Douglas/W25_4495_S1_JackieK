class AddPurchaseTypeFieldToOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :purchase_type, :string
  end
end
