class AddUserReferenceToGiftCards < ActiveRecord::Migration[5.2]
  def change
    add_reference :gift_cards, :user, foreign_key: true
    add_column :gift_cards, :uuid, :string
  end
end
