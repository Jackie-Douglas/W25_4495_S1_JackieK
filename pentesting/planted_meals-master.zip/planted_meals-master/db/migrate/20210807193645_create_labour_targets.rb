class CreateLabourTargets < ActiveRecord::Migration[5.2]
  def change
    create_table :labour_targets do |t|
      t.text :description
      t.references :weekly_menu, foreign_key: true

      t.timestamps
    end
  end
end
