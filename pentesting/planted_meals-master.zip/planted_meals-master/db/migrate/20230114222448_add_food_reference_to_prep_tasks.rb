class AddFoodReferenceToPrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_reference :prep_tasks, :food, foreign_key: true
  end
end
