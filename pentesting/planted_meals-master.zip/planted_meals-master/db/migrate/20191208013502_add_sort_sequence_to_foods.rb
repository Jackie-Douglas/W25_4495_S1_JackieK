class AddSortSequenceToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :sort_sequence, :integer
  end
end
