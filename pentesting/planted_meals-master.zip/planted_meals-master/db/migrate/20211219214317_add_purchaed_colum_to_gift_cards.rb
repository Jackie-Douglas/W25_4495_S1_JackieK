class AddPurchaedColumToGiftCards < ActiveRecord::Migration[5.2]
  def change
    add_column :gift_cards, :purchased, :boolean
  end
end
