class AddEmployeeReferenceAndAddPositionColumnsToTempOrders < ActiveRecord::Migration[5.2]
  def change
    add_reference :temp_orders, :employee, foreign_key: true
    add_column :temp_orders, :position, :integer
  end
end
