class AddEatingOrderColumnToFoodItems < ActiveRecord::Migration[5.2]
  def change
    add_column :food_items, :eating_order, :integer
  end
end
