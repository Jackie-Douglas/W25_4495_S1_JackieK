class AddPurchasedColumnToCouponUsages < ActiveRecord::Migration[5.2]
  def change
    add_column :coupon_usages, :purchased, :boolean
  end
end
