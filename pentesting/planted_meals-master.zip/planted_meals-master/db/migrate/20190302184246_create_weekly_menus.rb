class CreateWeeklyMenus < ActiveRecord::Migration[5.2]
  def change
    create_table :weekly_menus do |t|
      t.integer :mon
      t.integer :tue
      t.integer :wed
      t.integer :thu
      t.integer :fri
      t.date :week_start
      t.date :week_end
      
      t.timestamps
    end
  end
end
