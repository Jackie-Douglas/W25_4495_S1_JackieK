class ChangeMultipleGiftcardColumns < ActiveRecord::Migration[5.2]
  def change
    rename_column :gift_cards, :to_name , :to_first_name
    rename_column :gift_cards, :from_name , :from_first_name

    add_column :gift_cards, :to_last_name, :string
    add_column :gift_cards, :from_last_name, :string
  end
end
