class CreateGiftCardTransactions < ActiveRecord::Migration[5.2]
  def change
    create_table :gift_card_transactions do |t|
      t.integer "order_ref_id"
      t.decimal "credit_amount"
      t.integer "customer_ref_id"

      t.timestamps
    end
  end
end