class AddShippingRelatedColumnsToCustomers < ActiveRecord::Migration[5.2]
  def change
    add_column :customers, :shipping_address, :string
    add_column :customers, :shipping_city, :string
    add_column :customers, :shipping_province, :string
    add_column :customers, :shipping_country, :string
    add_column :customers, :shipping_postal_code, :string
  end
end






