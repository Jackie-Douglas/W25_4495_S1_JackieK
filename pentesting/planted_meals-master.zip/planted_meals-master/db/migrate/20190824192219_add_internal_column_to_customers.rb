class AddInternalColumnToCustomers < ActiveRecord::Migration[5.2]
  def change
    add_column :customers, :internal, :boolean, default: false
  end
end
