class CreateAddOns < ActiveRecord::Migration[5.2]
  def change
    create_table :add_ons do |t|
      t.references :food, foreign_key: true
      t.references :recipe, foreign_key: true
      t.string :name
      t.decimal :price

      t.timestamps
    end
  end
end
