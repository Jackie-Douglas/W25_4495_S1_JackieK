class CreateReferralTransactions < ActiveRecord::Migration[5.2]
  def change
    create_table :referral_transactions do |t|
      t.integer :order_ref_id
      t.decimal :order_subtotal
      t.decimal :credit_amount
      t.string :transaction_type

      t.timestamps
    end
    add_reference :referral_transactions, :wallet, forgien_key: true
  end
end
