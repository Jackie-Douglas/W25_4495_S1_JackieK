class RemoveMultipleColumnsFromOrders < ActiveRecord::Migration[5.2]
    def change
     remove_column :orders, :mon
     remove_column :orders, :tue
     remove_column :orders, :wed
     remove_column :orders, :thu
     remove_column :orders, :fri
     remove_column :orders, :sat
     remove_column :orders, :sun
     remove_column :orders, :single_cookie
     remove_column :orders, :bundle_cookie
     remove_column :orders, :ricotta
     remove_column :orders, :brownie
     remove_column :orders, :cookie_dough
     remove_column :orders, :overnight_oats
  end
end
