class AddStatusToEmployeePrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :employee_prep_tasks, :status, :string
  end
end
