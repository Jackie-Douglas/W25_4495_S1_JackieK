class AddNoteFieldToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :note, :text
    add_column :ingredients, :is_flagged, :boolean, default: false
  end
end
