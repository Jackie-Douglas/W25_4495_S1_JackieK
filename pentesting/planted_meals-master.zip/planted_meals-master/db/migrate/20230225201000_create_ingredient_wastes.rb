class CreateIngredientWastes < ActiveRecord::Migration[5.2]
  def change
    create_table :ingredient_wastes do |t|
      t.references :plating_component, foreign_key: true
      t.decimal :extra
      t.bigint :weekly_menu_id
      t.bigint :food_id

      t.timestamps
    end
  end
end
