class CreatePlatingIngredients < ActiveRecord::Migration[5.2]
  def change
    create_table :plating_ingredients do |t|
      t.bigint :recipe_ingredient_id
      t.references :plating_component, foreign_key: true

      t.timestamps
    end
  end
end
