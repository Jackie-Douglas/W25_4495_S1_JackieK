class AddPositionToOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :position, :integer
  end
end
