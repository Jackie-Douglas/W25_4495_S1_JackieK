class CreateVendorIngredientOrders < ActiveRecord::Migration[5.2]
  def change
    create_table :vendor_ingredient_orders do |t|
      t.string :unit
      t.decimal :quantity
      t.bigint :weekly_menu_id
      t.date :order_date
      t.string :vendor_name
      t.references :ingredient, foreign_key: true

      t.timestamps
    end
  end
end
