class AddSectionFieldToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :section, :string
  end
end
