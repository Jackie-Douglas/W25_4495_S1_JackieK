class CreateWorkSchedules < ActiveRecord::Migration[5.2]
  def change
    create_table :work_schedules do |t|
      t.date :work_date
      t.datetime :work_start
      t.datetime :work_end
      t.decimal :total_hours
      t.text :note
      t.references :employee

      t.timestamps
    end
  end
end
