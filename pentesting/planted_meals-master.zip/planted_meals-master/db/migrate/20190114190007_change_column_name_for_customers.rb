class ChangeColumnNameForCustomers < ActiveRecord::Migration[5.2]
  def change
    rename_column :customers, :delivery, :delivery_to    
  end
end
