class AddMultipleColumnsToOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :mon, :integer
    add_column :orders, :tue, :integer
    add_column :orders, :wed, :integer
    add_column :orders, :thu, :integer
    add_column :orders, :fri, :integer
    add_column :orders, :sat, :integer
    add_column :orders, :sun, :integer
    add_column :orders, :total_meal_count, :integer
    add_column :orders, :container_type, :string
    add_column :orders, :comment, :text
    add_column :orders, :cookie, :integer
  end
end
