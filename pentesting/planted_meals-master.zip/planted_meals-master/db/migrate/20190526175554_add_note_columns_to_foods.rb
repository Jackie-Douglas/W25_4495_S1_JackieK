class AddNoteColumnsToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :note, :text
  end
end
