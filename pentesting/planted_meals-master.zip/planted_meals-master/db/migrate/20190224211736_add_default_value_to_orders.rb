class AddDefaultValueToOrders < ActiveRecord::Migration[5.2]
  def change
    change_column_default :orders, :mon, from: nil, to: 0
    change_column_default :orders, :tue, from: nil, to: 0
    change_column_default :orders, :wed, from: nil, to: 0
    change_column_default :orders, :thu, from: nil, to: 0
    change_column_default :orders, :fri, from: nil, to: 0
  end
end
