class CreatePrepTasks < ActiveRecord::Migration[5.2]
  def change
    create_table :prep_tasks do |t|
      t.string :name
      t.integer :status
      t.string :machine_required
      t.string :cut_method
      t.string :size
      t.string :station
      t.references :recipe_ingredient, foreign_key: true

      t.timestamps
    end
  end
end
