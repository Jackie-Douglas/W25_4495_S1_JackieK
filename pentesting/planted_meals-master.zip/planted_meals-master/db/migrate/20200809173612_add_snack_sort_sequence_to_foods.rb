class AddSnackSortSequenceToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :snack_sort_sequence, :integer
  end
end
