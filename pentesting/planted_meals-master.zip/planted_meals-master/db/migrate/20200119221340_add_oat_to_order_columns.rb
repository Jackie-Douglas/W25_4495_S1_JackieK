class AddOatToOrderColumns < ActiveRecord::Migration[5.2]
  def change
    add_column :orders, :overnight_oats, :integer, default:  0 
  end
end
