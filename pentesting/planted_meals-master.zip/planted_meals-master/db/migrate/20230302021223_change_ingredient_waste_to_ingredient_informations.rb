class ChangeIngredientWasteToIngredientInformations < ActiveRecord::Migration[5.2]
  def change
    rename_table :ingredient_wastes, :ingredient_informations
  end
end
