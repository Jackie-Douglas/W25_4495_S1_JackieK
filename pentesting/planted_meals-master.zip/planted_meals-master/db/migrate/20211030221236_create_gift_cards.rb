class CreateGiftCards < ActiveRecord::Migration[5.2]
  def change
    create_table :gift_cards do |t|
      t.string :to_name
      t.string :to_email
      t.string :to_phone
      t.text :message
      t.decimal :amount
      t.string :from_name
      t.string :from_email
      t.string :from_phone

      t.timestamps
    end
  end
  
end
