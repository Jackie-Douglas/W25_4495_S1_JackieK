class AddSubscriptionInfoAndStripeIdToCustomers < ActiveRecord::Migration[5.1]
  def change
    add_column :customers, :subscription_info, :string
    add_column :customers, :stripe_id, :string
  end
end
