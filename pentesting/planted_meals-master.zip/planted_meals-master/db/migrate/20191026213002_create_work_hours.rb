class CreateWorkHours < ActiveRecord::Migration[5.2]
  def change
    create_table :work_hours do |t|
      t.integer :start_hour
      t.integer :start_min
      t.string :start_am_or_pm
      t.integer :end_hour
      t.integer :end_min
      t.string :end_am_or_pm
      t.date :work_date

      t.timestamps
    end
    add_reference :work_hours, :employee, foreign_key: true
  end
end
