class CreateLineItems < ActiveRecord::Migration[5.2]
  def change
    create_table :line_items do |t|
      t.integer :quantity, default: 0
      t.string :name
      t.decimal :price, default: 0.0

      t.timestamps
    end
    add_reference :line_items, :food, foreign_key: true
  end
end



    
    
