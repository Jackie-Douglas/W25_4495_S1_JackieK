class AddDescriptionFieldToAllergies < ActiveRecord::Migration[5.2]
  def change
    add_column :allergies, :description, :text
  end
end
