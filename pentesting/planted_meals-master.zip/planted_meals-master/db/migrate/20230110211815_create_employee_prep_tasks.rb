class CreateEmployeePrepTasks < ActiveRecord::Migration[5.2]
  def change
    create_table :employee_prep_tasks do |t|
      t.datetime :start_time
      t.datetime :end_time
      t.decimal :precut_weight
      t.decimal :actual_weight
      t.decimal :need_weight
      t.references :prep_task, foreign_key: true
      t.references :employee, foreign_key: true

      t.timestamps
    end
  end
end
