class AddTemplateIdToEmailTemplates < ActiveRecord::Migration[5.2]
  def change
    add_column :email_templates, :temp_ref_id, :string
  end
end
