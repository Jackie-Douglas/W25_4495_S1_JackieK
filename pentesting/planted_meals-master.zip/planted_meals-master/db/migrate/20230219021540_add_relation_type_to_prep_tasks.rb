class AddRelationTypeToPrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :prep_tasks, :relation_type, :string
  end
end
