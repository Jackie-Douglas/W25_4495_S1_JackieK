class AddDeliveryNoteToCusotmers < ActiveRecord::Migration[5.2]
  def change
    add_column :customers, :delivery_note, :text
    add_column :customers, :food_note, :text
  end
end
