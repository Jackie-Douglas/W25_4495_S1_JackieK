class AddGlutenWiseColumnsToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :gluten_wise, :boolean, default: false
  end
end
