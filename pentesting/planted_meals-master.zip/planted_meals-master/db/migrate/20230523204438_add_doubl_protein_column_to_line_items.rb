class AddDoublProteinColumnToLineItems < ActiveRecord::Migration[5.2]
  def change
    add_column :line_items, :double_protein, :boolean, default: false
    add_column :line_items, :add_on_price, :decimal
  end
end
