class AddPrecutPercentageToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :precut_percentage, :integer
  end
end
