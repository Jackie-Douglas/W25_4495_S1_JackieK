class AddEmployeeCodeToWorkHours < ActiveRecord::Migration[5.2]
  def change
    add_column :work_hours, :employee_code, :integer
  end
end
