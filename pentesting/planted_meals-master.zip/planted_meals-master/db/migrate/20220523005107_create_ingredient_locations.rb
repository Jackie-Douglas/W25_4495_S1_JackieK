class CreateIngredientLocations < ActiveRecord::Migration[5.2]
  def change
    create_table :ingredient_locations do |t|
      t.string :location

      t.timestamps
    end
  end
end
