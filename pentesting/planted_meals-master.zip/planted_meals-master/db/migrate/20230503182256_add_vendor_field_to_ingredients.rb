class AddVendorFieldToIngredients < ActiveRecord::Migration[5.2]
  def change
    add_column :ingredients, :vendor, :string
    add_column :ingredients, :vendor_order_quantity, :string
  end
end
