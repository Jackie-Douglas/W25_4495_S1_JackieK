class ChangeFoodItemIdColumnToFoodIdToPlatingStats < ActiveRecord::Migration[5.2]
  def change
    rename_column :plating_stats, :food_item_id, :food_id
  end
end
