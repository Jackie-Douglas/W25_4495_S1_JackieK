class AddListRefIdToEmailTemplates < ActiveRecord::Migration[5.2]
  def change
    add_column :email_templates, :list_ref_id, :string
  end
end
