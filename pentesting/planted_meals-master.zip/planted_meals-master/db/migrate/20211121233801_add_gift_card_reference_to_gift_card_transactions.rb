class AddGiftCardReferenceToGiftCardTransactions < ActiveRecord::Migration[5.2]
  def change
    add_reference :gift_card_transactions, :gift_card, foreign_key: true
  end
end
