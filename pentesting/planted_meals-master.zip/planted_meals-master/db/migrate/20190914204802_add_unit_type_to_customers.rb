class AddUnitTypeToCustomers < ActiveRecord::Migration[5.2]
  def change
    add_column :customers, :unit_type, :string
  end
end
