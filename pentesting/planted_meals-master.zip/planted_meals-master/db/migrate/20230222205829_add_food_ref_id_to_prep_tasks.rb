class AddFoodRefIdToPrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :prep_tasks, :food_ref_id, :bigint
  end
end
