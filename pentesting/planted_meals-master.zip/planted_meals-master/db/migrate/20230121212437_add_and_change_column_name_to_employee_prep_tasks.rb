class AddAndChangeColumnNameToEmployeePrepTasks < ActiveRecord::Migration[5.2]
  def change
    rename_column :employee_prep_tasks, :start_time, :prep_start_time
    rename_column :employee_prep_tasks, :end_time, :prep_end_time

    add_column    :employee_prep_tasks, :process_start_time, :datetime
    add_column    :employee_prep_tasks, :process_end_time, :datetime
  end
end
