class AddAndRemoveColumnFromOrders < ActiveRecord::Migration[5.2]
  def change
    remove_column :orders, :container_type, :string
    add_column :orders, :cookie_type, :string
  end
end
