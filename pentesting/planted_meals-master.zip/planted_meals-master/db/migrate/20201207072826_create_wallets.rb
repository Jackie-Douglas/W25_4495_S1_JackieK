class CreateWallets < ActiveRecord::Migration[5.2]
  def change
    create_table :wallets do |t|
      t.decimal :credit_amount

      t.timestamps
    end
    add_reference :wallets, :user, forgien_key: true
  end
end
