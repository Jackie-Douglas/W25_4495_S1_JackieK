class AddRetailPriceWholesalePriceColumnsToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :retail_price, :decimal
    add_column :foods, :wholesale_price, :decimal
  end
end
