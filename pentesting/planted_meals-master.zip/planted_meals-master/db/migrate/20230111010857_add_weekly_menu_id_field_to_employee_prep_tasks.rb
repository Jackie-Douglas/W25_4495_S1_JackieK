class AddWeeklyMenuIdFieldToEmployeePrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :employee_prep_tasks, :weekly_menu_id, :bigint
    add_column :employee_prep_tasks, :prep_date, :date
  end
end
