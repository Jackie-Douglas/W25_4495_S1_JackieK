class AddDeliveryDayColumndToTempOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :temp_orders, :delivery_day, :string
  end
end
