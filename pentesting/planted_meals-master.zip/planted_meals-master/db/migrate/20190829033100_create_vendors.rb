class CreateVendors < ActiveRecord::Migration[5.2]
  def change
    create_table :vendors do |t|
      t.string "first_name"
      t.string "last_name"
      t.string "email"
      t.string "phone"
      t.string "address"
      t.string "city"
      t.string "province"
      t.string "country"
      t.string "postal_code"
      t.string "shipping_address"
      t.string "shipping_city"
      t.string "shipping_province"
      t.string "shipping_country"
      t.string "shipping_postal_code"
      t.string "company_name"

      t.timestamps
    end
    add_reference :temp_orders, :vendor, foreign_key: true
  end
end
