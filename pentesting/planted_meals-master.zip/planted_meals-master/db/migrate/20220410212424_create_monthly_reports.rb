class CreateMonthlyReports < ActiveRecord::Migration[5.2]
  def change
    create_table :monthly_reports do |t|
      t.date :report_date
      t.decimal :cogs
      t.decimal :labour
      t.decimal :food_cost
      t.string :oc_img
      t.string :cogs_img

      t.timestamps
    end
  end
end
