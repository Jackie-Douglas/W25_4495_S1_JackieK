class CreateBagTrackers < ActiveRecord::Migration[5.2]
  def change
    create_table :bag_trackers do |t|
      t.integer :counter, default: 0

      t.timestamps
    end
    add_reference :bag_trackers, :customer, foreign_key: true
  end
end
