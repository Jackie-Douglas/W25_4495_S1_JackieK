class AddAvailabilityColumnToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :availability, :boolean, default: true
  end
end
