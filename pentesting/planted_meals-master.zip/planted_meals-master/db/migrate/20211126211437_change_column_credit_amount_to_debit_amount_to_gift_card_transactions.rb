class ChangeColumnCreditAmountToDebitAmountToGiftCardTransactions < ActiveRecord::Migration[5.2]
  def change
    rename_column :gift_card_transactions, :credit_amount, :debit_amount
  end
end
