class AddSpicyLevelColumnToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :spicy_level, :integer
  end
end
