class CreateStripeInfos < ActiveRecord::Migration[5.2]
  def change
    create_table :stripe_infos do |t|
      t.string :email
      t.string :first_name
      t.string :last_name
      t.text   :description
      t.string :last_4
      t.string :credit_card_type
      t.string :stripe_customer_id
      t.boolean :subscribed
      t.string :subscription_id      

      t.timestamps
    end
    add_reference :stripe_infos, :customer, index: true
  end
end
