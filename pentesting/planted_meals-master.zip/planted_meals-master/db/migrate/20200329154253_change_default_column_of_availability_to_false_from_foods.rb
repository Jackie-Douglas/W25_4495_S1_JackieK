class ChangeDefaultColumnOfAvailabilityToFalseFromFoods < ActiveRecord::Migration[5.2]
  def change
    change_column :foods, :availability, :boolean, default: false
  end
end
