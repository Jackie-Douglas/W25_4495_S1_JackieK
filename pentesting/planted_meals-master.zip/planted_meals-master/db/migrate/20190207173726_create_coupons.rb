class CreateCoupons < ActiveRecord::Migration[5.2]
  def change
    create_table :coupons do |t|
      t.string :coupon_code
      t.integer :numbers_available
      t.date :start_date
      t.date :end_date
      t.string :discount_type
      t.decimal :discount_amount
      t.timestamps
    end
  end
end
