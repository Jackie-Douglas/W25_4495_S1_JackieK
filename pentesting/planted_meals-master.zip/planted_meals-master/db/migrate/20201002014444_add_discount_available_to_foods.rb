class AddDiscountAvailableToFoods < ActiveRecord::Migration[5.2]
  def change
    add_column :foods, :discount_available, :boolean, default: true
  end
end
