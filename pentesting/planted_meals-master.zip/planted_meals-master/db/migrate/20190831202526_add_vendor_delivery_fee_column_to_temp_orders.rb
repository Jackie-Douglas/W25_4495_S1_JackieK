class AddVendorDeliveryFeeColumnToTempOrders < ActiveRecord::Migration[5.2]
  def change
    add_column :temp_orders, :vendor_delivery_fee, :decimal
  end
end
