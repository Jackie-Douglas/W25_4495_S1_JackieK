class AddSpecialColumnToCoupons < ActiveRecord::Migration[5.2]
  def change
    add_column :coupons, :special, :boolean, default: false
  end
end
