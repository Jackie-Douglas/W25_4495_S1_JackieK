class AddMultipleColumnsToReferrals < ActiveRecord::Migration[5.2]
  def change
    add_column :referrals, :referral_type, :string
    add_column :referrals, :message, :text
  end
end
