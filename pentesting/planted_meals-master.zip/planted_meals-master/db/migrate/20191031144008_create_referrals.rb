class CreateReferrals < ActiveRecord::Migration[5.2]
  def change
    create_table :referrals do |t|
      t.string :event_name
      t.string :email
      t.boolean :redeemed, default: false
      t.string :uuid

      t.timestamps
    end
    add_reference :referrals, :user, foreign_key: true     
  end
end
