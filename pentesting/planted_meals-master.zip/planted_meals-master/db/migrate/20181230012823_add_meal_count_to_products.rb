class AddMealCountToProducts < ActiveRecord::Migration[5.2]
  def change
    add_column :products, :meal_count, :integer
    add_column :products, :plan_type, :string
  end
end
