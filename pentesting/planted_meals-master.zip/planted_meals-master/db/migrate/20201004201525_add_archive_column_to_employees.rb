class AddArchiveColumnToEmployees < ActiveRecord::Migration[5.2]
  def change
    add_column :employees, :archive, :boolean, default: false
  end
end
