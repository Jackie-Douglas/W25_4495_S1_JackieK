class AddWeeklyMenuReferenceToOrders < ActiveRecord::Migration[5.2]
  def change
    add_reference :orders, :weekly_menu, foreign_key: true
  end
end
