class AddConfirmedColumToWorkSchedules < ActiveRecord::Migration[5.2]
  def change
    add_column :work_schedules, :confirmed, :boolean, default: false
  end
end
