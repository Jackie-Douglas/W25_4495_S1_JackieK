class AddLabourTargetFieldToWeeklyMenus < ActiveRecord::Migration[5.2]
  def change
    add_column :weekly_menus, :labour_target_percentage, :integer
  end
end
