class AddIsPrioritizeFieldToEmployeePrepTasks < ActiveRecord::Migration[5.2]
  def change
    add_column :employee_prep_tasks, :is_prioritize, :boolean, default: false
  end
end
