require 'prawn/measurement_extensions'

class SnackStickerSheet 
    include ActiveSupport::NumberHelper
    include Prawn::View

    SNACKS_PER_COLUMN = 6

    def initialize(orders, vendor_orders)
        super()
        @orders = orders
        @vendor_orders = vendor_orders
        @menu = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i)
        @label_count = 0
        @brownie = 40
        @cookie = 39
        @bundle_cookie = 89
        @ricotta = 81
        @cookie_dough = 85
        @oats = 86
        @cookie_packs = 87
        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"
        snack_orders        
    end

    def document
      @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10)
    end

    def snack_orders
        data = []
        count = 0

        @orders.each do |a|
            snack_ids = Food.where(food_type: "dessert", availability: true) + Food.where(id: 141)
            quantity = a.line_items.where(food_id: snack_ids).sum(:quantity)
            snack_item = a.line_items

            next if quantity == 0
            customer = Customer.find(a.customer_id)
            data += [["#{customer.first_name} #{customer.last_name}", get_snack_quantity(snack_item, @brownie), 
                      (get_snack_quantity(snack_item, @cookie) + (get_snack_quantity(snack_item, @bundle_cookie) * 6)),   
                         get_snack_quantity(snack_item, @ricotta), get_snack_quantity(snack_item, @cookie_dough), get_snack_quantity(snack_item, @oats), ""]]

            count += 1
            bounding_box(next_label_position, height: (2.in), width: (4.in)) do
                bounding_box([4.mm, (2.in - 4.mm)], height: (2.in - 8.mm), width: (4.in - 8.mm)) do
                    text_box "#{count}. #{customer.first_name.upcase} #{customer.last_name.upcase}", style: :bold, size: 8
                    text_box "", align: :right, style: :bold, size: 8 # TODO change to "#{delivery_day.upcase[0..2]}-__________-___" when needed
                    move_down 9
                    # text [
                    # [customer.unit.presence, customer.shipping_address].compact.join('-'),
                    # customer.shipping_city,
                    # customer.buzzer ? "Buzzer: #{customer.buzzer}" : nil,
                    # customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone
                    # ].compact.join(', '), size: 8
                    

                    bounding_box([0, 2.in - 45], height: 25.mm, width: 40.mm) do
                        table(snacks_for_order(snack_item)[0..5], width: 4.cm) do
                            cells.borders = []
                            cells.padding = [1, 3, 1, 3]
                            cells.size = 8
                            cells.column(1).align = :right
                            cells.style do |cell|
                            cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                            # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                            # cell.font_style = :bold if cell.column == 0 && cell.row < row_length - 1
                            cell.font_style = :bold
                            end
                        end
                    end

                    bounding_box([43.mm, 2.in - 45], height: 25.mm, width: 38.mm) do
                        bounding_box([0, 25.mm], width: 20.mm) do
                            
                            table(snacks_for_order(snack_item)[6..-1], width: 40.mm) do
                                cells.borders = []
                                cells.padding = [1, 3, 1, 3]
                                cells.size = 8
                                cells.font_style = :bold
                                cells.column(1).align = :right
                                cells.height = 4.mm
                                cells.overflow = :shrink_to_fit
                                cells.style do |cell|
                                cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                            end
                        end if (snacks_for_order(snack_item)[6..-1] != nil) && (!snacks_for_order(snack_item)[6..-1].nil? ? !snacks_for_order(snack_item)[6..-1].empty? : true )
                            
                        end
                    end


                    #     bounding_box([22.mm, 25.mm], width: 20.mm) do
                    #         table([snacks_second_column(snack_item)], width: 20.mm) do
                    #         cells.borders = []
                    #         cells.padding = [1, 3, 1, 3]
                    #         cells.size = 8
                    #         cells.font_style = :bold
                    #         cells.column(1).align = :right
                    #         cells.height = 4.mm
                    #         cells.overflow = :shrink_to_fit
                    #         cells.style do |cell|
                    #             cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                    #         end
                    #         end if snacks_second_column(snack_item).any?
                    #     end
                    # end

                    # bounding_box([50.mm, 2.in - 45], height: 25.mm, width: 38.mm) do
                    #     bounding_box([0, 25.mm], width: 20.mm) do
                    #         table(snacks_first_column(snack), width: 20.mm) do
                    #         cells.borders = []
                    #         cells.padding = [1, 3, 1, 3]
                    #         cells.size = 8 #         cells.font_style = :bold
                    #         cells.column(1).align = :right
                    #         cells.height = 4.mm
                    #         cells.overflow = :shrink_to_fit
                    #         cells.style do |cell|
                    #             cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                    #         end
                    #     end if snacks_first_column(order).any?
                    # end



                end
            end
        end

        @vendor_orders.each do |a|
            
            snack_ids = Food.where(food_type: "dessert", availability: true) + Food.where(id: 141)
            quantity = a.line_items.where(food_id: snack_ids).sum(:quantity)
            snack_item = a.line_items
            vendor_name = a.vendor.company_name
            
            next if quantity == 0

            bounding_box(next_label_position, height: (2.in), width: (4.in)) do
                bounding_box([4.mm, (2.in - 4.mm)], height: (2.in - 8.mm), width: (4.in - 8.mm)) do
                    text_box "#{vendor_name.upcase}", style: :bold, size: 8
                    text_box "", align: :right, style: :bold, size: 8 # TODO change to "#{delivery_day.upcase[0..2]}-__________-___" when needed
                    move_down 9
                    # text [
                    # [customer.unit.presence, customer.shipping_address].compact.join('-'),
                    # customer.shipping_city,
                    # customer.buzzer ? "Buzzer: #{customer.buzzer}" : nil,
                    # customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone
                    # ].compact.join(', '), size: 8

                    snack_for_vendor_order_variable = snacks_for_vendor_order(snack_item).empty? ? [[0, 0]] : snacks_for_vendor_order(snack_item)

                    bounding_box([0, 2.in - 45], height: 25.mm, width: 40.mm) do
                    table(snack_for_vendor_order_variable, width: 4.cm) do
                        cells.borders = []
                        cells.padding = [1, 3, 1, 3]
                        cells.size = 8
                        cells.column(1).align = :right
                        cells.style do |cell|
                        cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                        # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                        # cell.font_style = :bold if cell.column == 0 && cell.row < row_length - 1
                        cell.font_style = :bold
                        end
                    end
                    end
                end
            end

            

        end

        brownies = calculate_snack_count(@brownie) + calculate_vendor_snack(@brownie)
        cookies = calculate_snack_count(@cookie) + (calculate_snack_count(@bundle_cookie) * 6 ) + calculate_vendor_snack(@cookie)
        ricotta = calculate_snack_count(@ricotta) + calculate_vendor_snack(@ricotta)
        cookie_dough = calculate_snack_count(@cookie_dough) + calculate_vendor_snack(@cookie_dough)
        overnight_oats = calculate_snack_count(@oats) + calculate_vendor_snack(@oats)
        cookie_pack = calculate_vendor_snack(@cookie_packs)


        # data += [["Total", brownies, cookies, ricotta, cookie_dough, overnight_oats, cookie_pack]]
        

        # table(data, header: true, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
        #     table.row(0).font_style = :bold
        #     table.cells.style do |c|
        #         c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
        #     end
        # end

        
     
    end

    private

    def calculate_snack_count(ref_id)
        LineItem.where(order_id: @orders.pluck(:id), food_id: ref_id).sum(:quantity)
    end

    def calculate_vendor_snack(ref_id)
        food_id = Food.find(ref_id)
        vendor_order_ids = @vendor_orders.ids
        items = LineItem.where(temp_order_id: vendor_order_ids, food_id: food_id).sum(:quantity)
    end

    # calculates cursor position for next label
    def next_label_position
        start_new_page if @label_count > 0 && (@label_count % 10).zero?
        label_x = @label_count.even? ? 0 : 4.in
        move_up 2.in if @label_count.odd?
        @label_count += 1
        [label_x, cursor]
    end

    def snacks_for_order(snack_items)
        snack_ids = Food.where.not(food_type: "meal").where(availability: true)
        snacks_for_order = snack_items.where(food_id: snack_ids)

        snacks_for_order = snacks_for_order.map do |x|
                                [Food.find(x.food_id).short_name, x.quantity]
                           end
        
        snacks_for_order.reject { |(_name, count)| count.zero? }
        .each_slice(SNACKS_PER_COLUMN)
        .to_a.flatten(1)
    end


    # TODO: will prawn make new columns automatically??
    def snacks_first_column(order)
        snacks_for_order(order)[0] || []
    end

    # TODO: will prawn make new columns automatically??
    def snacks_second_column(order)
        snacks_for_order(order)[1] || []
    end

    def foods_for_order(order)
        [
        [Food.find(@menu.mon).name, order.mon],
        [Food.find(@menu.tue).name, order.tue],
        [Food.find(@menu.wed).name, order.wed],
        [Food.find(@menu.thu).name, order.thu],
        [Food.find(@menu.fri).name, order.fri]
        ].reject { |(_name, count)| count.zero? }
        .push(['TOTAL MEALS', order.total_meal_count])
    end

    def snacks_for_vendor_order(line_items)
        line_items.select do |line_item|
        line_item&.quantity&.positive? && line_item&.food_type == 'dessert'
        end.map do |line_item|
        [line_item.short_name, line_item.quantity]
        end.each_slice(SNACKS_PER_COLUMN)
        .to_a.flatten(1)
    end

    def filtered_item_quantity(quantity)
        quantity == nil ? 0 : quantity
    end

    def get_snack_quantity(line_items, food_id)
        begin
            line_items.find_by(food_id: food_id).quantity
        rescue
            0
        end
    end


end



