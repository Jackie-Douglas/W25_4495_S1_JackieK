require 'prawn/measurement_extensions'
#   transparent(0.5) { stroke_bounds }
class SunPrintSheet < Prawn::Document
	include ActiveSupport::NumberHelper
	include Prawn::View

	def initialize(orders)
		# super(:page_layout => :landscape, :page_size => 'LEGAL')
		super(:page_size => 'LEGAL')
		@orders = orders
		@vendor_cook_date =  WeeklyMenu.find(orders.pluck(:weekly_menu_id).uniq.join).week_start - 1.day
		# @vendor_cook_date = WeeklyMenu.last(2).first.week_start - 1.day
		# @orders = WeeklyMenu.last(2).first.orders.where(purchased: true)
		self.font_families.update("OpenSans" => {
														:normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
														:italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
														:bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
														:bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
		})

		font "OpenSans"
		customers = Customer.where(id: @orders.pluck(:customer_id), delivery_to: ["pickup", "pick up"])
		assign_numbers(customers.ids, @orders)    

		print
	end

	def document
		conversion_pt = 28.34645669291339
		width_in_pt = 10.16 * conversion_pt
		height_in_pt = 15.24 * conversion_pt
		
		@my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10, :page_size => [width_in_pt, height_in_pt])
	end

	def print
		grouped_orders(@orders).each do |o|
			employee_id = o[0].first
			delivery_day = o[0].second
			driver_name = Employee.find(employee_id).customer.first_name if employee_id != nil
				
			if employee_id.blank?
					text "Pickup", size: 30, style: :bold
			else
					text "#{driver_name.titleize}/#{delivery_day.titleize} (#{o[1].length})", size: 30, style: :bold
			end
			move_down 20
				
			o[1].each do |order|
				table(create_cells(order), :column_widths => [30, 30, 100, 80, 200, 50]) do
					cells.borders = [:top, :bottom, :left, :right]
					# cells.borders = []
					cells.padding = [7, 6, 7, 6]
					cells.size = 10
					cells.column(1).align = :right
					cells.style do |cell|
						cell.borders = cell.column.zero? ? [:top, :bottom, :left, :right] : [] 
					#   cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
						# cell.background_color = 
						# cell.background_color = 'FFFFFF' if cell.row == row_length - 1
					#   cell.font_style = :bold if cell.column
					end
				end
				move_down 2
			end
				start_new_page
		end
	end

	private

	def grouped_orders(orders)
		vendor_order_data = TempOrder.where(cook_on: @vendor_cook_date).joins(:vendor).select("id", "vendor_id", "vendors.company_name", "delivery_day", 
																																													"vendors.shipping_postal_code", "vendors.company_name", "vendors.shipping_address", "employee_id", "position")
		

		order_data = orders.joins(:customer).select("id", "customer_id", "customers.first_name", "customers.last_name", "customers.delivery_to",
																								"customers.shipping_postal_code", "customers.company_name", "customers.shipping_address", "customers.unit", "customers.delivery_day", "employee_id", "position")

		
		order_data = order_data + vendor_order_data
		# order_data = order_data.order([:employee_id, :delivery_day, :position]).group_by {|x| [x.employee_id, x.delivery_day]}
		# order_data = order_data.sort_by {|x| [(x.employee_id.nil? ? 0 : x.employee_id), x.delivery_day, x.position] }.group_by {|x| [x.employee_id, x.delivery_day]}
		order_data = order_data.sort_by do |x| 
			employee_id = x.employee_id.nil? ?   0 : x.employee_id
			delivery_day = x.delivery_day.nil? ? 0 : x.delivery_day
			position     = x.position.nil? ?     0 : x.position
			
			[employee_id, delivery_day, position] 
		end.group_by {|x| [x.employee_id, x.delivery_day]}
	end 

	def create_cells(order)
		condition = order.model_name == "TempOrder" 

		position = order.position
		customer = condition ? order.vendor : order.customer   
		full_name = condition ? "#{customer.company_name}" : "#{customer.first_name} #{customer.last_name}"
		phone = number_to_phone(customer.phone)

		address = condition ? customer.shipping_address : (customer.delivery_to == "pick up" ? "#{customer.delivery_note}" : "#{customer.shipping_address}")

		[["", position, full_name, phone, address, "##{order.id}"]]
	end

	def assign_numbers(customers_ids, orders)
		orders = orders.where(customer_id: customers_ids)

		count = 0
		orders.each do |x|
			count = count += 1
			x.update_columns(position: count)
		end
	end
end


# order_data = orders.joins(:customer).select("id", "customer_id", "total_meal_count", "weekly_menu_id", "customers.first_name", "customers.last_name", "customers.delivery_to",
        #                                             "customers.shipping_postal_code", "customers.company_name", "customers.shipping_address", "customers.unit", "customers.delivery_day", "employee_id", "position")