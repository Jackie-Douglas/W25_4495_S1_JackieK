class FoodNoteSheet < Prawn::Document

	def initialize(orders)
		super(:page_layout => :landscape)
		@orders = orders
		self.font_families.update("OpenSans" => {
														:normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
														:italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
														:bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
														:bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
		})

		font "OpenSans"
		food_note_label        
	end

	def food_note_label
		food_ids = Food.where(availability: true).where(food_type: "meal").order(id: :asc).pluck(:id)
		food_items = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i).food_items.where(food_id: food_ids)
		foods = Food.where(id: food_items.pluck(:food_id))

		name_array = foods.map { |x| x.short_name }
		name_array = name_array.prepend("NAME", "FOOD NOTE")
			
		data = [name_array]

		@orders.each do |a|
			customer = Customer.find(a.customer_id)
			items = a.line_items
			next if customer.food_note.blank?
			
			header = ["#{customer.first_name} #{customer.last_name}", customer.food_note]

			food_note_data = foods.map do |x|
				food_item = a.line_items.find_by(food_id: x.id)
				food_item.nil? ? 0 : food_item.quantity
			end

			data += ([header + food_note_data])
		end

		table(data, header: true, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
			table.row(0).font_style = :bold
			table.cells.style do |c|
				c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
			end
		end
	end

	private 

	def titleize(record)
		record.name.titleize
	end

	def get_meal_quantity(line_items, food_id)
		begin
			line_items.find_by(food_id: food_id).quantity
		rescue
			0
		end
	end
end