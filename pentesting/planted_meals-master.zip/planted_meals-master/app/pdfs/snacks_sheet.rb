require 'prawn/measurement_extensions'

class SnacksSheet < Prawn::Document
    include ActiveSupport::NumberHelper
    include Prawn::View

    def initialize(orders)
        super(:page_size => 'LEGAL')
        @orders = orders
        # @orders = WeeklyMenu.last(2).first.orders.where(purchased: true)
        @label_count = 0
        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"
        snack_orders
    end

    # not needed if you are happy with Prawn's default document settings
    # def document
    #   @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10)
    # end

    def snack_orders
        this_week_snack_item_ids = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.first).food_items.pluck(:food_id)
        snacks = Food.where(availability: true, id: this_week_snack_item_ids).where.not(food_type: "meal") + Food.where(id: 141)
        snacks = snacks.sort { |a,b| a[:snack_sort_sequence] <=> b[:snack_sort_sequence] }

        name_array = snacks.map { |x| x.short_name }
        name_array = name_array.prepend("NAME")
        
        data = [name_array]

        
        grouped_orders(@orders).each do |o|
            employee_id = o[0].first
            delivery_day = o[0].second
            driver_name = Employee.find(employee_id).customer.first_name if employee_id != nil
            
            if employee_id.blank?
                text "Pickup", size: 20, style: :bold
            else
                text "#{driver_name}/#{delivery_day}", size: 20, style: :bold
            end

            move_down 20
            

            o[1].each do |order|

                snack_items = order.line_items.where(food_id: snacks)
                quantity = snack_items.sum(:quantity)

                 next if quantity == 0

                data = [[],[]]

                snack_items.order(food_id: "ASC").each do |item|
                    next if item.quantity == 0
                    data[0] << Food.find(item.food_id).short_name
                    data[1] << item.quantity
                end


                data[0].prepend("Name") 
                data[1].prepend(order.customer.first_name) 
                data[0].prepend("Position") 
                data[1].prepend(order.position) 
                data[0].prepend("Driver/Day") 

                if order.customer.delivery_to == "pick up"
                    data[1].prepend("Pickup") 
                else
                    data[1].prepend("#{driver_name}/#{order.customer.delivery_day[0..2]}") 
                end

                data[0].prepend("Order #") 
                data[1].prepend(order.id) 

                table(data, header: 1000, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 70}) do |table|
                    table.row(0).font_style = :bold
                    table.cells.style do |c|
                        c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
                    end
                end
                move_down 10

            end

             start_new_page

             
        
    end

        total_data = snacks.map do |x|
            food_item = x.line_items.find_by(food_id: x.id)
            
            if food_item
                [x.short_name ,calculate_snack_count(x.id) ]
                # + calculate_vendor_snack(x.id)
            else
                0
            end
        end
        sorted_total_data = total_data.sort { |a,b| a[0] <=> b[0] }

        sorted_total_data.each do |x|
            text "#{x[0].titleize}: #{x[1]}"
            move_down 1

        end
     
    end

    private

    def get_snack_quantity(line_item, food_id)
        begin
            line_item = line_item.find_by(food_id: food_id)
            line_item.quantity == 0 ? "" : line_item.quantity
        rescue
            ""
        end
    end

    def calculate_snack_count(ref_id)
        LineItem.where(order_id: @orders.pluck(:id), food_id: ref_id).sum(:quantity)
    end

    def calculate_vendor_snack(ref_id)
        food_id = Food.find(ref_id)
        vendor_order_ids = @vendor_orders.ids
        items = LineItem.where(temp_order_id: vendor_order_ids, food_id: food_id).sum(:quantity)
    end

    def quantity_display_zero(quantity)
        quantity == 0 ? "" : quantity
    end

    def filtered_item_quantity(quantity)
        quantity == nil ? 0 : quantity
    end

    def next_label_position
        start_new_page if @label_count > 0 && (@label_count % 10).zero?
        label_x = @label_count.even? ? 0 : 4.in
        move_up 2.in if @label_count.odd?
        @label_count += 1
        [label_x, cursor]
    end

  def snacks_for_order(order)
    order.line_items.select do |line_item|
      line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id
    end.map do |line_item|
      [line_item.short_name, line_item.quantity]
    end.sort { |a, b| a[0].downcase <=> b[0].downcase }.each_slice(SNACKS_PER_COLUMN)
    .to_a
  end

  def grouped_orders(orders)
        order_data = orders.joins(:customer).select("id", "customer_id", "total_meal_count", "weekly_menu_id", "customers.first_name", "customers.last_name", "customers.delivery_to",
                                                    "customers.shipping_postal_code", "customers.company_name", "customers.shipping_address", "customers.unit", "customers.delivery_day", "employee_id", "position")

        order_data = order_data.order([:employee_id, :delivery_day, :position]).group_by {|x| [x.employee_id, x.delivery_day]}
  end





















end

