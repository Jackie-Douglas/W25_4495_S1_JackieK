require 'prawn/measurement_extensions'

class OrdersSheet
  include ActiveSupport::NumberHelper
  include Prawn::View

  SNACKS_PER_COLUMN = 6

    def initialize(grouped_orders, orders, grouped_other_orders)
        @grouped_orders = grouped_orders
        @orders = orders
        @grouped_other_orders = grouped_other_orders
        @label_count = 0
        @menu = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i)

        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"

        customer_orders
    end

    # not needed if you are happy with Prawn's default document settings
    def document
      @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10)
    end

    def customer_orders
        @grouped_orders.each do |(shipping_address, unit), order_group|
          begin
          customer = Customer.find_by(shipping_address: shipping_address)  if shipping_address != ""
          
          delivery_to = Customer.where(shipping_address: shipping_address).pluck(:delivery_to).uniq.join.upcase
          delivery_day = Customer.where(shipping_address: shipping_address).pluck(:delivery_day).uniq.join
          city = customer.shipping_city.strip if customer.shipping_city
          postal_code = customer.shipping_postal_code if customer
          rescue

          end

          order_group.each_with_index do |order, index|
            customer = order.customer
            address_order_count = "#{index + 1}/#{order_group.count}"
            driver_name = Employee.find(order.employee_id).customer.first_name if order.employee_id
            

            bounding_box(next_label_position, height: (2.in), width: (4.in)) do
              bounding_box([4.mm, (2.in - 4.mm)], height: (2.in - 8.mm), width: (4.in - 8.mm)) do

                translate(0, 0) do
                  if !order.position.blank? 
                    coordinates = order.position >= 10 ? [0.5, 121] : [3.5, 121]
                    size = order.position >= 10 ? 14.5 : 18
                    stroke_rectangle [0, 123], 18, 18
                      text_box "#{order.position}",
                      at: coordinates,
                      size: size
                  end
                end
                
                translate(22, 0) do 
                  text_box "#{address_order_count} #{customer.first_name.upcase} #{customer.last_name.upcase} | Meals: #{order.total_meal_count} | Driver: #{driver_name}", style: :bold, size: 8
                end
                  text_box customer.delivery_day.upcase[0..2], align: :right, style: :bold, size: 8 # TODO change to "#{delivery_day.upcase[0..2]}-__________-___" when needed
                  move_down 9
                  translate(22, 0) do 
                    text [
                      [customer.unit.presence, customer.shipping_address].compact.join('-'),
                      customer.shipping_city,
                      customer.buzzer.present? ? "B: #{customer.buzzer}" : nil,
                      customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone
                    ].compact.join(', '), size: 8
                end

                foods_for_order_variable = foods_for_order(order).empty? ? [[0, 0]] : foods_for_order(order)


                bounding_box([0, 2.in - 45], height: 25.mm, width: 40.mm) do
                  table(foods_for_order_variable, width: 2.7.cm) do
                    cells.borders = []
                    cells.padding = [1, 3, 1, 3]
                    cells.size = 7.5
                    cells.column(1).align = :right
                    cells.style do |cell|
                      cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                      # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                      cell.font_style = :bold if cell.column
                    end
                  end
                end

                bounding_box([50.mm, 2.in - 45], height: 25.mm, width: 38.mm) do
                  bounding_box([0, 25.mm], width: 20.mm) do
                    table(snacks_first_column(order), width: 20.mm) do
                      cells.borders = []
                      cells.padding = [1, 3, 1, 3]
                      cells.size = 7.5
                      cells.font_style = :bold
                      cells.column(1).align = :right
                      cells.height = 4.mm
                      cells.overflow = :shrink_to_fit
                      cells.style do |cell|
                        cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                      end
                    end if snacks_first_column(order).any?
                  end

                  bounding_box([22.mm, 25.mm], width: 20.mm) do
                    table(snacks_second_column(order), width: 20.mm) do
                      cells.borders = []
                      cells.padding = [1, 3, 1, 3]
                      cells.size = 7.5
                      cells.font_style = :bold
                      cells.column(1).align = :right
                      cells.height = 4.mm
                      cells.overflow = :shrink_to_fit
                      cells.style do |cell|
                        cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                      end
                    end if snacks_second_column(order).any?
                  end
                end

                bounding_box([0, 2.in - 47 - 25.mm], height: 30, width: 40.mm) do
                  text_box "FOOD NOTE: #{customer.food_note}", size: 6
                end

                bounding_box([50.mm, 2.in - 47 - 25.mm], height: 30, width: 38.mm) do
                  text_box "DELIVERY NOTE: #{customer.delivery_note}", size: 6
                end
              end
            end
          end
        end

      @grouped_other_orders.each do |order|
        customer = order.customer
        

        bounding_box(next_label_position, height: (2.in), width: (4.in)) do
          bounding_box([4.mm, (2.in - 4.mm)], height: (2.in - 8.mm), width: (4.in - 8.mm)) do

          translate(0, 0) do
                if !order.position.blank? 
                  coordinates = order.position >= 10 ? [0.5, 121] : [3.5, 121]
                  size = order.position >= 10 ? 14.5 : 18
                  stroke_rectangle [0, 123], 18, 18
                    text_box "#{order.position}",
                    at: coordinates,
                    size: size
                end
              end

            translate(22, 0) do 
              text_box "PICKUP #{customer.first_name.upcase} #{customer.last_name.upcase} | Meals: #{order.total_meal_count}", style: :bold, size: 8
            end
            move_down 9
            translate(22, 0) do 
              text [
              [customer.unit.presence, customer.shipping_address].compact.join('-'),
              customer.shipping_city,
              customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone
              ].compact.join(', '), size: 8
            end

            bounding_box([0, 2.in - 45], height: 25.mm, width: 40.mm) do
              table(foods_for_order(order), width: 2.7.cm) do
                cells.borders = []
                cells.padding = [1, 3, 1, 3]
                cells.size = 7.5
                cells.column(1).align = :right
                cells.style do |cell|
                  cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                  cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                  cell.font_style = :bold if cell.column == 0 && cell.row < row_length - 1
                end
              end
            end

            bounding_box([40.mm, 2.in - 45], height: 25.mm, width: 38.mm) do
              bounding_box([0, 25.mm], width: 20.mm) do
                table(snacks_first_column(order), width: 20.mm) do
                  cells.borders = []
                  cells.padding = [1, 3, 1, 3]
                  cells.size = 7.5
                  cells.font_style = :bold
                  cells.column(1).align = :right
                  cells.height = 4.mm
                  cells.overflow = :shrink_to_fit
                  cells.style do |cell|
                    cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                  end
                end if snacks_first_column(order).any?
              end

              bounding_box([22.mm, 25.mm], width: 20.mm) do
                table(snacks_second_column(order), width: 20.mm) do
                  cells.borders = []
                  cells.padding = [1, 3, 1, 3]
                  cells.size = 7.5
                  cells.font_style = :bold
                  cells.column(1).align = :right
                  cells.height = 4.mm
                  cells.overflow = :shrink_to_fit
                  cells.style do |cell|
                    cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
                  end
                end if snacks_second_column(order).any?
              end
            end

            bounding_box([0, 2.in - 47 - 25.mm], height: 30, width: 40.mm) do
              text_box "FOOD NOTE: #{customer.food_note}", size: 6
            end

            bounding_box([50.mm, 2.in - 47 - 25.mm], height: 30, width: 38.mm) do
              text_box "DELIVERY NOTE: #{customer.delivery_note}", size: 6
            end
          end
        end
      end
    end

  private

  # calculates cursor position for next labelshor
  def next_label_position
    start_new_page if @label_count > 0 && (@label_count % 10).zero?
    label_x = @label_count.even? ? 0 : 4.in
    move_up 2.in if @label_count.odd?
    @label_count += 1
    [label_x, cursor]
  end
  
  def category_meal_id
    FoodCategory.find_by(name: "meal").id
  end

  def foods_for_order(order)

    if order.total_meal_count == 0
      [[0,0]]      
    else 
      array = order.line_items.select do |line_item|
        line_item&.quantity&.positive? && line_item&.food_category_id == category_meal_id
      end.map do |line_item|
        short_name = line_item.gluten_wise_option ? "*GW #{line_item.short_name.titleize}" : line_item.short_name.titleize
        [short_name, line_item.quantity]
      end.sort{ |a, b| a[0].downcase <=> b[0].downcase }
      
       order.weekly_menu.sample && order.customer.tester ? array.push(["SAMPLE", "1"]) : array
       
    end
    # end.push(['TOTAL MEALS', order.total_meal_count])
  end

  def snacks_for_order(order)
    order.line_items.select do |line_item|
      line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id
    end.map do |line_item|
      [line_item.short_name, line_item.quantity]
    end.sort { |a, b| a[0].downcase <=> b[0].downcase }.each_slice(SNACKS_PER_COLUMN)
    .to_a
  end

  # TODO: will prawn make new columns automatically??
  def snacks_first_column(order)
    snacks_for_order(order)[0] || []
  end

  # TODO: will prawn make new columns automatically??
  def snacks_second_column(order)
    snacks_for_order(order)[1] || []
  end
end
