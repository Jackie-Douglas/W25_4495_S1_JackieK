require 'prawn/measurement_extensions'

class EverydayMealsSheet 
  include ActiveSupport::NumberHelper
  include Prawn::View

  def initialize(orders)
    @orders = orders.where(everyday_meals: true)
    self.font_families.update("OpenSans" => {
                            :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                            :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                            :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                            :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
    })

    font "OpenSans"
    vendor_new
  end

  def document
    conversion_pt = 28.34645669291339
    width_in_pt = 10.16 * conversion_pt
    height_in_pt = 15.24 * conversion_pt

    @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10, :page_size => [width_in_pt, height_in_pt])
  end



  def vendor_new
    @orders.each do |order|
      vendor = order.vendor
      em = Food.where(everyday_meals: true).ids

      next if !vendor.everyday_meals 
      next if order.line_items.where(food_id: em).sum(:quantity) == 0

      driver_name = Employee.find(order.employee_id).customer.first_name if order.employee_id

      bounding_box([0, cursor], width: 210, height: 30) do
        text "#{vendor.company_name.upcase}", style: :bold, size: 12
        text "#{vendor.phone.length == 10 ? number_to_phone(vendor.phone) : vendor.phone}", style: :bold, size: 12
      end

      bounding_box([0, cursor - 5], width: 210, height: 40) do
        text [vendor.shipping_address].compact.join('-').titleize, style: :normal, size: 10
        text "#{vendor.shipping_city}".titleize, style: :normal, size: 10
        text "", style: :bold, size: 10
      end

      bounding_box([0, cursor - 10], width: 40.mm) do
        table(foods_for_order(order), width: 4.cm) do
        cells.borders = []
        cells.padding = [4, 6, 4, 6]
        cells.size = 10
        cells.column(1).align = :right
          cells.style do |cell|
              cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
              cell.font_style = :bold if cell.column
          end
        end
      end

      bounding_box([0, cursor - 10], width: 40.mm) do
        table([ ["NOTE: #{vendor.note}"] ]) do
          cells.size = 8
          cells.style do |cell|
            cell.font_style = :italic
          end
        end
      end if !vendor.note.blank?

      translate(0, 0) do
        text_box "#{order.delivery_day[0..2].upcase}", style: :bold, size: 15, align: :right
      end

      translate(0, -13) do
        text_box "#{driver_name.upcase if driver_name}", style: :bold, size: 15, align: :right
      end

      # bounding_box([50.mm, 275], height: 25.mm, width: 4.cm) do
      #   # bounding_box([0, 25.mm], width: 4.cm, height: 8.cm) do
      #   #   table(snacks_for_order(order), width: 4.cm) do
      #   #     cells.borders = []
      #   #     cells.padding = [4, 6, 4, 6]
      #   #     cells.size = 10
      #   #     cells.font_style = :bold
      #   #     cells.column(1).align = :right
      #   #   end if snacks_for_order(order).any?
      #   # end
      # end
      start_new_page
    end
  end

  private 

  def category_meal_id
    FoodCategory.find_by(name: "meal").id
  end

  def foods_for_order(order)

    array = order.line_items.joins(:food).select("line_items.*, foods.*").order("foods.sort_sequence").select do |line_item|
      next if !line_item.everyday_meals
      line_item&.quantity&.positive? && line_item&.food_category_id == category_meal_id
    end.map do |line_item|
      short_name = line_item.gluten_wise_option ? "*GW #{line_item.short_name.titleize}" : line_item.short_name.titleize
      [short_name, line_item.quantity]
    end

    array.push()
  end

  def snacks_for_order(order)
    line_items = order.line_items.joins(:food).select("id", "quantity", "name", "food_id", "foods.food_type", "foods.short_name", "foods.sort_sequence").order("foods.sort_sequence")
    # grouped_line_items = line_items.group_by { |x| x.food_type }
    

    # array = []
    # snack_order = ["dessert", "Dips and Sauces", "addons"]

    # snack_order.each do |o|
    #   grouped_line_items[o].select do |line_item|
        
    #     line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id  
    #   end.map do |line_item|
    #     array << [line_item.short_name.titleize, line_item.quantity]
    #   end
    # end
    # array

    array = line_items.select do |line_item|
      line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id
    end.map do |line_item|
      [line_item.short_name, line_item.quantity]
    end


  end
end

