class SnacksSheet < Prawn::Document

    def initialize(orders, vendor_orders)
        super(:page_layout => :landscape, :page_size => 'LEGAL')
        @orders = orders
        @vendor_orders = vendor_orders
        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"
        snack_orders

    end

    def snack_orders
        this_week_snack_item_ids = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.first).food_items.pluck(:food_id)
        snacks = Food.where(availability: true, id: this_week_snack_item_ids).where.not(food_type: "meal") + Food.where(id: 141)
        snacks = snacks.sort { |a,b| a[:snack_sort_sequence] <=> b[:snack_sort_sequence] }
        

        name_array = snacks.map { |x| x.short_name }
        name_array = name_array.prepend("NAME")
        
        data = [name_array]

        @orders.each do |a|
            snack_items = a.line_items.where(food_id: snacks)
            quantity = snack_items.sum(:quantity)

            # food order cookie, brownie, ricotta, dough, oats, Cooke packs, cookie-6, TVP c, TVP S&P, TVP soy, Thai, Burger, Butter

            next if quantity == 0
            customer = Customer.find(a.customer_id)

            name = ["#{customer.first_name} #{customer.last_name}"]


            snack_data = snacks.map do |x|
                food_item = a.line_items.find_by(food_id: x.id)
                
                if food_item
                    food_item.quantity == 0 ? "" : food_item.quantity
                else
                    ""
                end
            end

            data += ([name + snack_data])
        end
        
        @vendor_orders.each do |a|
            snack_items = a.line_items.where(food_id: snacks)
            quantity = snack_items.sum(:quantity)

            # food order cookie, brownie, ricotta, dough, oats, Cooke packs, cookie-6, TVP c, TVP S&P, TVP soy, Thai, Burger, Butter

            next if quantity == 0

            name = ["#{a.vendor.company_name}"]

            snack_data = snacks.map do |x|
                food_item = a.line_items.find_by(food_id: x.id)
                
                if food_item
                    food_item.quantity == 0 ? "" : food_item.quantity
                else
                    ""
                end
            end
            # data += ([name + snack_data])
        end

        total = ["Total"]

        total_data = snacks.map do |x|
            food_item = x.line_items.find_by(food_id: x.id)
            
            if food_item
                calculate_snack_count(x.id) 
                # + calculate_vendor_snack(x.id)
            else
                0
            end
        end

        data += [(total + total_data)]

        header_data = data[0]
        total_data = data[-1]
        content_data = data[1..-2].sort_by!{ |k| k[0] }

        data = content_data.prepend(header_data)
        data = data.append(total_data)

        table(data, header: true, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}, :width => 930) do |table|
            table.row(0).font_style = :bold
            table.cells.style do |c|
                c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
            end
        end
     
    end

    private

    def get_snack_quantity(line_item, food_id)
        begin
            line_item = line_item.find_by(food_id: food_id)
            line_item.quantity == 0 ? "" : line_item.quantity
        rescue
            ""
        end
    end

    def calculate_snack_count(ref_id)
        LineItem.where(order_id: @orders.pluck(:id), food_id: ref_id).sum(:quantity)
    end

    def calculate_vendor_snack(ref_id)
        food_id = Food.find(ref_id)
        vendor_order_ids = @vendor_orders.ids
        items = LineItem.where(temp_order_id: vendor_order_ids, food_id: food_id).sum(:quantity)
    end

    def quantity_display_zero(quantity)
        quantity == 0 ? "" : quantity
    end

    def filtered_item_quantity(quantity)
        quantity == nil ? 0 : quantity
    end
















































end

