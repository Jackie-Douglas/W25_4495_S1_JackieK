class DoubleProteinSheet < Prawn::Document

  def initialize(orders)
		super(:page_layout => :portrait)
		@orders = orders
    # @orders = Order.where(weekly_menu_id: 485).purchased_orders
		

		self.font_families.update("OpenSans" => {
														:normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
														:italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
														:bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
														:bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
		})

		font "OpenSans"
		double_protein
	end

  def double_protein

    @orders.each do |o|
      next if o.line_items.where(double_protein: true).count == 0
      next if o.customer.on_subscription == false
      move_down 10
      text "#{o.customer.first_name} #{o.customer.last_name} | #{o.customer.email} | subscribed: #{o.customer.on_subscription}", style: :bold
      o.line_items.each do |l|
        next if l.double_protein == false
        move_down 7
        text "- #{l.food.short_name.titleize} X #{l.quantity}", indent_paragraphs: 10
        move_down 1
      end
    end

  end

end