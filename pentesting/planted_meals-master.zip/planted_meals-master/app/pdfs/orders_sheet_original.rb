# class OrdersSheet < Prawn::Document
    
#     def initialize(grouped_orders, orders, grouped_other_orders)
#         super(:page_layout => :landscape)
#         @grouped_orders = grouped_orders
#         @orders = orders
#         @grouped_other_orders = grouped_other_orders  
#         customer_orders        
#     end
  
#     def customer_orders
        
#         menu = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i)        
#         @grouped_orders.each do |k, v|
#             shipping_address = k[0]
#             unit = k[1]

#             customer = Customer.find_by(shipping_address: shipping_address)  if shipping_address != ""

#             delivery_to = Customer.where(shipping_address: shipping_address).pluck(:delivery_to).uniq.join.upcase 
#             delivery_day = Customer.where(shipping_address: shipping_address).pluck(:delivery_day).uniq.join
#             address = shipping_address
#             city = customer.shipping_city.strip if customer
#             postal_code = customer.shipping_postal_code if customer
            
#             address_header = ["#{delivery_to} #{delivery_day unless delivery_day.blank?}", {:content => "#{unit.blank? ? "" : "UNIT: #{unit} |"} #{address}, #{city}, #{postal_code} #{"Nat to deliver" if address.include?("686 West Broadway")}" , :colspan => 12, :align => :center}]
#             header = ["Name", Food.find(menu.mon).name.upcase, Food.find(menu.tue).name.upcase, Food.find(menu.wed).name.upcase, Food.find(menu.thu).name.upcase, Food.find(menu.fri).name.upcase, "<b>TOTAL</b>", "BROWNIE", "COOKIE", "COOKIE 6 PACK", "RICOTTA", "COOKIE DOUGH", "OATS"]
            
#             data = [address_header, header]
#             v.each do |a|
#                 customer = Customer.find(a.customer_id)
#                 buzzer = "<br> <b>Buzzer: #{customer.buzzer}</b>"
#                 if customer.food_note.blank? && customer.delivery_note.blank? 
#                     data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name} #{buzzer if !customer.buzzer.blank?}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta, a.cookie_dough, a.overnight_oats]]
#                 else
#                     data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name} #{buzzer if !customer.buzzer.blank?}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta, a.cookie_dough, a.overnight_oats],
#                              ["#{customer.first_name} #{customer.last_name}", {:content => "Food Notes: #{customer.food_note}", :colspan => 5 }, {:content => "Delivery Notes: #{customer.delivery_note} ", :colspan => 7 }  ]
#                             ]
#                 end
#             end
            
#             table(data, header: 1000, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
#                 table.row(0).font_style = :bold
#                 table.row(1).font_style = :bold
#                 table.cells.style do |c|
#                     c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
#                 end
#             end
#             move_down 10

#         end
        
#         @grouped_other_orders.each do |a|

#             address_header = [{:content => a.delivery_to.titleize, :colspan => 13, :align => :center}]
#             header = ["Name", Food.find(menu.mon).name.upcase, Food.find(menu.tue).name.upcase, Food.find(menu.wed).name.upcase, Food.find(menu.thu).name.upcase, Food.find(menu.fri).name.upcase, "<b>TOTAL</b>", "BROWNIE", "COOKIE", "COOKIE 6 PACK", "RICOTTA", "COOKIE DOUGH", "OATS"]
#             customer = Customer.find(a.customer_id)
#             data = [address_header, header]
#             # data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta, a.cookie_dough, a.overnight_oats]]

#             if customer.food_note.blank? && customer.delivery_note.blank? 
#                 data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta, a.cookie_dough, a.overnight_oats]]
#             else
#                 data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta, a.cookie_dough, a.overnight_oats],
#                             ["#{customer.first_name} #{customer.last_name}", {:content => "Food Notes: #{customer.food_note}", :colspan => 5 }, {:content => "Delivery Notes: #{customer.delivery_note} ", :colspan => 7 }  ]
#                         ]
#             end



            
#             table(data, header: 1000, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
#                 table.row(0).font_style = :bold
#                 table.row(1).font_style = :bold
#                 table.cells.style do |c|
#                     c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
#                 end
#             end
#             move_down 10
            
#         end
#     end


# end