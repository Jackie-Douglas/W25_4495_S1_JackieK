class Invoice < Prawn::Document
    include ActionView::Helpers::NumberHelper
    include ActiveSupport::Inflector

    def initialize(order)
        super()
        @order = order
        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"
        invoice
    end

    def invoice
        begin
            @order.each do |order|
                create_table(order, "multiple")
            end
        rescue
                create_table(@order)
        end
            
    end

    def create_table(order, option=nil)
        unless order.line_items.sum(:quantity) == 0
        
            define_grid(:columns => 2, :rows => 3, :gutter => 10)
            grid(0, 0).bounding_box do
                if order.everyday_meals
									text "Everyday Meals", :size => 30
									text "8354 St George Street, 
												Vancouver, V5X 3S7, Canada
											+ 1 (604) 369-3456
											team@everydaymeals.ca
											"
                else
									text "Planted Meals", :size => 30
									text "8354 St George Street, 
												Vancouver, V5X 3S7, Canada
											+ 1 (778) 819-1190
											team@plantedmeals.ca
											GST# 722145513
											"
                end
                    move_down 10
                    text "Store", :style => :bold
                    move_down 1
                    text "#{order.vendor.company_name}"
                    text "#{order.vendor.email}"
                    move_down 5
                    text "Invoice to", :style => :bold
                    text "#{order.vendor.store_name.blank? ? order.vendor.company_name : order.vendor.store_name}"
                end

            grid(0, 1).bounding_box do
                text "Invoice", { :align => :right, :style => :bold, :size => 20 } 
                move_down 3
                text "Invoice Date: #{order.invoice_date.strftime("%B %d, %Y")}", { :align => :right } 
                move_down 2
                text "Invoice number: #{order.invoice_number}", { :align => :right } 
                move_down 2
                text "PO number: #{order.po_number}", { :align => :right } 
                move_down 2
                text "Delivery Day: #{order.delivery_day&.titleize}", { :align => :right } 
            end

            grid([3, 0], [0.8, 1]).bounding_box do
                invoice_header = ["Description", "Qty", "Unit Price", "Amount"]
                data = [invoice_header]

                order.line_items.each do |l|
                    next if l.quantity == 0
                    data += [[l.name.titleize, l.quantity, number_to_currency(l.price), number_to_currency(l.quantity * l.price)]]
                end 
                    delivery_fee = order.vendor_delivery_fee.blank? ? 0 : order.vendor_delivery_fee
                    if delivery_fee > 0
                        data +=[["Delivery", 1, number_to_currency(delivery_fee), number_to_currency(delivery_fee)]]
                    end

                    subtotal = order.subtotal + delivery_fee
                    gst = subtotal * 0.05
                    amount_due = subtotal + gst

                    data +=[["", "", "Subtotal", number_to_currency(subtotal)]]
                    data +=[["", "", "GST (5%)", number_to_currency(gst)]]
                    data +=[["", "", "Amount Due", number_to_currency(amount_due)]]

                    table(data, :row_colors => ["F0F0F0", "FFFFFF"], :cell_style => { :size => 13, :"border_width" => 0.3, :padding => [7, 7, 5, 5] }, :column_widths => {0 => 300, 2 => 100 }) do |table|
                        table.row(0).font_style = :bold
                    end
                    move_down 10
                    text "<b>Contact us if you have any questions!</b>", inline_format: true
										
										if order.everyday_meals
											move_down 5
											text 'Ordering: team@everydaymeals.ca'
	
											move_down 3
											text 'Billing: team@everydaymeals.ca'
	
											move_down 3
											text 'Phone: +1 (604) 369-3456'
										else
											move_down 5
											text 'Ordering: team@plantedmeals.ca'
	
											move_down 3
											text 'Billing: admin@plantedmeals.ca'
	
											move_down 3
											text 'Phone: +1 (778) 819-1190'
										end

										move_down 10
										text "<b>Vendor Notes</b>: #{order.vendor.note == nil ? 'N/A' : order.vendor.note}", inline_format: true

                    if option == "multiple"
                    move_down 1000
                    text "\n"
                    end

                    
                end
            end
end
    
end

