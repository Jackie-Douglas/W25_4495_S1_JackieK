class WorkScheduleSheet < Prawn::Document
include WorkSchedulesHelper

	def initialize(weekly_menu)
		super(:page_layout => :portrait, :page_size => 'LEGAL')
		friday = weekly_menu.week_start - 3.days 

		@date_range = friday..friday + 2.days 

		self.font_families.update("OpenSans" => {
														:normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
														:italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
														:bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
														:bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
		})

		font "OpenSans"
		work_schedule
	end

	def work_schedule

		
		@date_range.each do |x|
			header = ["Name", "Start", "End", "Out"]
			data = [header]
			text x.strftime("%a, %b %d"),  size: 18
			move_down 5

			WorkSchedule.where(work_date: x).each do |w|
				
				employee = Employee.find(w.employee_id)
				data += ([[employee.customer.full_name&.titleize, display_work_hour(w.work_start), display_work_hour(w.work_end), ""]])
			end

			table(data, header: true, :cell_style => { :size => 10, :align => :center, inline_format: true, :"border_width" => 0.3, :height => 24, position: :center }, :column_widths => {0 => 120, 3 => 60}) do |table|
				table.row(0).font_style = :bold
				table.cells.style do |c|
					c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
				end
			end
			move_down 20
		end
		
	end
end

		# food_ids = Food.where(availability: true).where(food_type: "meal").order(id: :asc).pluck(:id)
		# food_items = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i).food_items.where(food_id: food_ids)
		# foods = Food.where(id: food_items.pluck(:food_id))

		# name_array = foods.map { |x| x.short_name }
		# name_array = name_array.prepend("NAME", "FOOD NOTE")
			
		# data = [name_array]

		# @orders.each do |a|
		# 	customer = Customer.find(a.customer_id)
		# 	items = a.line_items
		# 	next if customer.food_note.blank?
			
		# 	header = ["#{customer.first_name} #{customer.last_name}", customer.food_note]

		# 	food_note_data = foods.map do |x|
		# 		food_item = a.line_items.find_by(food_id: x.id)
		# 		food_item.nil? ? 0 : food_item.quantity
		# 	end

		# 	data += ([header + food_note_data])
		# end

		# table(data, header: true, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
		# 	table.row(0).font_style = :bold
		# 	table.cells.style do |c|
		# 		c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
		# 	end
		# end

