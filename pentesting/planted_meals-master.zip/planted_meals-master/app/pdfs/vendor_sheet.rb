require 'prawn/measurement_extensions'

class VendorSheet < Prawn::Document
# class VendorSheet
    include ActiveSupport::NumberHelper
    include Prawn::View
    
    def initialize(orders)
        super(:page_layout => :landscape)
        @orders = orders
        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"
        vendor_order        

        # vendor_new
    end

    def document
        conversion_pt = 28.34645669291339
        width_in_pt = 10.16 * conversion_pt
        height_in_pt = 15.24 * conversion_pt

      @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10, :page_size => [width_in_pt, height_in_pt])
    end

  
    def vendor_order
        
        @orders.each do |order|
            data = [[],[]]

            order.line_items.order(food_id: "ASC").each do |item|
                next if item.quantity == 0
                data[0] << Food.find(item.food_id).name
                data[1] << item.quantity
            end
             
            data[0].prepend("Name") 
            data[1].prepend(order.vendor.company_name) 
            data[0].append("Total") 
            data[1].append(order.line_items.sum(:quantity)) 
            
            table(data, header: 1000, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 130}) do |table|
                table.row(0).font_style = :bold
                table.cells.style do |c|
                    c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
                end
            end
            move_down 10
        end
        
    end

    # def vendor_new

    #     @orders.each do |order|
    #         vendor = order.vendor

    #         bounding_box([0, cursor], width: 210, height: 30) do
    #                     # | Meals: #{order.total_meal_count}
    #                     text "#{vendor.company_name.upcase}", style: :bold, size: 12
    #                     text "#{vendor.phone.length == 10 ? number_to_phone(vendor.phone) : vendor.phone}", style: :bold, size: 12
    #                 # transparent(0.5) { stroke_bounds }
    #         end

    #         bounding_box([0, cursor - 5], width: 210, height: 40) do
    #             text [vendor.shipping_address].compact.join('-').titleize, style: :normal, size: 10
    #             text "#{vendor.shipping_city}".titleize, style: :normal, size: 10
    #             text "", style: :bold, size: 10

    #             # transparent(0.5) { stroke_bounds }
    #         end

    #         bounding_box([0, cursor - 10], width: 40.mm) do
    #             table(foods_for_order(order), width: 4.cm) do
    #             cells.borders = []
    #             cells.padding = [4, 6, 4, 6]
    #             cells.size = 10
    #             cells.column(1).align = :right
    #             cells.style do |cell|
    #                 # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : [] 
    #                 cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
    #                 # cell.background_color = 
    #                 # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
    #                 cell.font_style = :bold if cell.column
    #             end
    #             end
    #         end

    #         bounding_box([0, cursor - 10], width: 40.mm) do
    #               table([ ["NOTE: #{vendor.note}"] ]) do
    #                 cells.size = 8
    #                 cells.style do |cell|
    #                   cell.font_style = :italic
    #                 end

    #               end
    #         end if !vendor.note.blank?
            
    #         start_new_page
    #     end


    # end


        
        # menu = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i)        
        # @grouped_orders.each do |k, v|
            # shipping_address = k[0]
            # unit = k[1]

            # customer = Customer.find_by(shipping_address: shipping_address)  if shipping_address != ""

            # delivery_to = Customer.where(shipping_address: shipping_address).pluck(:delivery_to).uniq.join.upcase 
            # address = shipping_address
            # city = customer.shipping_city.strip if customer
            # postal_code = customer.shipping_postal_code if customer
            
            # address_header = [delivery_to, {:content => "#{unit.blank? ? "" : "UNIT: #{unit} |"} #{address}, #{city}, #{postal_code} #{"Nat to deliver" if address.include?("686 West Broadway")}" , :colspan => 10, :align => :center}]
            # header = ["Name", Food.find(menu.mon).name.upcase, Food.find(menu.tue).name.upcase, Food.find(menu.wed).name.upcase, Food.find(menu.thu).name.upcase, Food.find(menu.fri).name.upcase, "<b>TOTAL</b>", "BROWNIE", "COOKIE", "COOKIE 6 PACK", "RICOTTA"]
            
            # data = [address_header, header]
            # v.each do |a|
            #     customer = Customer.find(a.customer_id)
            #     buzzer = "<br> <b>Buzzer: #{customer.buzzer}</b>"
            #     if customer.food_note.blank? && customer.delivery_note.blank? 
            #         data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name} #{buzzer if !customer.buzzer.blank?}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta]]
            #     else
            #         data += [["(#{customer.delivery_to}) #{customer.first_name} #{customer.last_name} #{buzzer if !customer.buzzer.blank?}", a.mon, a.tue, a.wed, a.thu, a.fri, "<b>#{a.total_meal_count}</b>", a.brownie, a.single_cookie, a.bundle_cookie, a.ricotta],
            #                  ["#{customer.first_name} #{customer.last_name}", {:content => "Food Notes: #{customer.food_note}", :colspan => 5 }, {:content => "Delivery Notes: #{customer.delivery_note} ", :colspan => 5 }  ]
            #                 ]
            #     end
            # end
            
            # table(data, header: 1000, :cell_style => { :size => 7, :align => :center, inline_format: true, :"border_width" => 0.3 }, :column_widths => {0 => 120}) do |table|
            #     table.row(0).font_style = :bold
            #     table.row(1).font_style = :bold
            #     table.cells.style do |c|
            #         c.background_color = ((c.column) % 2).zero? ? 'dddddd' : 'ffffff'
            #     end
            # end
            # move_down 10

        # end
     
    # end

    private 

    def foods_for_order(order)
        return if order.line_items.sum(:quantity) == 0

        # if order.line_items.sum == 0
        # [[0,0]]      
        # else 
        array = order.line_items.select do |line_item|
            line_item&.quantity&.positive?
        end.map do |line_item|
            short_name = line_item.gluten_wise_option ? "*GW #{line_item.short_name.titleize}" : line_item.short_name.titleize
            [short_name, line_item.quantity]
        end.sort{ |a, b| a[0].downcase <=> b[0].downcase }
        
        array.push(['TOTAL', order.line_items.sum(:quantity)])
        # end
        # end.push(['TOTAL MEALS', order.total_meal_count])
    end

            # data = [[],[]]

            # order.line_items.order(food_id: "ASC").each do |item|
            #     next if item.quantity == 0
            #     data[0] << Food.find(item.food_id).name
            #     data[1] << item.quantity
            # end
             
            # data[0].prepend("Name") 
            # data[1].prepend(order.vendor.company_name) 
            # data[0].append("Total") 
            # data[1].append(order.line_items.sum(:quantity)) 




















end

