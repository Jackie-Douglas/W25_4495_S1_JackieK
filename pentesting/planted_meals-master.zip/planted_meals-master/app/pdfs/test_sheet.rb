require 'prawn/measurement_extensions'
#   transparent(0.5) { stroke_bounds }
class TestSheet
  include ActiveSupport::NumberHelper
  include Prawn::View

  SNACKS_PER_COLUMN = 6

    def initialize(grouped_orders, orders, grouped_other_orders)
        @grouped_orders = grouped_orders
        @orders = orders
        # @orders = WeeklyMenu.last(2).first.orders.where(purchased: true)
        
        @weekly_menu = WeeklyMenu.find(orders.pluck(:weekly_menu_id).uniq.join)

        @vendor_cook_date = @weekly_menu.week_start - 1.day

        @vendor_order_data = TempOrder.where(cook_on: @vendor_cook_date, everyday_meals: false).joins(:vendor).select("id", "vendor_id", "vendors.company_name", "delivery_day", "total_meal_count", "weekly_menu_id", 
                                                                                              "vendors.shipping_postal_code", "vendors.company_name", "vendors.shipping_address", "employee_id", "position")
        @grouped_other_orders = grouped_other_orders
        @label_count = 0
        @menu = WeeklyMenu.find(@orders.pluck(:weekly_menu_id).uniq.join.to_i)

        self.font_families.update("OpenSans" => {
                                :normal => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Regular.ttf"),
                                :italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Italic.ttf"),
                                :bold => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-Bold.ttf"),
                                :bold_italic => Rails.root.join("app/assets/fonts/Open_Sans/OpenSans-BoldItalic.ttf")
        })

        font "OpenSans"

        # customer_orders
        
        test_orders

    end

    # not needed if you are happy with Prawn's default document settings
    def document
        conversion_pt = 28.34645669291339
        width_in_pt = 10.16 * conversion_pt
        height_in_pt = 15.24 * conversion_pt

      @my_prawn_doc ||= Prawn::Document.new(left_margin: 10, right_margin: 10, :page_size => [width_in_pt, height_in_pt])
    end

    def test_orders
      content_header
      start_new_page
      labels(false)
      special_header
      labels(true)
      vendor_header
      vendor_labels
      # move_down 10
      # stroke_axis
    end

  private

  # calculates cursor position for next labelshor
  def next_label_position
    start_new_page if @label_count > 0 && (@label_count % 10).zero?
    label_x = @label_count.even? ? 0 : 4.in
    move_up 2.in if @label_count.odd?
    @label_count += 1
    [label_x, cursor]
  end
  
  def category_meal_id
    FoodCategory.find_by(name: "meal").id
  end

  def foods_for_order(order)
    if order.model_name.name == "Order"
      if order.total_meal_count == 0 
        [[0,0]]      
      else
        array = order.line_items.select do |line_item|
          line_item&.quantity&.positive? && line_item&.food_category_id == category_meal_id
        end.map do |line_item|
          short_name = line_item.gluten_wise_option ? "(  )*GW #{line_item.short_name.titleize}" : line_item.short_name.titleize
          short_name = line_item.double_protein ? short_name.prepend("( )*DP ") : short_name
          [short_name, line_item.quantity]
        end.sort{ |a, b| a[0].downcase <=> b[0].downcase }
        order.weekly_menu.sample && order.customer.tester ? array.push(["SAMPLE", "1"]) : array
      end
    else
        array = order.line_items.select do |line_item|
          line_item&.quantity&.positive? && line_item&.food_category_id == category_meal_id
        end.map do |line_item|
          short_name = line_item.gluten_wise_option ? "(  )*GW #{line_item.short_name.titleize}" : line_item.short_name.titleize
          [short_name, line_item.quantity]
        end.sort{ |a, b| a[0].downcase <=> b[0].downcase }
        array
    end
    
  end

  def snacks_for_order(order)
    # addons = foods.where.not(food_type: "meal").order("LOWER(short_name)").group_by { |x| x.food_type }
    

    line_items = order.line_items.joins(:food).select("id", "quantity", "name", "food_id", "foods.food_type", "foods.short_name")
    grouped_line_items = line_items.group_by { |x| x.food_type }

    array = []

    snack_order = ["dessert", "Dips and Sauces", "addons"]

    snack_order.each do |o|
      next if grouped_line_items[o].nil?

      grouped_line_items[o].select do |line_item|
        
        line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id  
      end.map do |line_item|
        array << [line_item.short_name.titleize, line_item.quantity]
      end.sort { |a, b| a[0][0].downcase <=> b[0][0].downcase }
    end

    array

    

    # grouped_line_items.each do |grouped_line_item|

    #   grouped_line_item[1].select do |line_item|
    #     binding.pry if order.customer.last_name == "lau"
    #     line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id  
    #   end.map do |line_item|
    #     array << [line_item.short_name.titleize, line_item.quantity]
    #     binding.pry if order.customer.last_name == "lau"
    #   end
    #   # 

    # end

     


    
    # array = line_items.select do |line_item|
    #   line_item&.quantity&.positive? && line_item&.food_category_id != category_meal_id
    # end.map do |line_item|
    #   [line_item.short_name.titleize, line_item.quantity]
    # end.sort { |a, b| a[0].downcase <=> b[0].downcase }
    # end.sort { |a, b| a[0].downcase <=> b[0].downcase }.each_slice(SNACKS_PER_COLUMN)
    
  end

  # # TODO: will prawn make new columns automatically??
  # def snacks_first_column(order)
  #   snacks_for_order(order)[0] || []
  # end

  # # TODO: will prawn make new columns automatically??
  # def snacks_second_column(order)
  #   snacks_for_order(order)[1] || []
  # end

  def vendor_header
    text "Vendor Orders", size: 20, style: :bold, align: :center, valign: :center
    start_new_page
  end

  def special_header
    text "Special Orders", size: 20, style: :bold, align: :center, valign: :center
    start_new_page
  end

  def content_header
    food_ids = @weekly_menu.food_items.pluck(:food_id)
      foods = Food.where(id: food_ids)
      meals = foods.where(food_type: "meal").order("LOWER(short_name)")
      addons = foods.where.not(food_type: "meal").order("LOWER(short_name)").group_by { |x| x.food_type }

      text "Meals", size: 11, style: :bold
      meals.each_with_index do |item, index|
          index = index + 1
          bounding_box([0, cursor - 10], width: 40.mm) do
            table([["#{index}. #{item.short_name.titleize}", ""]], width: 4.cm) do
              cells.borders = []
              cells.padding = [0, 6, 0, 6]
              cells.size = 10
              cells.column(1).align = :right
              cells.style do |cell|
                # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : [] 
                # cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
                # cell.background_color = 
                # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                # cell.font_style = :bold if cell.column
              end
            end
          end
        end


      unless @grouped_orders[true].nil?
        move_down 7  
        text "Specials", size: 11, style: :bold
        move_down 5
  
        @grouped_orders[true].group_by {|x| [x.customer.delivery_day, x.employee_id]}.transform_values(&:size).each do |k, v|
          driver_name = k[1].nil? ? "PU" : Employee.find(k[1]).customer.first_name
          move_down 7
          text "#{k[0][0..2]} #{driver_name}: #{v}", size: 11
        end 
      end
      
      

      
      height_condition = @grouped_orders[true].nil? ? 168 : 350
      bounding_box([50.mm, cursor + height_condition], height: 4.m, width: 4.cm) do
      addons.each do |item|
          text item[0].titleize , size: 11, style: :bold
          move_down 5
          item[1].each_with_index do |s, index|
            index = index + 1
            text "#{index}. #{s.short_name.titleize}", size: 10
            move_down 5

          end
        end
      end
  end

  def labels(order_type)
    return if @grouped_orders[order_type] == nil

    @grouped_orders[order_type].group_by { |x| [x.shipping_address, x.unit]}.each do |(shipping_address, unit), order_group|
      order_group.each_with_index do |order, index|
        customer = order.customer
        address_order_count = "#{index + 1}/#{order_group.count}" unless customer.delivery_to == "pick up"
        driver_name = Employee.find(order.employee_id).customer.first_name if order.employee_id
        
        label_content(order, index, order_group)
      end
      
      start_new_page if order_group.count <= 1  
    end
  end
  

  def label_content(order, index, order_group)
    customer = order.customer
    address_order_count = "#{index + 1}/#{order_group.count}" unless customer.delivery_to == "pick up"
    driver_name = Employee.find(order.employee_id).customer.first_name if order.employee_id

    bounding_box([0, cursor], width: 230, height: 30) do
      # | Meals: #{order.total_meal_count}
      text "#{address_order_count} #{customer.first_name.upcase} #{customer.last_name.upcase}", style: :bold, size: 12
      text "#{customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone}", style: :bold, size: 12
      # transparent(0.5) { stroke_bounds }
    end

    bounding_box([0, cursor - 5], width: 210, height: 40) do
      text [customer.unit.presence, customer.shipping_address].compact.join('-').titleize.truncate(35), style: :normal, size: 12
      text "#{customer.shipping_city}".titleize, style: :normal, size: 12
      text "#{customer.buzzer.present? ? "BZR: #{customer.buzzer[0..25]}" : nil}", style: :bold, size: 10

      # transparent(0.5) { stroke_bounds }
    end

    bounding_box([0, cursor - 5], width: 210, height: 40) do
      table([ ["DELIVERY NOTE: #{customer.delivery_note}"] ]) do
        cells.size = 10
        cells.style do |cell|
          cell.font_style = :italic
          cell.min_font_size = 8
        end
      end if !customer.delivery_note.blank?
    end

    translate(0, 20) do
      text_box "##{order.id}", style: :bold, size: 8, align: :right
    end

    translate(0, 0) do
      text_box "#{order.position}", style: :bold, size: 40, align: :right
    end

    translate(0, -37) do
      if customer.delivery_to.include?("home") || customer.delivery_to.include?("office")
        text_box "#{customer.delivery_day[0..2].upcase}", style: :bold, size: 15, align: :right
      else
        text_box "PU", style: :bold, size: 15, align: :right
      end
    end

    translate(0, -52) do
      text_box "#{driver_name.upcase if driver_name}", style: :bold, size: 15, align: :right
    end

    foods_for_order_variable = foods_for_order(order).empty? ? [[0, 0]] : foods_for_order(order).append(["TOTAL MEALS", order.total_meal_count])

    bounding_box([0, cursor - 10], width: 40.mm) do
      table(foods_for_order_variable, width: 4.cm) do
        cells.borders = []
        cells.padding = [4, 6, 4, 6]
        cells.size = 10
        cells.column(1).align = :right
        cells.style do |cell|
          # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : [] 
          cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
          # cell.background_color = 
          # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
          cell.font_style = :bold if cell.column
        end
      end
    end

    bounding_box([0, cursor - 10], width: 40.mm) do
      table([ ["FOOD NOTE: #{customer.food_note}"] ]) do
        cells.size = 10
        cells.style do |cell|
          cell.font_style = :italic
        end

      end
    end if !customer.food_note.blank?

    bounding_box([0, cursor - 10], width: 40.mm) do
      table([["", "SPECIAL"]], width: 4.cm) do
        cells.style do |cell|
          cell.borders = cell.column.even? ? [:top, :bottom, :left, :right] : []
          cell.font_style = :bold if cell.column
        end
      end
    end if order.special

    bounding_box([0, 20], width: 90.mm) do
        table([ ["Please return bag and ice packs on your next delivery"] ]) do
        cells.size = 9
        cells.style do |cell|
          cell.font_style = :italic
          cell.font_style = :bold
        end
      end
    end

    bounding_box([50.mm, 230], height: 25.mm, width: 4.cm) do
      bounding_box([0, 25.mm], width: 4.cm, height: 8.cm) do
        table(snacks_for_order(order), width: 4.cm) do
          cells.borders = []
          cells.padding = [4, 6, 4, 6]
          cells.size = 10
          cells.font_style = :bold
          cells.column(1).align = :right
          cells.style do |cell|
            # cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
            # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : []
          end
        end if snacks_for_order(order).any?
          # transparent(0.5) { stroke_bounds }
      end
    end
    
    start_new_page if order_group.count > 1  

  end
  

  def vendor_labels
            vendor_orders_count = @vendor_order_data.length

        @vendor_order_data.each do |order|
          vendor_orders_count -= 1

          customer = order.vendor
          driver_name = Employee.find(order.employee_id).customer.first_name if order.employee_id

          bounding_box([0, cursor], width: 210, height: 30) do
                        # | Meals: #{order.total_meal_count}
                        text "#{customer.company_name.upcase}", style: :bold, size: 12
                        text "#{customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone}", style: :bold, size: 12
                    # transparent(0.5) { stroke_bounds }
          end

          bounding_box([0, cursor - 5], width: 210, height: 40) do
                    text [customer.shipping_address].compact.join('-').titleize, style: :normal, size: 10
                    text "#{customer.shipping_city}".titleize, style: :normal, size: 10
                    text "", style: :bold, size: 10

                    # transparent(0.5) { stroke_bounds }
          end

          bounding_box([0, cursor - 5], width: 210, height: 40) do
                  table([ ["DELIVERY NOTE: #{customer.note}"] ]) do
                      cells.size = 10
                      cells.style do |cell|
                        cell.font_style = :italic
                        cell.min_font_size = 8
                    end
              end if !customer.note.blank?
          end

          translate(0, 20) do
            text_box "##{order.id}", style: :bold, size: 8, align: :right
          end


          translate(0, 0) do
            text_box "#{order.position}", style: :bold, size: 40, align: :right
          end

          translate(0, -37) do
            text_box "#{order.delivery_day[0..2].upcase}", style: :bold, size: 15, align: :right
          end

          translate(0, -52) do
            text_box "#{driver_name.upcase if driver_name}", style: :bold, size: 15, align: :right
          end


          bounding_box([0, cursor - 10], width: 40.mm) do
            table(foods_for_order(order).append(["TOTAL MEALS", order.total_meal_count]), width: 4.cm) do
              cells.borders = []
              cells.padding = [4, 6, 4, 6]
              cells.size = 10
              cells.column(1).align = :right
              cells.style do |cell|
                # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : [] 
                cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
                # cell.background_color = 
                # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                cell.font_style = :bold if cell.column
              end
            end
          end

          bounding_box([50.mm, 230], height: 25.mm, width: 4.cm) do
          bounding_box([0, 25.mm], width: 4.cm, height: 8.cm) do
            table(snacks_for_order(order), width: 4.cm) do
              cells.borders = []
              cells.padding = [4, 6, 4, 6]
              cells.size = 10
              cells.font_style = :bold
              cells.column(1).align = :right
              cells.style do |cell|
                # cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
              end
            end if snacks_for_order(order).any?
              # transparent(0.5) { stroke_bounds }
          end
        end
          start_new_page if vendor_orders_count > 0
        end
  end

  def extra
    other_orders_count = @grouped_other_orders.length

        @grouped_other_orders.each do |order|

          other_orders_count -= 1

          customer = order.customer

          bounding_box([0, cursor], width: 210, height: 30) do
                        # | Meals: #{order.total_meal_count}
                        text "#{customer.first_name.upcase} #{customer.last_name.upcase}", style: :bold, size: 12
                        text "#{customer.phone.length == 10 ? number_to_phone(customer.phone) : customer.phone}", style: :bold, size: 12
                    # transparent(0.5) { stroke_bounds }
          end

          bounding_box([0, cursor - 5], width: 210, height: 40) do
                    text [customer.unit.presence, customer.shipping_address].compact.join('-').titleize, style: :normal, size: 10
                    text "#{customer.shipping_city}".titleize, style: :normal, size: 10
                    text "", style: :bold, size: 10

                    # transparent(0.5) { stroke_bounds }
          end

          bounding_box([0, cursor - 5], width: 210, height: 40) do
                  table([ ["DELIVERY NOTE: #{customer.delivery_note}"] ]) do
                      cells.size = 10
                      cells.style do |cell|
                        cell.font_style = :italic
                        cell.min_font_size = 8
                    end
              end if !customer.delivery_note.blank?
          end

          translate(0, 0) do
                  text_box "#{order.position}", style: :bold, size: 40, align: :right
          end

          translate(0, -37) do
                  text_box "PU", style: :bold, size: 15, align: :right
          end

          translate(0, -52) do
                  text_box "", style: :bold, size: 15, align: :right
          end


          bounding_box([0, cursor - 10], width: 40.mm) do
            table(foods_for_order(order).append(["TOTAL MEALS", order.total_meal_count]), width: 4.cm) do
              cells.borders = []
              cells.padding = [4, 6, 4, 6]
              cells.size = 10
              cells.column(1).align = :right
              cells.style do |cell|
                # cell.borders = cell.row.even? ? (cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right]) : [] 
                cell.borders = cell.column.even? ? [:top, :bottom, :left] : [:top, :bottom, :right] if cell.row == row_length - 1
                # cell.background_color = 
                # cell.background_color = 'FFFFFF' if cell.row == row_length - 1
                cell.font_style = :bold if cell.column
              end
            end
          end

          bounding_box([0, cursor - 10], width: 40.mm) do
            table([ ["FOOD NOTE: #{customer.food_note}"] ]) do
              cells.size = 10
              cells.style do |cell|
                cell.font_style = :italic
              end

            end
          end if !customer.food_note.blank?

          bounding_box([0, cursor - 10], width: 40.mm) do
                  table([["", "SPECIAL"]], width: 4.cm) do
                    cells.style do |cell|
                      cell.borders = cell.column.even? ? [:top, :bottom, :left, :right] : []
                      cell.font_style = :bold if cell.column
                    end
                  end
                end if order.special


            bounding_box([0, 20], width: 90.mm) do
                table([ ["Please return bag and ice packs on your next delivery"] ]) do
              cells.size = 9
              cells.style do |cell|
                cell.font_style = :italic
                cell.font_style = :bold
              end
            end
          end 

          bounding_box([50.mm, 230], height: 25.mm, width: 4.cm) do
          bounding_box([0, 25.mm], width: 4.cm, height: 8.cm) do
            table(snacks_for_order(order), width: 4.cm) do
              cells.borders = []
              cells.padding = [4, 6, 4, 6]
              cells.size = 10
              cells.font_style = :bold
              cells.column(1).align = :right
              cells.style do |cell|
                # cell.background_color = cell.row.even? ? 'DDDDDD' : 'FFFFFF'
              end
            end if snacks_for_order(order).any?
              # transparent(0.5) { stroke_bounds }
          end
        end
          # start_new_page if other_orders_count > 0
          start_new_page
        end

  end
end
