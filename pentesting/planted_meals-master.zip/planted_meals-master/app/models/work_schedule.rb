class WorkSchedule < ApplicationRecord
  belongs_to :employee

  before_validation :calculate_total_hr
  after_create :create_workhour_for_if_salary

  validate :staff_cannot_be_scheduled_twice_on_a_same_day, on: :create
  
  def calculate_total_hr
    self.total_hours = (self.work_end - self.work_start) / 1.hour
  end

  def staff_cannot_be_scheduled_twice_on_a_same_day
    if already_scheduled?(self.work_date, self.employee_id)
       errors.add(:employee, "is already scheduled")
    end
  end

  def already_scheduled?(date, employee_id)
    WorkSchedule.find_by(work_date: date, employee_id: employee_id)
  end

  def create_workhour_for_if_salary
     work_hour = self.employee.work_hours.build(start_hour: 9, start_min: 0, start_am_or_pm: "AM", end_hour: 5, end_min: 0, end_am_or_pm: "PM", work_date: self.work_date, employee_code: self.employee.customer.id) 

     work_hour.save if self.employee.salary
  end

end
