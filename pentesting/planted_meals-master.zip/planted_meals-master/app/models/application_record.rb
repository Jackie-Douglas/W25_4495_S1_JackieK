class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true

  def update_email_on_user_model
    return if self.user.nil?

    self.user.update_columns(email: email)
  end




end
