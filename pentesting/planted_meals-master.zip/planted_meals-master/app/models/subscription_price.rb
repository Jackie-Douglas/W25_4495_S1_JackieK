class SubscriptionPrice < ApplicationRecord
    has_many :customers
end
