class Tracker < ApplicationRecord
end
