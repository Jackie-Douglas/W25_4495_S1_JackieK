class FoodGroup < ApplicationRecord
  has_many :foods
end
