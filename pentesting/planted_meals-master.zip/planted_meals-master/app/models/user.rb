class User < ApplicationRecord
  enum role: [:customer, :vendor, :manager, :admin]
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable,
         :confirmable
  has_one :customer
  has_many :referrals
  has_one :wallet
  has_one :vendor
  has_many :gift_cards, dependent: :nullify

  after_save :update_email_on_vendor_or_customer_model

  def update_email_on_vendor_or_customer_model
    
    return if self.vendor.nil? 

    if self.user_type =="vendor"
        self.vendor.update_columns(email: self.email)
      else
        self.customer.update_columns(email: self.email)
    end
  end
  
end
