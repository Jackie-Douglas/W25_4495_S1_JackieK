class FoodCategory < ApplicationRecord
    has_many :foods
end
