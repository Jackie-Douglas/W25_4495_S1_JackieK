class Recipe < ApplicationRecord
  belongs_to :food, optional: true
  has_many :recipe_ingredients
  has_many :ingredients, through: :recipe_ingredients
  has_many :recipe_instructions, dependent: :destroy

  accepts_nested_attributes_for :recipe_ingredients
  accepts_nested_attributes_for :recipe_instructions
end
