class PlatingIngredient < ApplicationRecord
  belongs_to :plating_component
end
