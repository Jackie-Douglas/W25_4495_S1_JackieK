class PlatingComponent < ApplicationRecord
  belongs_to :plating_guide

  has_many :ingredient_informations, dependent: :destroy
  has_many :plating_ingredients

  accepts_nested_attributes_for :plating_ingredients
end
