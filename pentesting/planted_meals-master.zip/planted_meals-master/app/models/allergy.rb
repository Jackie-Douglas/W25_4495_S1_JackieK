class Allergy < ApplicationRecord
  belongs_to :food
  belongs_to :customer
end
