class GiftCard < ApplicationRecord
    belongs_to :user, optional: true
    before_validation :create_uuid
    before_validation :downcase_email

    has_many :gift_card_transactions

    def create_uuid
        self.uuid = SecureRandom.hex(3) if self.uuid.blank?
    end

    def downcase_email
        self.to_email = self.to_email.downcase
        self.from_email = self.from_email.downcase
    end

end
