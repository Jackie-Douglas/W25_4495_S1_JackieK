class Pdf < ApplicationRecord
end
