class IngredientLocation < ApplicationRecord
  has_many :ingredients
end
