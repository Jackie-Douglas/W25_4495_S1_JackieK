class Referral < ApplicationRecord
    belongs_to :user
    before_validation :create_uuid
    validates :email, uniqueness: true
    before_validation :downcase_email

    def create_uuid
        self.uuid = SecureRandom.uuid
    end

    def downcase_email
        self.email = email.downcase
    end

end
