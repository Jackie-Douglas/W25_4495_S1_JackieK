class GiftCardTransaction < ApplicationRecord
    belongs_to :gift_card
end
