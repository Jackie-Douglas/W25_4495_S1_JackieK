class Transaction < ApplicationRecord
end
