class NewsletterEmail < ApplicationRecord
    validates :email, uniqueness: true
end
