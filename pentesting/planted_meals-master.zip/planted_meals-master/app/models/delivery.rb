class Delivery < ApplicationRecord
  has_many :customers
end
