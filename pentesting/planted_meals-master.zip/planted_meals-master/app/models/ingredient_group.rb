class IngredientGroup < ApplicationRecord
  has_many :ingredients
end
