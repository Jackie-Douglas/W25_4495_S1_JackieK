class Plan < ApplicationRecord
end
