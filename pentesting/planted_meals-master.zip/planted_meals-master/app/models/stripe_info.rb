class StripeInfo < ApplicationRecord
    belongs_to :customer

    before_validation :normalize_info

    def normalize_info
        self.stripe_customer_id = stripe_customer_id.strip if self.stripe_customer_id
        self.default_source = default_source.strip if self.default_source
    end
end
