class Food < ApplicationRecord
	scope :for_allergies, -> { where(food_type: "meal", availability: true) }

  mount_uploader :image, FoodUploader

  has_many :line_items
  has_many :food_items
  has_many :recipes
	has_many :prep_tasks
	has_many :allergies
	has_many :customers, through: :allergies
	has_many :add_ons
	has_many :food_reviews
	has_many :customers, through: :food_reviews
	
	has_one :plating_guide

	accepts_nested_attributes_for :add_ons, reject_if: proc { |attributes| attributes['recipe_id'].blank? }

  belongs_to :food_category
  belongs_to :food_group, optional: true
  belongs_to :eating_instruction, optional: true
  # validates :sort_sequence, uniqueness: true
  validates :retail_price, presence: true
  validates :wholesale_price, presence: true
  validate :snack_sort_sequence_presence_true_on_snacks_and_addons
  validates :spicy_level, numericality: { less_than_or_equal_to: 3 }, :allow_nil => true

  before_validation :downcase_allergen_input
  before_validation :update_food_type
  before_validation :update_eating_instructions
  before_save :resequence_snack_sort_sequence
  # before_save :create_recipe, on: :create

	


	def downcase_allergen_input
			self.allergens = allergens.downcase if !allergens.nil?
	end

	def update_eating_instructions
			return if self.eating_instruction_id.nil?
			eating_instruction = EatingInstruction.find(self.eating_instruction_id)
			self.eating_instructions = eating_instruction.instructions
	end

	def update_food_type
			name = FoodCategory.find(self.food_category_id).name
			self.food_type = name
	end

	def snack_sort_sequence_presence_true_on_snacks_and_addons
			if food_type != "meal" && snack_sort_sequence.nil?
					errors.add(:snack_sort_sequence, "can't be blank")
			end
	end

	def resequence_snack_sort_sequence
			return if self.food_type == "meal"
			snacks = Food.order(snack_sort_sequence: :ASC).where(availability: true).where.not(food_type: "meal") + Food.where(id: 141)
			added_sort_sequence = snack_sort_sequence
			final_sort_sequence =  snacks.pluck(:snack_sort_sequence).compact.max { |a, b| a<=>b }
			
			added_sort_sequence.upto(final_sort_sequence).each do |s|
					new_sort_sequence = s + 1
					food = Food.find_by(snack_sort_sequence: s)
					return if food.nil?
					food.update_columns(snack_sort_sequence: new_sort_sequence)
			end
	end

	def create_recipe
			self.build_recipe
	end
end