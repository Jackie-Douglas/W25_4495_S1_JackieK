class PrepTask < ApplicationRecord
  scope :veggie_task, -> { where(station: nil) }
  belongs_to :recipe_ingredient, optional: true 
  belongs_to :food, optional: true

  has_many :employee_prep_tasks, dependent: :nullify
  has_many :employee, through: :employee_prep_tasks, dependent: :nullify
end
