class IngredientTransaction < ApplicationRecord
  belongs_to :ingredient
end
