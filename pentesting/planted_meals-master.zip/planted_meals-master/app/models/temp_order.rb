class TempOrder < ApplicationRecord
    has_many :line_items, dependent: :destroy
    belongs_to :vendor
    accepts_nested_attributes_for :line_items,
        :reject_if => proc {|attributes|
        attributes.all? {|k,v| v.blank?}
    }

    before_validation :update_order_number, on: :create
    before_validation :update_nil_to_zero
    before_validation :update_total_meal_count
    belongs_to :employee, optional: true

    # validate :cannot_have_duplicate_orders, on: :create

    def update_order_number
        self.invoice_number = "PM#{SecureRandom.hex(3).upcase}-#{SecureRandom.hex(2).upcase}"
    end

    def update_nil_to_zero
      self.line_items.each do |x|
        x.quantity = 0 if x.quantity.blank?
      end
    end

    def update_total_meal_count
      update_nil_to_zero
      count = sort_meals_to_snacks(self.line_items).map(&:quantity).sum
      self.total_meal_count = count
    end

    def update_nil_to_zero
        self.line_items.each do |x|
          x.quantity = 0 if x.quantity.blank?
        end
    end

    def sort_meals_to_snacks(items)
      food_ids = items.map(&:food_id)
      meal_category_id = FoodCategory.find_by(name: "meal").id
      meal_ids = Food.where(id: food_ids).where(food_category_id: meal_category_id).ids

      items.select do |x|
        x if meal_ids.include?(x.food_id)
      end
    end

    def cannot_have_duplicate_orders
      if vendor_already_ordered
        errors.add(:orders, "We already have an order for this date")
      end
    end

    def vendor_already_ordered
      !TempOrder.find_by(vendor_id: vendor_id, cook_on: cook_on).nil?
    end
end


  
    