class CookMachine < ApplicationRecord
end
