class WorkHour < ApplicationRecord
    belongs_to :employee
    validate :employee_code_confirmation

    def employee_code_confirmation
        employee_code = Employee.find(self.employee_id).customer_id

        if self.employee_code != employee_code
            errors.add(:employee_code, "does not match!")
        end
    end

end



# validate :expiration_date_cannot_be_in_the_past,
#     :discount_cannot_be_greater_than_total_value

#   def expiration_date_cannot_be_in_the_past
#     if expiration_date.present? && expiration_date < Date.today
#       errors.add(:expiration_date, "can't be in the past")
#     end
#   end

#   def discount_cannot_be_greater_than_total_value
#     if discount > total_value
#       errors.add(:discount, "can't be greater than total value")
#     end
#   end