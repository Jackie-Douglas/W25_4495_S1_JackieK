class WeeklyMenu < ApplicationRecord
    has_many :orders, dependent: :destroy
    has_many :food_items, dependent: :destroy
    has_many :email_templates, dependent: :destroy
    has_one :labour_target

    accepts_nested_attributes_for :food_items, reject_if: :food_id_is_nil

    validates :week_start, :week_end, uniqueness: true, presence: true
    before_validation :update_order_sheet

    def update_order_sheet
        meal_ids = self.food_items.map do |f|
            food_type = Food.find(f.food_id).food_type
            next if food_type != "meal"
            f.food_id
        end
        
        meal_ids = meal_ids.compact

        self.mon = meal_ids[0]
        self.tue = meal_ids[1]
        self.wed = meal_ids[2]
        self.thu = meal_ids[3]
        self.fri = meal_ids[4]
    end

    def food_id_is_nil(attributes)
        attributes[:food_id].blank?
    end

end
