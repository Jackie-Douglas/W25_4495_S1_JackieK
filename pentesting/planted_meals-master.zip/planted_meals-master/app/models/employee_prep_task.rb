class EmployeePrepTask < ApplicationRecord
  belongs_to :prep_task
  belongs_to :employee, optional: true
end
