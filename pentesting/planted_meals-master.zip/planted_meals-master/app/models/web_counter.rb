class WebCounter < ApplicationRecord
end
