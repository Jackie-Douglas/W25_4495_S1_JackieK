class Employee < ApplicationRecord
	belongs_to :customer
	has_many :work_hours
	has_many :orders
	has_many :temp_orders
	has_many :work_schedules
	has_many :wage_informations

	has_many :employee_prep_tasks
	has_many :prep_tasks, through: :employee_prep_tasks

	before_validation :assign_uuid

	def assign_uuid
		self.uuid = SecureRandom.hex(10) if self.uuid.nil?
	end
end
