class Notice < ApplicationRecord
end
