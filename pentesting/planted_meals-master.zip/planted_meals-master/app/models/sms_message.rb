class SmsMessage < ApplicationRecord
end
