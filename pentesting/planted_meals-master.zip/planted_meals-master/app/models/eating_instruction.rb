class EatingInstruction < ApplicationRecord
    has_many :foods
end
