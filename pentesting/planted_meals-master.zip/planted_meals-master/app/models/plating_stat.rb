class PlatingStat < ApplicationRecord
  belongs_to :plating_guide
end
