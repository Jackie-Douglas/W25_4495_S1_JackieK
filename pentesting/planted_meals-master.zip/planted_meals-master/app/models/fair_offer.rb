class FairOffer < ApplicationRecord
  after_save :update_coupon_code
  validates :email, presence: true, 
                    uniqueness: true,
                    format: { with: URI::MailTo::EMAIL_REGEXP, message: "only allows valid emails" }

  def update_coupon_code
    coupon = generate_coupon
    self.update_columns(coupon_code: coupon.coupon_code)
  end

  def generate_coupon
    coupon = Coupon.new(coupon_data)
    coupon.save

    coupon
  end

  def coupon_data
    {
      coupon_code: "#{self.fair_name}-#{SecureRandom.hex(2)}",
      numbers_available: 1,
      discount_type: "%",
      discount_amount: 45.0,
      special: true
    }
  end
end
    
    

