class CutSize < ApplicationRecord
end
