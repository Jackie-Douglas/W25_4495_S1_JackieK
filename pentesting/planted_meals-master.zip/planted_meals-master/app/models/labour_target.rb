class LabourTarget < ApplicationRecord
  belongs_to :weekly_menu
end
