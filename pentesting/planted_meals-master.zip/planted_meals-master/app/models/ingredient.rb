class Ingredient < ApplicationRecord
  has_many :recipe_ingredients
  has_many :recipe, through: :recipe_ingredients
  has_many :vendor_ingredient_orders
  belongs_to :ingredient_category, optional: true
  belongs_to :ingredient_group, optional: true
  belongs_to :ingredient_location, optional: true 
  
  before_validation :update_total_on_hand
  before_validation :update_position

  validates :position, uniqueness: true
  validates :ingredient_category, presence: true

  def update_total_on_hand
    base_qty = self.base_qty.nil? ? 0 : self.base_qty
    on_hand  = self.on_hand.nil? ? 0 : self.on_hand

    self.total_on_hand = base_qty * on_hand
  end

  def update_position
    Ingredient.where("position >= ?", self.position).order(:position).update_all("position = position + 1") if self.position_changed?
  end
  
end
