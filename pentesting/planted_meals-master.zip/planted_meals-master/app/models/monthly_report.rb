class MonthlyReport < ApplicationRecord
  mount_uploader :oc_img, OcImgUploader
  mount_uploader :cogs_img, CogsImgUploader
end
