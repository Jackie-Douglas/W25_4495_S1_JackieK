class RecipeIngredient < ApplicationRecord
  belongs_to :recipe
  belongs_to :ingredient
  has_many :prep_tasks, dependent: :destroy

  before_validation :update_precut_percentage

  def update_precut_percentage
      self.precut_percentage = self.ingredient.precut_percentage
  end
end


