class ReferralTransaction < ApplicationRecord
    before_save :update_wallet_credit, :on => :create
    belongs_to :wallet
    

    def update_wallet_credit
        # check if the type is redeem or reward
        wallet = self.wallet
        current_credit = wallet.credit_amount.nil? ? 0 : wallet.credit_amount

        if self.transaction_type == "reward"
            # get previous credit and add
            credit_amount = self.credit_amount
            new_amount = current_credit + credit_amount
            # might need to put a condition where if it's nil make them zero
            wallet.update_columns(credit_amount: new_amount)
        else
            # get previous credit and add
            redeemed_amount = self.credit_amount
            new_amount = current_credit - redeemed_amount
            # might need to put a condition where if it's nil make them zero
            wallet.update_columns(credit_amount: new_amount)
        end

    end













end
