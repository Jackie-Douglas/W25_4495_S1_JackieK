class WageInformation < ApplicationRecord
  belongs_to :employee
end
