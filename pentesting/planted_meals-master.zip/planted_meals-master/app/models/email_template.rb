class EmailTemplate < ApplicationRecord
    belongs_to :weekly_menu
end
