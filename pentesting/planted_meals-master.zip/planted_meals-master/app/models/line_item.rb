class LineItem < ApplicationRecord
	scope :is_double_protein, -> { where(double_protein: true) }

	belongs_to :temp_order, optional: true
	belongs_to :food
	belongs_to :order, optional: true

	delegate :food_type, to: :food, prefix: false
	delegate :short_name, to: :food, prefix: false
	delegate :food_category_id, to: :food, prefix: false
	delegate :everyday_meals, to: :food, prefix: false


	before_validation :update_unit 
	before_validation :update_price


	def update_unit
		unit_for_line_item = self.food.unit
		self.unit = unit_for_line_item
	end

	def update_price 
		if temp_order
			price = self.food.wholesale_price
		else
			if !self.order.customer.nil?
				if self.order.customer.on_subscription
					if self.food.food_type == "meal"
						subscription_price = self.order.customer.subscription_price
						final_price = subscription_price.nil? ? self.food.retail_price : (self.food.discount_available ? subscription_price.price.to_f : self.food.retail_price)
					else
						final_price = self.food.retail_price
					end
	
					if !food.sale_price.blank?
						price = food.sale_price > final_price ? final_price : self.food.sale_price        
					else
						price = final_price
					end
	
				elsif !self.food.sale_price.blank?
					price = self.food.sale_price
				else
					price = self.food.retail_price
				end
			else
				if !self.food.sale_price.blank?
					price = self.food.sale_price
				else
					price = self.food.retail_price
				end
			end
		end

		self.price = price 
	end

end

