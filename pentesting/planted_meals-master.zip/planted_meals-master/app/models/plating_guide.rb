class PlatingGuide < ApplicationRecord
  has_one_attached :image

  belongs_to :food

  has_many :plating_stats
  has_many :plating_components

  accepts_nested_attributes_for :plating_components, allow_destroy: true
end
