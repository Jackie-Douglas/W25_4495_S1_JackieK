class Vendor < ApplicationRecord
	has_many :temp_orders
	belongs_to :user, optional: true

	after_save :update_email_on_user_model

	def address
		[shipping_address, shipping_city, shipping_province, shipping_country].compact.join(', ')
	end
end
