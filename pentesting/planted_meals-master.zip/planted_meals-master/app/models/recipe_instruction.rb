class RecipeInstruction < ApplicationRecord
  belongs_to :recipe
end
