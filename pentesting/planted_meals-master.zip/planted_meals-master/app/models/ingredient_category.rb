class IngredientCategory < ApplicationRecord
  has_many :ingredients
end
