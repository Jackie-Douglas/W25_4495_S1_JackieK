class IngredientInformation < ApplicationRecord
  belongs_to :plating_component
end
