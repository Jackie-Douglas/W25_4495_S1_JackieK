class Customer < ApplicationRecord
	belongs_to :delivery, optional: true
	belongs_to :user, required: false
	belongs_to :subscription_price, optional: true

	has_many :orders, dependent: :nullify
	has_many :coupon_usages
	has_many :coupons, through: :coupon_usages
	has_many :allergies, dependent: :destroy
	has_many :foods, through: :allergies
	has_many :food_reviews
	has_many :foods, through: :food_reviews
	
	has_one :stripe_info
	has_one :employee, dependent: :nullify 
	has_one :bag_tracker, dependent: :destroy
	
	accepts_nested_attributes_for :stripe_info
	accepts_nested_attributes_for :employee, reject_if: proc { |attributes| attributes['position'].blank? }
	accepts_nested_attributes_for :allergies

	geocoded_by :address
	after_validation :geocode
	before_validation :normalize_data
	before_validation :update_delivery_day
	after_save :update_email_on_user_model

	validates :first_name, presence: true
	validates :last_name, presence: true
	validates :email, presence: true, 
										format: { with: URI::MailTo::EMAIL_REGEXP, message: "only allows valid emails" }


	validates :phone,:presence => true,
								:numericality => true,
								:length => { :minimum => 10, :maximum => 15 }

	def address
		[shipping_address, shipping_city, shipping_province, shipping_country].compact.join(', ')
	end

	def normalize_data
		self.email = email.downcase if self.email
		self.shipping_address = shipping_address.downcase if self.shipping_address
		self.shipping_city = shipping_city.downcase.strip if self.shipping_city
		self.unit = unit.downcase if self.unit
		self.shipping_postal_code = shipping_postal_code.downcase.delete(' ') if shipping_postal_code != nil
	end

	def update_delivery_day
		case self.delivery_to
		when "office"
				self.delivery_day = "monday"
		when "pick up"
				self.delivery_day = "sunday"
		end
	end

	def full_name
		"#{self.first_name} #{self.last_name}" 
	end
end