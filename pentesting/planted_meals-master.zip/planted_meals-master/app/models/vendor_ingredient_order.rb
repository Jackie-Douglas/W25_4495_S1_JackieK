class VendorIngredientOrder < ApplicationRecord
  belongs_to :ingredient
end
