class Order < ApplicationRecord
  include ActionView::Helpers::NumberHelper
  scope :purchased_orders, -> { where(purchased: true) }

  belongs_to :customer, optional: true
  belongs_to :weekly_menu
  has_many :line_items, dependent: :destroy
  belongs_to :employee, optional: true
  accepts_nested_attributes_for :line_items

  validate :meal_count#, if: :no_thanks_giving_feast_is_selected
  validates :total_meal_count, presence: true
  before_validation :update_total_meal_count
  after_validation :update_subtotal

  def meal_count
    puts "false"
    count = sort_meals_to_snacks(self.line_items).map(&:quantity).sum

    subtotal_array = []
    
    self.line_items.each do |x|
      next if x.quantity == 0

      subtotal = x.quantity * x.price
      
      subtotal_array << subtotal.to_f
    end

    final_subtotal = subtotal_array.sum
    
    if one_time_purchase? && (final_subtotal < 20.0)
      errors.add(:total_meal_count, "Please add #{ number_to_currency(20 - final_subtotal) } to your order to meet our $20 minimum order value. Thank you!")
    elsif subscription? && (self.total_meal_count < 2)
      errors.add(:total_meal_count, "Please add #{2 - self.total_meal_count} more to your order to meet our minimum order quantity. Thank you!")
    # elsif subscription? && (count > subscription_meal_count)
    #     errors.add(:total_meal_count, "Please remove #{count - subscription_meal_count} meals")
    end
  end

  def no_thanks_giving_feast_is_selected

    thanks_giving_feast = self.line_items.map { |x| x if x.food_id == 144 }.compact
    quantity = thanks_giving_feast.map(&:quantity).first

    if quantity >= 1
      return false
    else
      return true
    end

  end

  private

  def one_time_purchase?
    purchase_type == "one time purchase"
  end

  def subscription?
    purchase_type == "subscription"
  end

  def update_total_meal_count
      update_nil_to_zero
      count = sort_meals_to_snacks(self.line_items).map(&:quantity).sum
      self.total_meal_count = count
  end

  def update_nil_to_zero
      self.line_items.each do |x|
        x.quantity = 0 if x.quantity.blank?
      end
  end

  def update_subtotal
    self.subtotal = Calculation::Subtotal.new(self).get_subtotal
  end
  
  def sort_meals_to_snacks(items)
    food_ids = items.map(&:food_id)
    meal_category_id = FoodCategory.find_by(name: "meal").id
    meal_ids = Food.where(id: food_ids).where(food_category_id: meal_category_id).ids

    items.select do |x|
      x if meal_ids.include?(x.food_id)
    end
  end

  


















end