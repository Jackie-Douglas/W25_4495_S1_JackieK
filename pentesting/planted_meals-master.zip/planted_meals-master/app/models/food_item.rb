class FoodItem < ApplicationRecord
    belongs_to :weekly_menu
    belongs_to :food
end
