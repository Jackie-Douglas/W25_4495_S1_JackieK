class Coupon < ApplicationRecord
	has_many :coupon_usages
	has_many :customers, through: :coupon_usages

	validates :coupon_code, uniqueness: :true
	validates :discount_amount, presence: :true

	before_validation :assign_uuid

	def assign_uuid
		self.uuid = SecureRandom.hex(12)
	end
end
