class ReferralMailer < ApplicationMailer
    default from: 'team@plantedmeals.ca'
    helper ApplicationHelper

    def referral_email
        @email = params[:email]
        @uuid = params[:uuid]
        @current_user = params[:current_user]
        @first_name = Referral.find_by(email: @email).first_name
        @weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
        meal_items
        
        mail(to: @email, subject: "Your Friend #{@current_user.customer.first_name.titleize} Wants You To Try Planted Meals!")
    end

    def referral_reminder_email
        @email = params[:email]
        @uuid = params[:uuid]
        @current_user = params[:current_user]
        @first_name = Referral.find_by(email: @email).first_name
        @weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
        meal_items

        mail(to: @email, subject: "Just A Friendly Reminder! Your Friend #{@current_user.customer.first_name.titleize} Wants You To Try Planted Meals!")
    end

    def meal_items
        @meals = @weekly_menu.food_items.where(food_id: Food.where(food_type: "meal"))
        .joins("LEFT JOIN foods ON foods.id = food_items.food_id")
        .select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions")
        .order("eating_order" => "ASC")
    end




end
