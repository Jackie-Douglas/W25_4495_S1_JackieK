class GiftCardMailer < ApplicationMailer
    default from: 'team@plantedmeals.ca'
    helper ApplicationHelper

    def gift_card_email
        @gift_card = params[:gift_card_info]
        @root_url = params[:root_url]
        to_email = @gift_card.to_email 
        
        mail(to: to_email, subject: "Your Friend #{@gift_card.from_first_name.titleize} Wants You To Send Gift Card For Planted Meals!")
    end

end
