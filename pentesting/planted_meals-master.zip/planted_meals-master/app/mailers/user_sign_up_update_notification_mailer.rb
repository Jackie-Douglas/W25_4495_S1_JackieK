class UserSignUpUpdateNotificationMailer < ApplicationMailer
    default from: 'Planted Meals <team@plantedmeals.ca>'

    def notification_email
        @temp_pass = params[:temp_pass]
        @email = params[:email]
        mail(to: @email, subject: "Please Update Your Account!")
    end

    def account_update_email
        @temp_pass = params[:temp_pass]
        @email = params[:email]
        mail(to: @email, subject: "Please Update Your Account!")
    end

end
