class ApplicationMailer < ActionMailer::Base
  helper :Application

  default from: 'from@example.com'
  layout 'mailer'

  def week_start
    Time.zone = "Pacific Time (US & Canada)"

    if after_cut_off_time
      Time.zone.today.next_week.beginning_of_week(:monday) + 1.week
    else
      Time.zone.today.next_week.beginning_of_week(:monday)
    end
  end

  def week_end
    Time.zone = "Pacific Time (US & Canada)"

    if after_cut_off_time
      Time.zone.today.next_week.end_of_week(:saturday) + 1.week
    else
      Time.zone.today.next_week.end_of_week(:saturday)
    end
  end

  def after_cut_off_time
    Time.zone = "Pacific Time (US & Canada)"

    current_time = Time.zone.now
    cut_off_date =  Time.zone.now.beginning_of_week(:monday) + 3.days
    year = cut_off_date.year
    month = cut_off_date.month
    day = cut_off_date.day

    cut_off_date_w_time = DateTime.new(year, month, day, 18, 0, 0)
    
    current_time > cut_off_date_w_time
  end

  def get_weekly_menu
      @weekly_menu = WeeklyMenu.find_by(week_start: week_start,  week_end: week_end)
  end

  def get_weekly_menu_for_admin
      Time.zone = "Pacific Time (US & Canada)"

      # if Time.zone.now >= Time.zone.parse('19:00:00')
      #   week_start = Time.zone.today.next_week.beginning_of_week(:monday) + 1.week
      #   week_end = Time.zone.today.next_week.end_of_week(:saturday) + 1.week
      # else
        week_start = Time.zone.today.next_week.beginning_of_week(:monday)
        week_end = Time.zone.today.next_week.end_of_week(:saturday)
      # end

      @weekly_menu = WeeklyMenu.find_by(week_start: week_start,  week_end: week_end)
  end

  

end
