class LabelMailer < ApplicationMailer
    default from: 'team@plantedmeals.ca'

    def send_email
        @label_type = params[:label_type].nil? ? "Order" : params[:label_type]
        @pdf_record_id = params[:pdf_record_id]
        email = Rails.env == "development" ? "mike.epiphany@gmail.com" : "team@plantedmeals.ca"

        mail(to: email, subject: "#{@label_type} label is ready to download")
    end
end
