class AutomationMailer < ApplicationMailer
    default from: 'team@plantedmeals.ca'
    

    def send_email
        email_template = EmailTemplate.find(params[:email_template_id])
        weekly_menu = EmailTemplate.find(params[:email_template_id]).weekly_menu
        @email = EmailTemplate.find(email_template.id)

        if Rails.env == "production"
            ActiveRecord::Base.transaction do
                weekly_menu.orders.where(purchased: true).each do |order|
                     email = order.customer.email
                     mail(to: email, subject: "Eating order for #{weekly_menu.week_start} - #{weekly_menu.week_end}")
                 end
                 email_template.update_columns(sent: true)
                 mail(to: "mike.epiphany@gmail.com", subject: "Eating order for #{weekly_menu.week_start} - #{weekly_menu.week_end}")
            end
        else
            ActiveRecord::Base.transaction do
                mail(to: "mike.epiphany@gmail.com", subject: "Eating order for #{weekly_menu.week_start} - #{weekly_menu.week_end}")
                email_template.update_columns(sent: true)
            end
        end
        
    end

end