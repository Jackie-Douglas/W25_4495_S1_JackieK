class NotificationMailer < ApplicationMailer
  default from: 'team@plantedmeals.ca'

  def fair_coupon_notification
    @fair_offer_information = params[:fair_offer_information]
    @coupon_code = @fair_offer_information.coupon_code
    to_email = @fair_offer_information.email
    @root_url = params[:root_url]
        
    mail(to: to_email, subject: "Here is your coupon code")
  end

  def weekly_food_review_notification
    order = Order.find(params[:order_id])
    @line_items = order.line_items.where.not(quantity: 0)
    to_email = order.customer.email

    mail(to: to_email, subject: "Enjoyed Your Meal? Let Others Know!")
  end
end
