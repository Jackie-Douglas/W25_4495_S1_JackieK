class PurchasedNotificationMailer < ApplicationMailer
    default from: 'team@plantedmeals.ca'

    def notification_email
        @customer_info = params[:customer_info]
        @order_info = params[:order_info]

        @weekly_menu = WeeklyMenu.find(@order_info.weekly_menu.id)
        
        subject = @customer_info.on_subscription ? "Subscription Order Submitted" : "One Time Order Purchased"

        if Rails.env == "production"
            mail(to: "order@plantedmeals.ca", subject: subject)
        else
            mail(to: "mike.epiphany@gmail.com", subject: subject)
        end
    end

end
