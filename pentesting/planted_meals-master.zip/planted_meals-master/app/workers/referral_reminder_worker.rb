class ReferralReminderWorker
    include Sidekiq::Worker

    def perform(uuid, email, current_user_id, weekly_menu_id)
        referee = Referral.find_by(email: email)
        user = User.find(current_user_id)
        
        return if referee.redeemed
        ReferralMailer.with(uuid: uuid, email: email, current_user: user, weekly_menu_id: weekly_menu_id).referral_reminder_email.deliver_now
    end

end