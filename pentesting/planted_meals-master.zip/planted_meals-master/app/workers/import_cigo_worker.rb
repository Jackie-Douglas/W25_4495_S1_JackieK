class ImportCigoWorker
    include Sidekiq::Worker

    def perform(weekly_menu_id)
        Delivery::ImportFromCigo.new(weekly_menu_id).call
    end


end