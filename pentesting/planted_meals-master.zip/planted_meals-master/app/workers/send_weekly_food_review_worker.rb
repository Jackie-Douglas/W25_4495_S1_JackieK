class SendWeeklyFoodReviewWorker
  include Sidekiq::Worker

  def perform(order_id)
    NotificationMailer.with(order_id: order_id).weekly_food_review_notification.deliver_now
  end
end
