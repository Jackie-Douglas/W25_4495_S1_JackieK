class SendEmailWorker
  include Sidekiq::Worker

  def perform(email_template_id)
    AutomationMailer.with(email_template_id: email_template_id).send_email.deliver_now
  end
end
