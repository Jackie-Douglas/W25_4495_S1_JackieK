class KlaviyoSendEventWorker
    include Sidekiq::Worker

    def perform(order_id)
        @order = Order.find(order_id)
        
        Klaviyo::SendEvent.new(@order).successful_purchase
    end
end