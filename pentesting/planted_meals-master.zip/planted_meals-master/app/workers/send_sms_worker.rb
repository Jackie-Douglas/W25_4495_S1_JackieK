class SendSmsWorker
  include Sidekiq::Worker
  sidekiq_options retry: false

  def perform(date, root_url)
    monday       = date.to_date
    sunday       = date.to_date.end_of_week
    date_range   = monday..sunday
    employee_ids = WorkSchedule.where(work_date: date_range).pluck(:employee_id).uniq
    
    employee_ids.each { |e| Twilio::SendScheduleText.new(e, root_url, monday, sunday).send_sms }
  end
end
