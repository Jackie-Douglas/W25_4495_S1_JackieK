class LabelWorker
    include Sidekiq::Worker

    def perform(opts={})
        orders = Order.where(id: opts["order_ids"])
        vendor_snack_orders = TempOrder.where(id: opts["vendor_snack_order_ids"])
        grouped_orders = grouped_orders(orders, "home office")
        grouped_other_orders = grouped_orders(orders, "other")
        label_type = opts["label_type"]

        if label_type == "snack"
            pdf = SnacksSheet.new(orders, vendor_snack_orders)        
        elsif label_type == "order"
            pdf = OrdersSheet.new(grouped_orders, orders, grouped_other_orders)
        end
        
        pdf_record = Pdf.create(pdf_text: pdf.render)

        LabelMailer.with(pdf_record_id: pdf_record.id, label_type: label_type).send_email.deliver_now
    end

    private

    def grouped_orders(orders, delivery_to)
        order_data = orders.joins(:customer).select("id", "customer_id", "total_meal_count", "weekly_menu_id", "customers.first_name", "customers.last_name", "customers.delivery_to",
                                                    "customers.shipping_postal_code", "customers.company_name", "customers.shipping_address", "customers.unit", "employee_id", "position")

        order_data = order_data.order(:employee_id)
        
        case delivery_to
        when "home office"
            # order_data.where("customers.delivery_to": ["home", "office"]).group_by(&:shipping_address)
            order_data.where("customers.delivery_to": ["home", "office"]).group_by { |x| [x.shipping_address, x.unit] }
        when "other"
            order_data.where.not("customers.delivery_to": ["home", "office"])
        end
        
    end
end