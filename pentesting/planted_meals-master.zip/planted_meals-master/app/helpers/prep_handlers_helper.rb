module PrepHandlersHelper

  def get_background_color_for_status(status)
    case status

    when "prep in progress"
      "pip"
    when "ready for processing"
      "rfp"
    when "processing in progress"
      "proip"
    when "finished"
      "fin"
    else
      "nt"
    end
  end 

  def find_employee_employee_task(prep_task_id, weekly_menu_id)
    employee_prep_task = EmployeePrepTask.find_by(prep_task_id: prep_task_id, weekly_menu_id: weekly_menu_id)

    employee_prep_task.nil? ? "" : (employee_prep_task.is_prioritize ? "prioritize" : "")
  end

  def get_group_border_colour(group_id)

    case group_id
    when 1
      "#e67c73"
    when 2
      "#f7cb4d"
    when 3
      "#41b375"
    when 4
      "#7baaf7"
    when 5
      "#ba67c8"
    end
  end

end

