module VendorDashboardsHelper

	def get_delivery_date(weekly_menu, day)
		week_start = weekly_menu.week_start
		week_end   = weekly_menu.week_end
		case day
		when "thu"
				format_date_for_display_w_year(week_start + 3.days)
		when "sun"
				format_date_for_display_w_year(week_end.end_of_week)
		when "mon"
				format_date_for_display_w_year(week_end.end_of_week + 1.day)
		end
	end

	def monday_cut_off_date
		Time.zone = "Pacific Time (US & Canada)"
		current_time = Time.zone.now
		cut_off_date =  Time.zone.now.beginning_of_week(:monday)

		year = cut_off_date.year
		month = cut_off_date.month
		day = cut_off_date.day
		cut_off_date_w_time = DateTime.new(year, month, day, 19, 59, 0).in_time_zone("Pacific Time (US & Canada)")
		
		current_time >= cut_off_date_w_time
	end

	def monday_delivery_available_date
		Time.zone = "Pacific Time (US & Canada)"

		if monday_cut_off_date
				Time.zone.now.next_week(:thursday)
		else
				@weekly_menu.week_start + 3.days - 1.week
		end
	end
    

	def wednesday_cut_off_date
		Time.zone = "Pacific Time (US & Canada)"
		current_time = Time.zone.now
		cut_off_date =  Time.zone.now.beginning_of_week(:wednesday)
		
		year = cut_off_date.year
		month = cut_off_date.month
		day = cut_off_date.day
		cut_off_date_w_time = DateTime.new(year, month, day, 4, 59, 0).in_time_zone("Pacific Time (US & Canada)")

		current_time > cut_off_date_w_time
	end

	def sun_mon_delivery_available_date
		Time.zone = "Pacific Time (US & Canada)"

		if wednesday_cut_off_date
				@weekly_menu.week_end.end_of_week - 1.week
		else
				@weekly_menu.week_end.end_of_week + 1.week
		end
	end

	def format_time_zone_and_display_with_day_for_delivery_date(date)
		date.strftime("%A, %B %d, %Y")
	end
end  



