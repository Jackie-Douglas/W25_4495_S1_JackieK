module IngredientsHelper

  def inventory_last_edited_time
    begin
      date_range = Date.today.beginning_of_week(:sunday).beginning_of_day..Date.today.beginning_of_week(:sunday).end_of_day
    rescue => exception
      date_range = Date.today.beginning_of_week(:wednesday).beginning_of_day..Date.today.beginning_of_week(:wednesday).end_of_day
    end

    Ingredient.where(updated_at: date_range).last.updated_at.in_time_zone("Pacific Time (US & Canada)").strftime("%b %d %a, %Y at %l:%m%p")
  end
end