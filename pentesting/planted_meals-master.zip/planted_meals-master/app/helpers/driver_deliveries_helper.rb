module DriverDeliveriesHelper
    
	def get_delivery_count(driver_id, weekly_menu_id)
		get_purchased_orders(weekly_menu_id).where(employee_id: driver_id).count
	end

	def get_vendor_delivery_count(driver_id, delivery_date)
		filtered_vendor_orders(delivery_date).where(employee_id: driver_id).count
	end

	def get_assigned_vendor_deliveries(driver_id, delivery_date)
		filtered_vendor_orders(delivery_date).where(employee_id: driver_id)
	end

	def get_unassigned_vendor_deliveries(delivery_date)
		filtered_vendor_orders(delivery_date).where(employee_id: nil).count
	end

	def display_delivery_week(weekly_menu_id)
		weekly_menu = WeeklyMenu.find(weekly_menu_id)
		week_start = format_date_for_display_w_year(weekly_menu.week_start)
		week_end = format_date_for_display_w_year(weekly_menu.week_end)
		
		"#{week_start} - #{week_end}"
	end

	def get_assigned_delivery_count(weekly_menu_id)
		get_purchased_orders(weekly_menu_id).where.not(employee_id: nil).count
	end

	def get_purchased_orders(weekly_menu_id)
		WeeklyMenu.find(weekly_menu_id).orders.where(purchased: true)
	end

	def get_remainding_delivery_count(weekly_menu_id)
		count = filtered_customer_orders(weekly_menu_id).count - get_assigned_delivery_count(weekly_menu_id)
		count = count <= 0 ? 0 : count
	end

	def get_vendor_delivery_days
		Time.zone = "Pacific Time (US & Canada)"

		mon_delivery_date = Time.zone.today.next_week.beginning_of_week(:monday)
		thu_delivery_date = mon_delivery_date - 4.days
		sat_delivery_date = mon_delivery_date - 1.days
	
		[thu_delivery_date, sat_delivery_date, mon_delivery_date]
	end
end