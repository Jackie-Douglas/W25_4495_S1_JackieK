module FoodItemsHelper
    def check_if_order_is_placed(weekly_menu_id, food_id)
        orders = get_orders(weekly_menu_id)
        order_ids = orders.pluck(:id)
        line_items = LineItem.where(order_id: order_ids, food_id: food_id).where("quantity > ?", 0)

        result = line_items.map do |x|
                    "#{x.order.customer.email}"
                end

        result = result.empty? ? "Are you sure?" : "We already have order from the following customers \n\n Email: #{result.join(", ")} \n\n Do you still want to remove the item?"

    end

    def get_orders(weekly_menu_id)
        Order.where(weekly_menu_id: weekly_menu_id, purchased: true)
    end

end