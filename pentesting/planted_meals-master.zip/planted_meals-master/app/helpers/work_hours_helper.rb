module WorkHoursHelper

    def work_hour(hour, min, am_or_pm)
        return if hour.nil?
        "#{hour}:#{sprintf("%02d", min)} #{am_or_pm}" 
    end

    def calculate_work_hour(record)
        sec = get_time_break_down_in_sec(record)

        if sec / 3600 >= 8
           seconds_to_hms((((3600 * 8)) .round))
            # time_worked = seconds_to_hms(sec.round)
        elsif sec / 3600 >= 5
            time_worked = seconds_to_hms(sec.round)
            # time_worked = seconds_to_hms(sec.round)
        else
            time_worked = seconds_to_hms(sec.round)
        end
        
    end

    def calculate_break_time(record)
				return 0 if record.break_time_start_hour.blank? && record.break_time_end_hour.blank?						

        start_hour = record.break_time_start_hour
        start_min = record.break_time_start_min
        start_am_or_pm = record.break_time_start_am_or_pm
        end_hour = record.break_time_end_hour.nil? ? 0 : record.break_time_end_hour
        end_min = record.break_time_end_min.nil? ? 0 : record.break_time_end_min
        end_am_or_pm = record.break_time_end_am_or_pm.nil? ? "AM" : record.break_time_end_am_or_pm

        start_time = Time.parse("#{start_hour}:#{start_min}#{start_am_or_pm}")
        end_time = Time.parse("#{end_hour}:#{end_min}#{end_am_or_pm}")
        

        sec = end_time - start_time
        # time_worked = seconds_to_hms(sec.round)
    end

    def calculate_work_hour_with_break(record)
        sec = get_time_break_down_in_sec(record)
				break_time_in_sec = calculate_break_time(record)
        
        time_worked = seconds_to_hms(sec.round - break_time_in_sec.round)
    end

    def calculate_over_time_hour(record)
        sec = get_time_break_down_in_sec(record)

        if sec / 3600 >= 8
            seconds_to_hms((sec - 28800).round)
        end
    end

    def get_time_break_down_in_sec(record)
        start_hour = record.start_hour
        start_min = record.start_min
        start_am_or_pm = record.start_am_or_pm
        end_hour = record.end_hour.nil? ? 0 : record.end_hour
        end_min = record.end_min.nil? ? 0 : record.end_min
        end_am_or_pm = record.end_am_or_pm.nil? ? "AM" : record.end_am_or_pm

        start_time = Time.parse("#{start_hour}:#{start_min}#{start_am_or_pm}")
        end_time = Time.parse("#{end_hour}:#{end_min}#{end_am_or_pm}")
        

        sec = end_time - start_time
    end

    def calculate_total_hours(record)
        work_hour = []
        
        begin
            record.second.each do |rr|
                sec = get_time_break_down_in_sec(rr)
                if sec / 3600 >= 8
                    work_hour << ((3600 * 8)).round
                    # work_hour << sec.round
                elsif sec / 3600 >= 5
                    # work_hour << sec.round + 1800
                    work_hour << sec.round
                else
                    work_hour << sec.round
                end
            end

            seconds_to_hms(work_hour.sum)
        rescue
            record.each do |rr|
                sec = get_time_break_down_in_sec(rr)
                if sec / 3600 >= 8
                    work_hour << ((3600 * 8)).round
                    # work_hour << sec.round
                elsif sec / 3600 >= 5
                    # work_hour << sec.round + 1800
                    work_hour << sec.round
                else
                    work_hour << sec.round
                end
            end

            seconds_to_hms(work_hour.sum)
        end
        

        
    end

    def calculate_total_ot_hours(record)
        ot_hour = []

        record.second.each do |rr|
            sec = get_time_break_down_in_sec(rr)

            ot_hour << ((sec - 28800).round) if sec / 3600 >= 8
        end
        seconds_to_hms(ot_hour.sum)
    end


    def seconds_to_hms(sec)
        return if sec.nil?
        [sec / 3600, sec / 60 % 60].map{|t| t.to_s.rjust(2,'0')}.join(':')
    end

end