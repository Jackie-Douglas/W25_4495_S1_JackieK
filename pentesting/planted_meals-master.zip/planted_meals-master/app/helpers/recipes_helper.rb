module RecipesHelper

  def units
    Ingredient.pluck(:unit).uniq
  end

  
end




