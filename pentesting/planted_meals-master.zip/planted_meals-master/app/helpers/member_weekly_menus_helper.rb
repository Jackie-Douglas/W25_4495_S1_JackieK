module MemberWeeklyMenusHelper

    def current_user_gift_card_needs_more_credit
        
    end

end