module ProductsHelper

    def discounted_price(coupon_id, order)
        product_price = order.subtotal
        product_price - discount_amount(coupon_id, order)
    end

    def discount_amount(coupon_id, order)

        coupon = Coupon.find_by(uuid: coupon_id)

        case coupon.discount_type
        when "$"
            coupon.discount_amount
        when "%"
            (discount_percentage(coupon_id) * discount_subtotal(order))
        end
    end

    def discount_percentage(coupon_id)
        coupon = Coupon.find_by(uuid: coupon_id)

        case coupon.discount_type
        when "$"
            coupon.discount_amount
        when "%"
            coupon.discount_amount.to_f / 100
        end
    end

    def humanize_date(date)
        if after_cut_off_time
            date = date + 1.week
            date.strftime("%B %d")
        else
            date.strftime("%B %d")
        end
    end

    def important_notice(string)
        "<u><span class='important-notice'>#{string}</span></u>".html_safe
    end

    def stripe_public_credentials
        Rails.env == "production" ? (root_url.include?("plantedmeals.io") ? "pk_test_XuBlFOo0Z4CrifqAEzO3oPJQ" : Rails.application.credentials.stripe_publish_key) : "pk_test_XuBlFOo0Z4CrifqAEzO3oPJQ"
    end

    def line_items_with_discount_column(order)
        line_items = order.line_items.joins(:food).select("id", "quantity", "name", "price", "food_id", "temp_order_id", "order_id", "foods.discount_available").where.not(quantity: 0)
    end

    def discount_subtotal(order)
        line_items = line_items_with_discount_column(order).where("foods.discount_available": true)
        calculate_subtotal(line_items)
    end

    def calculate_subtotal(line_items)
        line_items.inject(0) do |result, element|
            result + (element.quantity * element.price)
        end
    end


end

# get discount amount from availble and + by no discount