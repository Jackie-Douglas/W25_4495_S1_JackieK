module PlatingGuidesHelper

  def has_started?(weekly_menu_id, food_id, plating_guide_id)
    plating_stats = PlatingStat.find_by(weekly_menu_id: weekly_menu_id, food_id: food_id, plating_guide_id: plating_guide_id)

    plating_stats.nil?
  end

  def has_finished?(weekly_menu_id, food_id, plating_guide_id)
    plating_stats = PlatingStat.find_by(weekly_menu_id: weekly_menu_id, food_id: food_id, plating_guide_id: plating_guide_id)

    !plating_stats.end_time.nil?
  end

  def find_ingredient_information(plating_component, weekly_menu_id)
    plating_component.ingredient_informations.find_by(weekly_menu_id: weekly_menu_id)
  end

  def get_have_amount(plating_component, date)
    ingredients = plating_component.plating_ingredients
    prep_tasks  = RecipeIngredient.where(ingredient_id: ingredients.ids)
    date = date.to_date
    date_range = date + 3.days..date + 5.days
    weekly_menu_id = WeeklyMenu.find_by(week_start: date + 1.week, week_end: date + 1.week + 4.days).id

    final_amount = 0.0
    times        = 0.0

    plating_component.plating_ingredients.each do |i|
      if plating_component.mixed
        if !i.recipe_ingredient_id.nil?
          prep_task  = RecipeIngredient.find_by(ingredient_id: i.recipe_ingredient_id) 
          amount     = EmployeePrepTask.find_by(prep_task_id: prep_task.id, prep_date: date_range)&.actual_weight if !prep_task.nil?
        end
      else
        if i.cooked_method == "cooked"
          recipe_ingredient = RecipeIngredient.find(i.recipe_ingredient_id)
          prep_task         = recipe_ingredient.prep_tasks.first
          # order_count = get_weekend_total_order_count(prep_task.food_ref_id, EmployeePrepTask.find_by(prep_task_id: prep_task.id, prep_date: date_range).weekly_menu_id)  
          order_count = get_weekend_total_order_count(prep_task.food_ref_id, weekly_menu_id)  
          raw_amount      = order_count * recipe_ingredient.quantity.to_f

          
          

          calculate_cook_percentage_change_avg(i)

          final_amount += (raw_amount + (raw_amount * (calculate_cook_percentage_change_avg(i) / 100)).round(2))
          times        += (raw_amount / (raw_amount * (calculate_cook_percentage_change_avg(i) / 100)).round(2)).round(2)

        else
          if !i.recipe_ingredient_id.nil?
            prep_task  = RecipeIngredient.find(i.recipe_ingredient_id).prep_tasks.first
            amount = EmployeePrepTask.find_by(prep_task_id: prep_task.id, prep_date: date_range)&.actual_weight if !prep_task.nil?
            final_amount += amount.nil? ? 0 : amount
          end
        end
        
      end
    end
    
    "#{final_amount} #{times}"
  end

  def calculate_cook_percentage_change_avg(plating_ingredient)
    data = []

    recipe_ingredient = RecipeIngredient.find(plating_ingredient.recipe_ingredient_id)
    prep_task         = recipe_ingredient.prep_tasks.first

    EmployeePrepTask.where(prep_task_id: prep_task.id).each do |p|
      order_count = get_weekend_total_order_count(prep_task.food_ref_id, p.weekly_menu_id)  
      result      = order_count * recipe_ingredient.quantity.to_f

      cooked_amount = plating_ingredient.plating_component.ingredient_informations.where(weekly_menu_id: p.weekly_menu_id).first&.have&.to_f
      
      data << percentage_change(result, cooked_amount) if !cooked_amount.nil?
    end

    avg_percentage_change = data.inject{ |sum, el| sum + el }.to_f / data.size



    # weekly menu id
    #pre numbere comes from order amount of that week multiply by the recipe
    # I want to get pre and cooked number, come up with the difference in percentage and get avg
  end


end