module VendorDeliveriesHelper
  
  def is_checked?(order)
    order.checked ? "order-checked" : "order-not-checked"
  end
end
