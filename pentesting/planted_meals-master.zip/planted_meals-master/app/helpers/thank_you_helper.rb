module ThankYouHelper

  def calculate_delivery_day(order)
    today_date_with_time_zone.last_week(:sunday)..find_delivery_day(order) + 14.days
  end

  def is_today_or_delivery_day?(c, order)
    today = today_date_with_time_zone
    delivery_day = find_delivery_day(order)

    if today == c
      {
        date: "TODAY<br>#{format_date_for_display(c)}".html_safe,
        result: "today" 
      }
      
    elsif delivery_day == c
      pick_up_or_delivery = order.customer.delivery_to == "pick up" ? "Pick up" : "Delivery" 
      {
        date: "#{pick_up_or_delivery.upcase}<br>#{format_date_for_display(c)}".html_safe,
        result: "delivery day" 
      }
    else
      {
        date: format_date_for_display(c),
        result: false 
      }
    end
  end

  def filter_background(result)
    case result
    when "today"
      "today"
    when "delivery day"
      "delivery_day"
    when false
      ""
    end
  end

  def find_delivery_day(order)
    delivery_day = order.customer.delivery_day

    case delivery_day
    when "sunday"
      order.weekly_menu.week_start - 1.day
    when "monday"
      order.weekly_menu.week_start
    end
  end
end