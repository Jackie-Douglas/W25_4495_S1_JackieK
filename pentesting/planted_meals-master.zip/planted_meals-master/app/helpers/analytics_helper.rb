module AnalyticsHelper

	def get_total_meal_count
		start_date = Date.today.beginning_of_year
		end_date = Date.today + 1.week
		weekly_menu_ids = WeeklyMenu.where(week_start: start_date..end_date).ids
		Order.where(weekly_menu_id: weekly_menu_ids, purchased: true).sum(:total_meal_count)
	end

	def get_total_meal_count_previous_year
		start_date = Date.today.last_year.beginning_of_year
		end_date = Date.today.last_year + 1.week
		weekly_menu_ids = WeeklyMenu.where(week_start: start_date..end_date).ids
		Order.where(weekly_menu_id: weekly_menu_ids, purchased: true).sum(:total_meal_count)
	end

	def total_customer_orders_previous_year
		start_date = Date.today.last_year.beginning_of_year
		end_date = Date.today.last_year + 1.week
		weekly_menu_ids = WeeklyMenu.where(week_start: start_date..end_date).ids
		Order.where(weekly_menu_id: weekly_menu_ids, purchased: true).count
	end

	def total_customer_orders
		start_date = Date.today.beginning_of_year
		end_date = Date.today + 1.week
		weekly_menu_ids = WeeklyMenu.where(week_start: start_date..end_date).ids
		Order.where(weekly_menu_id: weekly_menu_ids, purchased: true).count
	end

	def get_total_number_of_subscribers
		start_date = Date.today - 4.weeks
		end_date = Date.today	
		date_range = start_date..end_date
		
		Customer.where(id: Order.where(purchased: true, created_at: date_range).pluck(:customer_id), on_subscription: true).count
	end

	def food_analytics
		order_ids = Order.where(purchased: true).ids 
		line_items = LineItem.where(order_id: order_ids).group("food_id").sum("quantity")
		hash = Hash.new

		line_items.each do |k, v|
			food = Food.find(k)
			next if food.food_type != "meal"
			next if food.availability == false
			food_item_count = FoodItem.where(food_id: k).count
			next if (food_item_count == 0 || food_item_count < 5)
			
			value = v / food_item_count.to_f

			hash[k] = value.round
		end

		sorted_hash = Hash[hash.sort_by{|k, v| v}.reverse]
	end

	def customer_meals(date_range, food_type)
		result = date_range.map do |date|
								range = date.beginning_of_month..date.end_of_month
								order_ids = Order.where(created_at: range, purchased: true).ids
								line_items = LineItem.where(order_id: order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where("foods.food_type": food_type).where.not(quantity: 0)
								count = line_items.sum(:quantity)
								revenue = line_items.pluck("SUM(quantity * price)")[0].to_f

								"<td>#{count}<br> #{number_to_currency(revenue)}</td>"
							end

		result.join(" ").html_safe
	end

	def customer_orders(date_range)
		result = date_range.map do |date|
								range = date.beginning_of_month..date.end_of_month
								previous_year_range = date.beginning_of_month.last_year..date.end_of_month.last_year
								previous_year_count = Order.where(created_at: previous_year_range, purchased: true).count
								count = Order.where(created_at: range, purchased: true).count
								change_in_percentage = percentage_change(previous_year_count, count)

								tag_condition = change_in_percentage.negative? ? 'fa-arrow-down' : 'fa-arrow-up'

								"<td>#{count} (#{previous_year_count}) <br> <span class='analytics-tag'><i class='fas #{tag_condition}'></i> #{change_in_percentage.round(2)}%</span> <span style= 'font-size: 12px'> VS. previous year</span></td>"
							end

		result.join(" ").html_safe
	end
	
	def total_customer_revenue(date_range)
		result = date_range.map do |date|
						   range = date.beginning_of_month..date.end_of_month
							 order_ids = Order.where(created_at: range, purchased: true).ids
							 line_items = LineItem.where(order_id: order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where.not(quantity: 0)
							 count = line_items.sum(:quantity)
							 revenue = line_items.pluck("SUM(quantity * price)")[0].to_f

							 "<td>#{number_to_currency(revenue)}</td>"
						 end

		result.join(" ").html_safe
	end

	def vendor_orders(date_range)
		result = date_range.map do |date|
								range = date.beginning_of_month..date.end_of_month
								previous_year_range = date.beginning_of_month.last_year..date.end_of_month.last_year
								previous_year_count = TempOrder.where(created_at: previous_year_range).count
								count = TempOrder.where(created_at: range).count
								change_in_percentage = percentage_change(previous_year_count, count)

								tag_condition = change_in_percentage.negative? ? 'fa-arrow-down' : 'fa-arrow-up'

								"<td>#{count} (#{previous_year_count}) <br> <span class='analytics-tag'><i class='fas #{tag_condition}'></i> #{change_in_percentage.round(2)}%</span> <span style= 'font-size: 12px'> VS. previous year</span></td>"
							end

		result.join(" ").html_safe
	end

	def vendor_meals(date_range, food_type)
		result = date_range.map do |date|
						  range = date.beginning_of_month..date.end_of_month
						  order_ids = TempOrder.where(created_at: range).ids
						  line_items = LineItem.where(temp_order_id: order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where("foods.food_type": food_type).where.not(quantity: 0)
						  count = line_items.sum(:quantity)
						  revenue = line_items.pluck("SUM(quantity * price)")[0].to_f
  
						  "<td>#{count}<br> #{number_to_currency(revenue)}</td>"
						 end

		result.join(" ").html_safe
	end

	def total_vendor_revenue(date_range)
		result = date_range.map do |date|
						 range = date.beginning_of_month..date.end_of_month
						 order_ids = TempOrder.where(created_at: range).ids
						 line_items = LineItem.where(temp_order_id: order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where.not(quantity: 0)
						 count = line_items.sum(:quantity)
						 revenue = line_items.pluck("SUM(quantity * price)")[0].to_f

						 "<td>#{number_to_currency(revenue)}</td>"
						end

		result.join(" ").html_safe
	end

	def customer_and_vendor_total_revenue(date_range)
		result = date_range.map do |date|
						 range = date.beginning_of_month..date.end_of_month
						 temp_order_ids = TempOrder.where(created_at: range).ids
						 order_ids = Order.where(created_at: range, purchased: true).ids 
						 vendor_line_items = LineItem.where(temp_order_id: temp_order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where.not(quantity: 0)
						 customer_line_items = LineItem.where(order_id: order_ids).joins(:food).select("id", "quantity", "price", "unit", "foods.food_type").where.not(quantity: 0)
						 vendor_revenue = vendor_line_items.pluck("SUM(quantity * price)")[0].to_f
						 customer_revenue = customer_line_items.pluck("SUM(quantity * price)")[0].to_f 
						 total_revenue = vendor_revenue + customer_revenue 

						 "<td>#{number_to_currency(total_revenue)}</td>" 
						 end

		result.join(" ").html_safe
	end

	def customer_source
		Customer.where.not(source: [nil, ""])
	end

	def grouped_customer_source
		customer_source.group(:source).count
	end

	def customer_source_other_information
		customer_source.where.not(other: [nil, ""]).order(:created_at => "DESC")
	end



	def customer_repeat_purchase_rate
		a = Customer.where(internal: false, on_subscription: false).joins(:orders).select("customers.id","orders.purchased", "count(orders.id) as order_counts").group("customers.id", "orders.purchased").having("count(orders.id) > 1 AND  purchased = true").length
    b = Customer.where(internal: false, on_subscription: false).joins(:orders).select("customers.id","orders.purchased", "count(orders.id) as order_counts").group("customers.id", "orders.purchased").having("count(orders.id) = 1 AND  purchased = true").length
    c = (a.to_f / (a + b)) * 100

    c.round(2)
	end

	def customer_avg_sale
		Order.where(purchased: true).sum(:subtotal).to_i / Order.where(purchased: true).count
	end


	def meal_count_render_partial_data(weekly_menus_search_result)
		internals = Customer.where(internal: true).ids

		total_array = []
		one_time_array = []
		subscription_array = []
		avg_cost_per_meal_array = [] 
		avg_cost_per_dish = []
		work_hours_array = []
		vendor_array = []
		labour_cost_perentage = []
		labour_goal_cost_percentage = []
		weekend_labour_cost_percentage = []
		weekend_labour_goal_cost_percentage = []
		weekend_ple = []
		order_count_array = []
		vendor_order_count_array = []

		# Information I need
		# 1. labour calculation of fri, sat, sun 
		# 2. total calculation of meals produced
		# 3. PLE and compare with the labour hours

        weekly_menus_search_result.each do |x|
          week_start = x.week_start - 1.week
          week_end = week_start.end_of_week

          date_range_for_vendor = (week_start)..week_end

          weekend_labour_date_range = (week_end - 2.days)..week_end

          orders = Order.where(weekly_menu_id: x.id, purchased: true).where.not(customer_id: internals)
          vendor_orders = TempOrder.where(cook_on: date_range_for_vendor)
          weekend_vendor_orders = TempOrder.where(cook_on: weekend_labour_date_range)

          subscription_meal_count = orders.where(charged_amount: nil).sum(:total_meal_count)
          one_time_purchase_meal_count =  orders.where.not(charged_amount: nil).sum(:total_meal_count)
          vendor_order_meal_count = LineItem.where(temp_order_id: vendor_orders.ids).sum(:quantity)
          weekend_vendor_order_meal_count = LineItem.where(temp_order_id: weekend_vendor_orders.ids).sum(:quantity)

          total_order_dollar_value = LineItem.where(order_id: orders.ids).sum("line_items.quantity * line_items.price").to_i
          total_vendor_order_dollar_value = LineItem.where(order_id: vendor_orders.ids).sum("line_items.quantity * line_items.price").to_i
          weekend_total_vendor_order_dollar_value = LineItem.where(order_id: weekend_vendor_orders.ids).sum("line_items.quantity * line_items.price").to_i
          total_sum_of_vendor_plus_order = total_order_dollar_value + total_vendor_order_dollar_value


        ####################Weekend Meals##############################
        total_sum_of_weekend_vendor_plus_order = total_order_dollar_value + weekend_total_vendor_order_dollar_value
        ###############################################################


        total_meal_count = orders.sum(:total_meal_count)
			
				avg_food_item_cost = LineItem.where(order_id: orders.ids).includes(:food).where("foods.food_type": "meal").average(:price).to_f
				
        total_charged_amount = orders.joins('LEFT OUTER JOIN coupon_usages on orders.id = coupon_usages.order_ref_id LEFT OUTER JOIN coupons on coupon_usages.coupon_id = coupons.id')
																		 .select("id", "subtotal", "total_meal_count", "charged_amount", "(charged_amount / 100) / 1.05 as charged_amount_beforetax", "discount_amount", "total_meal_count * #{avg_food_item_cost} as meal_count_cost", "((total_meal_count * #{avg_food_item_cost}) - (total_meal_count * #{avg_food_item_cost}) * discount_amount / 100) as meal_count_after_discount")
																		 .map.each do |x|
																				if x.meal_count_after_discount.nil?
																					x.meal_count_cost
																				else
																					x.meal_count_after_discount  
																				end
                               				end

        food_ids = x.food_items.pluck(:food_id)

        avg_cost_per_meal = total_charged_amount.sum.to_f / total_meal_count  
        avg_cost_per_food = Food.where(id: food_ids).where(food_type: "meal").average(:cost_per_dish)
				
				total_array << ["#{x.week_start} - #{x.week_end.end_of_week}", total_meal_count]
        
        one_time_array << ["#{x.week_start} - #{x.week_end.end_of_week}", one_time_purchase_meal_count]
        subscription_array << ["#{x.week_start} - #{x.week_end.end_of_week}", subscription_meal_count]
        vendor_array << ["#{x.week_start} - #{x.week_end.end_of_week}", vendor_order_meal_count]

        avg_cost_per_meal_array << ["#{x.week_start} - #{x.week_end.end_of_week}", (avg_cost_per_meal).round(2)]
        order_count_array << ["#{x.week_start} - #{x.week_end.end_of_week}", orders.count]
				vendor_order_count_array << ["#{x.week_start} - #{x.week_end.end_of_week}", vendor_orders.count]
        # avg_cost_per_dish << ["#{x.week_start} - #{x.week_end.end_of_week}", avg_cost_per_food.round(2)]

        ###################################################################################################
        meals = get_meals_w_food_category(x)


        kitchen_worker_ids = Employee.where(position: "cook").ids
        worked_hours = WorkHour.where(work_date: x.week_start - 1.week..(x.week_end - 1.week).end_of_week).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)
        

        weekend_worked_hours = WorkHour.where(work_date: weekend_labour_date_range).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)

        weekend_work_hour = []
        weekend_labour_cost = []

        weekend_worked_hours.each do |w|
        next if w.nil?
          sec = get_time_break_down_in_sec(w)
          weekend_work_hour << sec.round 
          
          worked_hour = sec / 3600
          rate = w.employee.customer.rate
          next if rate.nil? 
          total_rate = rate.to_i * worked_hour

          weekend_labour_cost << total_rate
        end

        work_hour = []
        labour_cost = []

        worked_hours.each do |w|
          sec = get_time_break_down_in_sec(w)
          work_hour << sec.round 
          
          worked_hour = sec / 3600
          rate = w.employee.customer.rate
          next if rate.nil? 
          total_rate = rate.to_i * worked_hour

          labour_cost << total_rate
        end

        calculated_ple = (calculate_add_info_for_weekly_menu(meals)[:average_ple].to_f / 30) * 100

        weekend_total_hours = (weekend_work_hour.sum) / 3600
        total_weekend_labour_cost_in_percentage = (weekend_labour_cost.sum / total_sum_of_weekend_vendor_plus_order) * 100 

        total_hours = (work_hour.sum) / 3600.00
        total_labour_cost_in_prcentage = (labour_cost.sum / total_sum_of_vendor_plus_order) * 100 
        
        work_hours_array << ["#{x.week_start} - #{x.week_end.end_of_week}", total_hours.round(2)]
        labour_cost_perentage << ["#{x.week_start} - #{x.week_end.end_of_week}", total_labour_cost_in_prcentage.round(2)]
        labour_goal_cost_percentage << ["#{x.week_start} - #{x.week_end.end_of_week}", 30]
        weekend_labour_cost_percentage << [x.week_end.end_of_week, total_weekend_labour_cost_in_percentage.round(2)]
        weekend_labour_goal_cost_percentage << [x.week_end.end_of_week, 30]
        weekend_ple << [x.week_end.end_of_week, calculated_ple.round(2)]

				
        end 

				{
					total_array: total_array,
					one_time_array: one_time_array ,
					subscription_array: subscription_array,
					avg_cost_per_meal_array: avg_cost_per_meal_array,
					# avg_cost_per_dish: avg_cost_per_dish,
					work_hours_array: work_hours_array,
					vendor_array: vendor_array,
					labour_cost_perentage: labour_cost_perentage,
					labour_goal_cost_percentage: labour_goal_cost_percentage,
					weekend_labour_cost_percentage: weekend_labour_cost_percentage,
					weekend_labour_goal_cost_percentage: weekend_labour_goal_cost_percentage,
					weekend_ple: weekend_ple,
					order_count_array: order_count_array
				}
	end

	def get_max_and_min(data)
		filtered_array = data.map(&:second)
		
		{
			min: filtered_array.min - 10,
			max: filtered_array.max + 10
		}
	end
end

      
        # 1. after what week a customer becomes a long term customer
        # 2. customer retention rate
        # 3. customer chrun rate
        # 4. Conversion rate 
        #     Website visitor -> Trial/demo -> paying customer
        # 5. MRR AVG meal count
        # get all monthly meal / number of month

        # 6. ARR = MRR * 12 
        # 7. Customer Life time value(CLV)
        #     1. Average Revenue Per Customer(ARPC or ARPU)
        #        MRR / number of customer = XX per month per customer
        #     2. 92 average x 20months = XX
        # 8. attrition or churn
        #     1. # of customers that cancel / total # of customers
        #     ex: 5 cancellations out of 100 total customers
        #         5 / 100 = 5% attrition
        #         1 / 0.5 = 20months

# ============================================================================
				#   customer_with_only_one_purchase_array = [] 
    #   customer_with_more_than_one_purchase_array = [] 

    # Customer.where(internal: false, on_subscription: false).each do |c|
    #   purchased_orders = c.orders.where(purchased: true).count

    #   if purchased_orders == 1
    #     customer_with_only_one_purchase_array << c.email
    #   elsif purchased_orders > 1
    #     customer_with_more_than_one_purchase_array << c.email
    #   end
    # end

    # one_time_purchase_customer = customer_with_only_one_purchase_array.count
    # repeat_purchase_customer = customer_with_more_than_one_purchase_array.count

    # repeat_purchase_rate = (repeat_purchase_customer.to_f / (one_time_purchase_customer + repeat_purchase_customer)) * 100 

    # repeat_purchase_rate = repeat_purchase_rate.round(2) 
    

    # Customer.where().each do |c|
      


    #   Customer.where(on_subscription: true)
    # end

   # how to find repeat purchases?

  #  Repeat rate = number of customers who have shopped more than once /  number of customers


# Customer.where(internal: false).joins(:orders)


  # aggregate order purchase

   #find first purchase and last purchase and if the date is greater than 1 month ago, consider them as dead?


