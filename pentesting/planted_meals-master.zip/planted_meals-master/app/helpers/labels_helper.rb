module LabelsHelper
  def self.send_data(orders, vendor_snack_orders)

    pdf = SnacksSheet.new(orders, vendor_snack_orders)
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'

                    
  end

  

end