module FoodsHelper

  def product_data(weekly_menus_search_result, food_id)
		customer_line_item_array = []
		vendor_line_item_array   = []

		weekly_menus_search_result.each do |x|
			customer_line_item_array << ["#{x.week_start}- #{x.week_end.end_of_week}", get_individual_item_for_customers(x, food_id)]
			vendor_line_item_array << ["#{x.week_start}- #{x.week_end.end_of_week}", get_individual_item_for_vendors(x, food_id)]
		end

    {
      customer_line_item_array: customer_line_item_array,
      vendor_line_item_array: vendor_line_item_array
    }
	end

	def get_individual_item_for_customers(weekly_menu, food_id)
		orders = Order.where(weekly_menu_id: weekly_menu.id, purchased: true).where.not(customer_id: Customer.where(internal: true).ids)
		line_items = LineItem.where(food_id: food_id, order_id: orders.ids).sum(:quantity)
	end

	def get_individual_item_for_vendors(weekly_menu, food_id)
		week_start = weekly_menu.week_start - 1.week
    week_end = week_start.end_of_week
		
		vendor_orders = TempOrder.where(cook_on: week_start..week_end)
		line_items = LineItem.where(food_id: food_id, temp_order_id: vendor_orders.ids).count
	end
end