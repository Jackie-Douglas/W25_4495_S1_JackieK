module WorkSchedulesHelper

  def get_scheduled_hours(date)
    work_scheduled = WorkSchedule.where(work_date: date)
    work_scheduled = work_scheduled.sum(:total_hours) 

    (work_scheduled * 3600).to_i
  end

  def get_total_scheduled_hours_for_single_employee(work_schedule_record)
    work_scheduled = work_schedule_record.total_hours
    
    (work_scheduled * 3600).to_i
  end

  def display_in_hours(hour)
    splited_array = hour.to_s.split(".")
    whole_number  = splited_array[0].to_f
    fac_number    = BigDecimal(splited_array[1].prepend(".")).to_f
    fac_number    = fac_number * 60 / 100

    (whole_number + fac_number)
  end

  def get_work_scheduled(date)
    work_scheduled = WorkSchedule.where(work_date: date)
  end

  def get_indi_work_schedule(date, id)
    WorkSchedule.find_by(work_date: date, employee_id: id)
  end

  def display_work_hour(date)
    date.in_time_zone('America/Vancouver').strftime("%I:%M %p")
  end

  def display_alert(target_number, scheduled_number)
    return if (target_number.nil? || scheduled_number.nil?)
    scheduled_number > target_number ? "no-go-text" : "go-text"
  end

  def get_actual_worked_hour(date, employee_id)
    worked_hour = WorkHour.find_by(work_date: date, employee_id: employee_id)

    if !worked_hour.nil?
      start_hour = work_hour(worked_hour.start_hour, worked_hour.start_min, worked_hour.start_am_or_pm) 
      end_hour   = work_hour(worked_hour.end_hour, worked_hour.end_min, worked_hour.end_am_or_pm)
  
      "#{start_hour} - #{end_hour}"
    end
  end

  def get_total_worked_hours_for_single_employee(date, employee_id)
    worked_hour = WorkHour.find_by(work_date: date, employee_id: employee_id)

    if !worked_hour.nil?
      sec = get_time_break_down_in_sec(worked_hour)
      total_work_hours = sec.round

      total_work_hours
    end
  end

  def is_current_week?(start_date, end_date)
    Date.today.between?(start_date, end_date)
  end

  def get_total_worked_hours(date)
    worked_hours = WorkHour.where(work_date: date)

    total_work_hours = []

    worked_hours.each do |x|
      sec = get_time_break_down_in_sec(x)
      if sec / 3600 >= 8
          total_work_hours << ((3600 * 8)).round
      elsif sec / 3600 >= 5
          total_work_hours << sec.round
      else
          total_work_hours << sec.round
      end
    end

    total_work_hours.sum
  end
end