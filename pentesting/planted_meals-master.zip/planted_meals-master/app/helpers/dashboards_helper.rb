module DashboardsHelper

	def calculate_vendor_snack(snack_type)
		begin
			food_id = Food.find_by(name: snack_type).id
			vendor_order_ids = TempOrder.where(cook_on: @weekly_menu.week_start - 1.day).ids
			items = LineItem.where(temp_order_id: vendor_order_ids, food_id: food_id).sum(:quantity)
		rescue
			return 0
		end
	end

	def get_vandor_snack_line_items(food_ids)
		begin
			vendor_order_ids = TempOrder.where(cook_on: @weekly_menu.week_start - 1.day).ids
			items = LineItem.where(temp_order_id: vendor_order_ids, food_id: food_ids).sum(:quantity)
		rescue
			return 0
		end
	end

	

	def get_mrr_from_profit_well
		header = { authorization: Rails.application.credentials.profitwell_authorization }
		response = HTTParty.get("https://api.profitwell.com/v2/metrics/monthly/", headers: header)
		parsed_json = JSON.parse(response.body)

		parsed_json.dig('data', 'existing_recurring_revenue')
	end

	def calculate_actual_quantity(grouped_food, line_items)
		if grouped_food[1] != nil
			foods_ids = grouped_food[1].map { |x| x.id }
		else
			foods_ids = grouped_food.id
		end
		
		filtered_line_items = line_items.where(food_id: foods_ids)
		quantity_array = filtered_line_items.map { |x| x.unit * x.quantity }
		final_quantity = quantity_array.inject(0, :+) + + get_vandor_snack_line_items(foods_ids)
	end

	def calculate_actual_quantity_wed(grouped_food, line_items)
		if grouped_food[1] != nil
			foods_ids = grouped_food[1].map { |x| x.id }
		else
			foods_ids = grouped_food.id
		end
		
		filtered_line_items = line_items.where(food_id: foods_ids)
		quantity_array = filtered_line_items.map { |x| x.unit * x.quantity }
		final_quantity = quantity_array.inject(0, :+)
	end

	def calculate_indi_quantity(food_id, line_items)
		filtered_line_items = line_items.where(food_id: food_id)
		customer_quantity = filtered_line_items.sum(:quantity)
		vendor_quantity   = get_vandor_snack_line_items(food_id) 

		{
			customer_quantity: customer_quantity,
			vendor_quantity: vendor_quantity,
			total: customer_quantity + vendor_quantity
		}
	end


end
