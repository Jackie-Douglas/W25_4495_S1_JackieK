module ApplicationHelper  

  def subdomain_resource
    "admin"
  end

  def titleize(string)
    string.titleize
  end

  def total_item_count(order)
    total_meal_count = order.line_items.sum(:quantity)
  end

  def nutritional_facts(data)
    {
      cal: data.kcal,
      p: data.protein,    
      c: data.carbohydrates,
      f: data.fat
    }
  end
  
  def get_delivery_day(delivery_to, home_delivery_day)
    
    case delivery_to
    when "home"
      home_delivery_day
    when "pick up"
      "N/A"
    when "office"
      "Monday"
    end
    
  end

  def free_delivery_applied
    "<span class='free-delivery-info'>Free Delivery Applied</span>".html_safe
  end

  def css_identifier(subdomain)
    case subdomain
    when "admin"
      "admin-layout"
    when  "portal"
      "portal-layout"
    end
  end 
  
  def gluten_wise_description
    "Please note unfortunately our kitchen is not completely gluten free and cross contamination may occur, but gluten is not an active ingredient in the gluten-wise dishes."
  end

  def gluten_wise_option_description
    "Switch to gluten wise item by clicking the check box down below"
  end

  def format_header_item_header(string)
    "<b>#{string}</b>"
  end

  def credit_card_type(card_type)
    if !card_type.blank?
      case card_type.downcase
      when "mastercard"
        '<i class="fab fa-cc-mastercard credit-card-icon"></i>'.html_safe
      when "visa"
        "<i class='fab fa-cc-visa credit-card-icon'></i>".html_safe
      end
    end
  end

  def get_full_name(first_name, last_name)
    "#{first_name} #{last_name}".titleize
  end

  def charge_details(order, customer)
    total_meal_count = order.total_meal_count.nil? ? order_meal_count(order) : order.total_meal_count
    delivery_fee = get_delivery_charge(total_meal_count, customer.delivery.fee)
    subtotal = delivery_fee + order.subtotal
    gst = subtotal + 0.05
    total = (subtotal + gst)

        "Order Summary<br>
         items (#{total_item_count(order)}): #{number_to_currency(order.subtotal)}<Br>
         Delivery: #{delivery_fee}<Br>
         <hr>
         Subtotal: #{subtotal}<br>
         Tax (GST 5%): #{gst}<Br>
         <h6 class='price-display'>Order Total: #{total}</h6>
        "
    end

    def delivery_form_error
      "delivery-form-error" if current_user.customer.delivery_id.nil?
    end

    def delivery_to_error
      "delivery-form-error" if current_user.customer.delivery_to.nil?
    end

    def format_date_for_display(date)
      date.strftime("%B %d")
    end

    def format_addres(customer)
      if customer.shipping_address.blank?
        nil
      else
      "#{customer.shipping_address.titleize}, #{customer.shipping_city.titleize}, #{customer.shipping_postal_code.upcase}"
      end
    end

    def format_vendor_addres(vendor)
      if vendor.shipping_address.blank?
        nil
      else
        "#{vendor.shipping_address.titleize}, #{vendor.shipping_city.titleize}, #{vendor.shipping_postal_code.upcase}"
      end
    end

    def filtered_customer_orders(weekly_menu_id)
      weekly_menu = WeeklyMenu.find(weekly_menu_id)
      pick_up_id = Delivery.find_by(delivery: "pick up").id
      pick_up_customers = Customer.where(delivery_id: pick_up_id).pluck(:id)
      employee_ids = Employee.pluck(:customer_id)
      combined_ids = employee_ids + pick_up_customers

      weekly_menu.orders.where(purchased: true).where.not(customer_id: combined_ids)
    end

    def get_meals_w_food_category(weekly_menu) 
      meal_category_id = FoodCategory.find_by_name("meal").id
      meals = weekly_menu.food_items.joins("LEFT JOIN foods ON foods.id = food_items.food_id")
              .select("id", "weekly_menu_id", "food_id", "quantity", "eating_order", "foods.name", "foods.food_category_id, foods.short_name")
              .order("eating_order" => "ASC").where("foods.food_category_id = #{meal_category_id}")
    end

    def terms_and_services_privacy_content
      "<p class='agreement-text'><i>By continuing, you agree to Planted Meal's <a href='https://www.plantedmeals.ca/terms-and-services.html' target='_blank'>Terms and Services</a> and <a href='https://www.plantedmeals.ca/privacy-policy.html' target='_blank'>Privacy Policy</a></i></p>"
    end

    def test_helper
      "hello"
    end

    def get_ltv(email)
      begin
        orders = Customer.find_by(email: email).orders.where(purchased: true)
        number_to_currency(orders.sum(:subtotal).to_f)
      rescue 
        0
      end
    end

    # Calculation

    def calculate_add_info_for_weekly_menu(meals)
      food_ids = meals.pluck(:food_id)
      foods = Food.where(id: food_ids)      
      weekly_menu_ids = meals.pluck(:weekly_menu_id)
      orders = Order.where(weekly_menu_id: weekly_menu_ids, purchased: true)
      
      average_ple = foods.average(:ple).to_f.round(2)
      average_food_cost = foods.average(:cost_per_dish).round(2)
      total_food_sold = orders.sum(:total_meal_count)

      {
        average_ple: average_ple,   
        average_food_cost: average_food_cost,
        total_food_sold: total_food_sold
      }
    end

    def get_day_in_words(day_in_short_form)
      case day_in_short_form
      when 'thu'
        "Thursday"
      when 'sun'
        "Sunday"
      when 'mon'
        "Monday"
      end
    end

    def gluten_wise_text
      "<span style='color: #8cd672'>GW. </span>".html_safe
    end

    def total_sum_of_vendor_and_orders(weekly_menu)
      week_start = weekly_menu.week_start - 1.week
      week_end = week_start.end_of_week

      internals = Customer.where(internal: true).ids
      orders = Order.where(weekly_menu_id: weekly_menu.id, purchased: true).where.not(customer_id: internals)

      # labour_date_range = (week_start + 4.days)..week_end
      labour_date_range = week_start..week_end
      vendor_orders = TempOrder.where(cook_on: labour_date_range)

      total_order_dollar_value = LineItem.where(order_id: orders.ids).sum("line_items.quantity * line_items.price").to_i
      total_vendor_order_dollar_value = LineItem.where(temp_order_id: vendor_orders.ids).sum("line_items.quantity * line_items.price").to_i

      total_sum_of_vendor_plus_order = total_order_dollar_value + total_vendor_order_dollar_value
    end

    def total_order_count_with_vendor(weekly_menu)
      week_start = weekly_menu.week_start - 1.week
      week_end = week_start.end_of_week

      internals = Customer.where(internal: true).ids
      orders = Order.where(weekly_menu_id: weekly_menu.id, purchased: true).where.not(customer_id: internals)

      labour_date_range = week_start..week_end
      vendor_orders = TempOrder.where(cook_on: labour_date_range)

      total_order_dollar_value = LineItem.where(order_id: orders.ids).sum("line_items.quantity").to_i
      total_vendor_order_dollar_value = LineItem.where(order_id: vendor_orders.ids).sum("line_items.quantity").to_i

      total_sum_of_vendor_plus_order = total_order_dollar_value + total_vendor_order_dollar_value
    end

    def labour_target_calculation(weekly_menu)
      labour_target_amount = total_sum_of_vendor_and_orders(weekly_menu) * (weekly_menu.labour_target_percentage / 100.0)

      total_labour_target = (labour_target_amount) / get_avg_hourly_value(weekly_menu)

      result = {
          thu: (total_labour_target * 0.35).round,
          fri: (total_labour_target * 0.3).round,
          sat: (total_labour_target * 0.35).round
      }


      # get the cost of items sold
      # average labour hour cost

      # get percentage of the total sold cost
      # friday == 9 %
      # saturday == 9 %
      # sunday == 12 % 
    end

    def actual_labour_percentage(weekly_menu)
      week_start = weekly_menu.week_start - 1.week
      week_end = week_start.end_of_week

      date_range = week_end - 3.days..week_end
      kitchen_worker_ids = Employee.where(position: "cook").ids
      worked_hours = WorkHour.where(work_date: date_range).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)

      work_hours = []

      worked_hours.each do |w|
          next if w.nil?
          sec = get_time_break_down_in_sec(w)
          work_hours << sec.round 
      end
      total_hours = (work_hours.sum) / 3600.00
      total_hours = total_hours.round

      actual = (((total_hours * 20.8)) / total_sum_of_vendor_and_orders(weekly_menu).to_f) * 100

      begin
        actual.round if !actual.nan?
      rescue
        0
      end
    end

    def get_avg_hourly_value(weekly_menu)
      kitchen_workers = Employee.where(position: "cook")

      wage = []

      kitchen_workers.each do |e|
        next if e.wage_informations.empty?

        if e.wage_informations.last.hourly
          wage << e.wage_informations.last.hourly
        else
          wage << (e.wage_informations.last.salary / 2080)
        end
      end
      
      result = (wage.sum(0.0) / wage.size)
    end


    
    def calculate_workhour_for_dashboard(date)
      kitchen_worker_ids = Employee.where(position: "cook").ids
      worked_hours = WorkHour.where(work_date: date).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)

      work_hours = []
      over_time_hours = []
      total_work_hours = []

      worked_hours.each do |w|
        next if w.nil?
        sec = get_time_break_down_in_sec(w)

        if (sec.round / 3600.00) > 8
          over_time = sec - (8 * 3600.00) 
          hour = sec - over_time

          over_time_hours << over_time
          work_hours << hour
        else 
          work_hours << sec
        end

        total_work_hours << sec
      end

      work_hours = (work_hours.sum) / 3600.00
      over_time_hours = (over_time_hours.sum) / 3600.00
      total_work_hours = (total_work_hours.sum) / 3600.00

      result = {
        work_hours: work_hours.round,
        over_time_hours: over_time_hours.round,
        total_work_hours: total_work_hours.round
      }
    end

    def calculate_workhours_for_managers(date)
      managers             = Employee.where(salary: true)
      manager_worked_hours = WorkHour.where(work_date: date).where(employee_id: managers.ids)

      worked_hours = []

      manager_worked_hours.each do |w|
        next if w.nil?
        sec = get_time_break_down_in_sec(w)

        worked_hours << sec
      end

      worked_hours = (worked_hours.sum) / 3600.00
      worked_hours.round
    end


    def number_of_staff_worked(date)
        kitchen_worker_ids = Employee.where(position: "cook").ids
        worked_hours = WorkHour.where(work_date: date).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)

        worked_hours.pluck(:employee_id).uniq.size
    end


    def calculate_over_time_hour(record)
        sec = get_time_break_down_in_sec(record)

        if sec / 3600 >= 8
            seconds_to_hms((sec - 28800).round)
        end
    end

    def admin?
      current_user.is_admin
    end

    # def calculate_workhour_for_dashboard(date)
    #     kitchen_worker_ids = Employee.where(position: "cook").ids
    #     worked_hours = WorkHour.where(work_date: date).where.not(employee_id: 10).where(employee_id: kitchen_worker_ids)

    #     work_hours = []
    #     over_time_hours = []

    #     worked_hours.each do |w|
    #         next if w.nil?
    #         sec = get_time_break_down_in_sec(w)

    #         if (sec.round / 3600) >= 8
    #           over_time_hours << sec.round
    #         else 
    #           work_hours << sec.round
    #         end
    #     end

    #     hours_without_overtime = (work_hours.sum) / 3600.00
    #     over_time_hours = (over_time_hours.sum) / 3600.00

    #    result = {
    #       hours_without_overtime: hours_without_overtime.round,
    #       over_time_hours: over_time_hours.round
    #     }
    # end

  def difference_in_percentage(v1, v2)
    result = ((v1 - v2).abs / ((v1 + v2) / 2).to_f).round(2) + 0.5
  end  

  def percentage_change(v1, v2)
    ((v2 - v1) / v1.to_f) * 100
  end

  def link_to_add_field(name, f, association)
    new_object = f.object.send(association).klass.new
    id = new_object.object_id

    fields = f.fields_for(association, new_object, child_index: id) do |builder|
      render(association.to_s.singularize + "_fields", f: builder)
    end

    link_to(name, "#", class: "add_fields", data: {id: id, fields: fields.gsub("\n", "")})
  end


  def is_recent_update?(time)
    time_difference = (Time.now - time) / 3600

    time_difference <= 48
  end


  def total_meal_count_sun
		date = @weekly_menu.week_start - 1.day
		vendor_orders = TempOrder.where(cook_on: date)
		vendor_order_ids = vendor_orders.ids
		line_items = LineItem.where(temp_order_id: vendor_order_ids)

		weekly_menu_food_items = []

		@weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << d.food_id
			end
		end

		result = {
			customer_orders: @orders.sum(:total_meal_count),
			vendor_orders: line_items.where(food_id: @vendor_menu.ids + weekly_menu_food_items).sum(:quantity),
			total_orders: @orders.sum(:total_meal_count) + line_items.where(food_id: @vendor_menu.ids + weekly_menu_food_items).sum(:quantity) + 35
		}
	end

  def vendor_menu_ids
    Food.where(vendor_menu: true, food_type: "meal").ids 
  end

  def total_meal_count_sun(weekly_menu)
		date = weekly_menu.week_start - 1.day
		vendor_orders = TempOrder.where(cook_on: date)
		vendor_order_ids = vendor_orders.ids
		line_items = LineItem.where(temp_order_id: vendor_order_ids)
		internals = Customer.where(internal: true).ids
    purchased_orders = weekly_menu.orders.where(purchased: true)

		weekly_menu_food_items = []

		weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << d.food_id
			end
		end

    buffer_count = weekly_menu_food_items.length * 5

		result = {
			customer_orders: purchased_orders.where.not(customer_id: internals).sum(:total_meal_count),
			internal_orders: purchased_orders.where(customer_id: internals).sum(:total_meal_count),
			vendor_orders: line_items.where(food_id: vendor_menu_ids + weekly_menu_food_items).sum(:quantity),
      buffer_count: buffer_count,
			total_orders: purchased_orders.sum(:total_meal_count) + line_items.where(food_id: vendor_menu_ids + weekly_menu_food_items).sum(:quantity) + buffer_count
		}
	end

  def get_weekly_vendor_meal_count(weekly_menu)
    date_range = get_weekly_cook_on_date_range(weekly_menu)
    vendor_orders = TempOrder.where(cook_on: date_range)
    vendor_order_ids = vendor_orders.ids
    line_items = LineItem.where(temp_order_id: vendor_order_ids)

    weekly_menu_food_items = []

    weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << d.food_id
			end
		end

    line_items.where(food_id: vendor_menu_ids + weekly_menu_food_items).sum(:quantity)
  end

  def get_item_counts_for_midweek(weekly_menu)
    date = weekly_menu.week_start - 5.day
		vendor_orders = TempOrder.where(cook_on: date)
    vendor_order_ids = vendor_orders.ids
    line_items = LineItem.where(temp_order_id: vendor_order_ids)

    weekly_menu_food_items = []

		weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << d.food_id
			end
		end

    result = {
			vendor_orders: line_items.where(food_id: vendor_menu_ids + weekly_menu_food_items).sum(:quantity)
		}
  end

  def ple_calc_for_single(weekly_menu, food_id)
    date = weekly_menu.week_start - 1.day
		vendor_orders = TempOrder.where(cook_on: date)
		vendor_order_ids = vendor_orders.ids
		line_items = LineItem.where(temp_order_id: vendor_order_ids)
    food = Food.find(food_id)
    internals = Customer.where(internal: true).ids
    purchased_orders = weekly_menu.orders.where(purchased: true)
    
    total_number_of_meals_made_for_single = LineItem.where(order_id: purchased_orders.ids, food_id: food_id).count 
    ple = food.ple

    weekly_menu_food_items = []

    buffer_count = weekly_menu_food_items.length * 5

		weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << d.food_id
			end
		end

    total_number_of_meals_made = purchased_orders.sum(:total_meal_count) + line_items.where(food_id: vendor_menu_ids + weekly_menu_food_items).sum(:quantity) + buffer_count

    (total_number_of_meals_made_for_single.to_f / total_number_of_meals_made) * ple.to_f
  end

  def ple_calc_for_weekly_menu(weekly_menu)
    weekly_menu_food_items = []

		weekly_menu.food_items.each do |d|
			food = Food.find(d.food_id)
			if food.food_type == "meal"
				weekly_menu_food_items << ple_calc_for_single(weekly_menu, d.food_id)
			end
		end

    weekly_menu_food_items.sum(0.0).round(2)
  end

  def dollar_display(hours, total_difference)
    hours.positive? ? number_to_currency((fri * 20.3) + (2450.00 * 0.35)) : number_to_currency((fri * 20.3) - (2450.00 * 0.35))
  end

  def display_hours_with_manger(staff_hour, manager_hour)
    staff_hour = staff_hour - manager_hour
    total_hour = staff_hour + manager_hour

    "#{staff_hour} + #{manager_hour}(M) = <b>#{total_hour}</b>".html_safe
  end

  def get_target_info(date)
    
    get_hours_target(date)

    case date.strftime("%A").downcase
    when "tuesday"
      { 
        hours_target: 0,
        staff_target: 0
      }
    when "wednesday"
      {
        hours_target: 0,
        staff_target: 0
      }
    when "thursday"
      {
        hours_target: 0,
        staff_target: 0
      }
    when "friday"
      hours_target = (get_hours_target(date)[:fri] - 48)

      {
        hours_target: hours_target * 3600,
        staff_target: hours_target / 8
      }
    when "saturday"
      hours_target = (get_hours_target(date)[:sat] - 38)
      {
        hours_target: hours_target * 3600,
        staff_target: hours_target / 8
      }
    end
  end

  def get_hours_target(date)
    date_range = date.last_year.beginning_of_month..date.last_year.end_of_month
    weekly_menus = WeeklyMenu.where(week_start: date_range)

    thu_array = []
    fri_array = []
    sat_array = []

    weekly_menus.each do |w|
      thu_array << labour_target_calculation(w)[:thu]
      fri_array << labour_target_calculation(w)[:fri]
      sat_array << labour_target_calculation(w)[:sat]
    end

    result = {
      thu: thu_array.sum / thu_array.size,
      fri: fri_array.sum / fri_array.size,
      sat: sat_array.sum / sat_array.size
    }
  end


  #=================== Recipe ingredient calculation method start =================================
  
  def get_need_ingredient_weight(record, date)
    recipe_ingredient   = record.prep_task.recipe_ingredient
    food                = recipe_ingredient.recipe.food
    base_q              = recipe_ingredient.quantity.to_f
    weekly_menu         = WeeklyMenu.find(record.weekly_menu_id)
    purchased_order_ids = weekly_menu.orders.purchased_orders
    buffer              = food.buffer

    if date == "weekday"
      vendor_cook_date    = weekly_menu.week_start - 5.day
      
      vendor_orders       = TempOrder.where(cook_on: vendor_cook_date)
      vendor_line_items   = LineItem.where(temp_order_id: vendor_orders.ids, food_id: food.id).sum(:quantity)

      total_orders        = vendor_line_items
    else
      vendor_cook_date    = weekly_menu.week_start - 1.day
      vendor_orders       = TempOrder.where(cook_on: vendor_cook_date)
      vendor_line_items   = LineItem.where(temp_order_id: vendor_orders.ids, food_id: food.id).sum(:quantity)
      regular_orders      = LineItem.where(order_id: purchased_order_ids, food_id: food.id).sum(:quantity)
      d_protein_orders    = LineItem.where(order_id: purchased_order_ids, food_id: food.id, double_protein: true).sum(:quantity)
      protein_recipe_id   = food.add_ons.first&.recipe_id
      d_protein_orders =  protein_recipe_id == recipe_ingredient.recipe_id ? d_protein_orders : 0 

      total_orders        = ((vendor_line_items + regular_orders) + buffer) + d_protein_orders
    end

    if record.custom_need_amount.nil?
      calculated_ing_amt  = base_q * total_orders
    else
      base_q * record.custom_need_amount
    end
    # calculated_ing_amt  = "#{number_with_delimiter(base_q * total_orders, :delimiter => ',')}#{recipe_ingredient.unit}"
  end
  
  # def get_total_need_ingredient_weight(ingredient_id, weekly_menu_id, unit)
  #   weekly_menu = WeeklyMenu.find(weekly_menu_id)
  #   purchased_order_ids = weekly_menu.orders.purchased_orders
  #   recipe_ingredients = RecipeIngredient.where(ingredient_id: ingredient_id)

  #   vendor_cook_date    = weekly_menu.week_start - 1.day
  #   vendor_orders       = TempOrder.where(cook_on: vendor_cook_date)

  #   food_ids                       = get_meals(weekly_menu.id).pluck(:food_id)
  #   vendor_food_ids                = Food.where(vendor_menu: true).pluck(:id)
  #   other_food_ids                 = get_everything_but_meals(weekly_menu.id).pluck(:food_id).uniq
    
  #   all_item_ids                   = food_ids + vendor_food_ids + other_food_ids
  #   all_recipe_ids                 = Recipe.where(food_id: all_item_ids.uniq)

  #   filtered_recipe_ingredients = recipe_ingredients.where(recipe_id: all_recipe_ids)
  #   filtered_recipes = Recipe.where(id: filtered_recipe_ingredients.pluck(:recipe_id))

  #   orders = LineItem.where(order_id: purchased_order_ids, food_id: filtered_recipes.pluck(:food_id)).sum(:quantity)

  #   data = []
  
  #   filtered_recipe_ingredients.each do |r|
  #     food_id = r.recipe.food_id
  #     orders = LineItem.where(order_id: purchased_order_ids, food_id: food_id).sum(:quantity)
  #     vendor_line_items = LineItem.where(temp_order_id: vendor_orders.ids, food_id: food_id).sum(:quantity)

  #     orders  = orders + vendor_line_items

  #     data << orders * r.quantity
  #   end

  #   if unit.downcase == "kg" || unit.downcase == "l"
  #     weight = data.sum.to_f / 1000
  #   elsif unit.downcase == "lbs"
  #     weight = data.sum.to_f / 453.6
  #   else
  #     weight = data.sum.to_f 
  #   end

  #   weight.round(2)
  # end

  def get_total_need_ingredient_weight(ingredient_id, weekly_menu_id, unit)
    weekly_menu = WeeklyMenu.find(weekly_menu_id)
    food_ids = weekly_menu.food_items.pluck(:food_id)
    all_recipe_ids = Recipe.where(food_id: food_ids).ids

    all_recipe_ingredients = RecipeIngredient.where(ingredient_id: ingredient_id, recipe_id: all_recipe_ids)

    data = []

    all_recipe_ingredients.each do |i|
      food_id = i.recipe.food_id
      custom_order_amount = weekly_menu.food_items.find_by(food_id: food_id).vendor_order_quantity

      data << (custom_order_amount.nil? ? 0 : custom_order_amount) * i.quantity
    end

    if unit.downcase == "kg" || unit.downcase == "l"
      weight = data.sum.to_f / 1000
    elsif unit.downcase == "lbs"
      weight = data.sum.to_f / 453.6
    else
      weight = data.sum.to_f 
    end

    weight.round(2)
  end


  #=================== Recipe ingredient calculation method end =================================

  def get_order_count(food_id, weekly_menu_id)
    # food                = record.recipe_ingredient_id.nil? ? record.food : record.recipe_ingredient.recipe.food
    food                = Food.find(food_id)
    weekly_menu         = WeeklyMenu.find(weekly_menu_id)
    purchased_order_ids = weekly_menu.orders.purchased_orders
    regular_orders      = LineItem.where(order_id: purchased_order_ids, food_id: food.id).sum(:quantity)

    d_protein_orders    = LineItem.where(order_id: purchased_order_ids, food_id: food.id, double_protein: true).sum(:quantity)
    
    # calculated_ing_amt  = "#{number_with_delimiter(base_q * total_orders, :delimiter => ',')}#{recipe_ingredient.unit}"
    regular_orders
  end

  def get_double_protein_count(food_id, weekly_menu_id)
    food                = Food.find(food_id)
    weekly_menu         = WeeklyMenu.find(weekly_menu_id)
    purchased_order_ids = weekly_menu.orders.purchased_orders
    
    d_protein_orders    = LineItem.where(order_id: purchased_order_ids, food_id: food.id, double_protein: true).sum(:quantity)
  end

  def get_vendor_order_count(food_id, weekly_menu_id)
    food                = Food.find(food_id)
    weekly_menu         = WeeklyMenu.find(weekly_menu_id)
    vendor_cook_date    = weekly_menu.week_start - 1.day
    vendor_orders       = TempOrder.where(cook_on: vendor_cook_date)
    vendor_line_items   = LineItem.where(temp_order_id: vendor_orders.ids, food_id: food.id).sum(:quantity)

    vendor_line_items
  end

  def week_day_get_vendor_order_count(food_id, weekly_menu_id)
    food                = Food.find(food_id)
    weekly_menu         = WeeklyMenu.find(weekly_menu_id)
    vendor_cook_date    = weekly_menu.week_start - 5.day
    vendor_orders       = TempOrder.where(cook_on: vendor_cook_date)
    vendor_line_items   = LineItem.where(temp_order_id: vendor_orders.ids, food_id: food.id).sum(:quantity)

    vendor_line_items
  end
  
  def get_weekend_total_order_count(food_id, weekly_menu_id)
    return 0 if food_id.nil?

    food           = Food.find(food_id)
    weekly_menu    = WeeklyMenu.find(weekly_menu_id)
    regular_orders = get_order_count(food.id, weekly_menu_id)
    vendor_orders  = get_vendor_order_count(food.id, weekly_menu_id)
    
    total_orders   = regular_orders + vendor_orders + food.buffer
  end

  def get_weekday_total_order_count(food_id, weekly_menu_id)
    return 0 if food_id == nil

    food           = Food.find(food_id)
    weekly_menu    = WeeklyMenu.find(weekly_menu_id)
    vendor_orders  = week_day_get_vendor_order_count(food.id, weekly_menu_id)
    
    total_orders   = vendor_orders
  end

  def get_total_order_count_for_plating(food_id, weekly_menu_id)
    return 0 if food_id == nil

    food           = Food.find(food_id)
    weekly_menu    = WeeklyMenu.find(weekly_menu_id)
    regular_orders = get_order_count(food.id, weekly_menu_id)
    vendor_orders  = get_vendor_order_count(food.id, weekly_menu_id)
    
    total_orders   = regular_orders + vendor_orders + get_buffer_count_for_dashboard(food.id)
  end

  # def get_buffer_count_for_prep(food_id)
  #   food   = Food.find(food_id)
  #   buffer = [21, 148, 152, 86, 195, 193, 40, 230].include?(food.id) ? 0 : ([151, 29, 147].include?(food.id) ? 15 : (food.food_type == "meal" ? 30 : 0) )
  # end

  # def get_buffer_count(food_id)
  #   food   = Food.find(food_id)
  #   buffer = food.id == 21 ? 0 : (food.food_type == "meal" ? 24 : 15)
  # end

  def get_buffer_count_for_dashboard(food_id)
    food   = Food.find(food_id)
    buffer = [274, 275].include?(food.id) ? 0 : 5
  end

  def get_specials(food_id, weekly_menu_id)
    # check if food weekly_menu_id food items food_id includes food id
    weekly_menu           = WeeklyMenu.find(weekly_menu_id)
    weekly_menu_food_ids  = weekly_menu.food_items.pluck(:food_id)

    return if !weekly_menu_food_ids.include?(food_id)

    customer_with_allergy = Allergy.where(food_id: food_id).pluck(:customer_id)
    special_order_ids     = weekly_menu.orders.purchased_orders.where(customer_id: customer_with_allergy)
    
    special_orders        = LineItem.where(order_id: special_order_ids, food_id: food_id)
    special_orders_dp     = special_orders.where(double_protein: true).sum(:quantity)

    {
      special_order_count: special_orders.sum(:quantity) - special_orders_dp,
      special_order_dp_count: special_orders_dp
    }

  end

  def get_specials_with_double_protein(food_id, weekly_menu_id)
    # check if food weekly_menu_id food items food_id includes food id
    weekly_menu           = WeeklyMenu.find(weekly_menu_id)
    weekly_menu_food_ids  = weekly_menu.food_items.pluck(:food_id)

    return if !weekly_menu_food_ids.include?(food_id)

    customer_with_allergy = Allergy.where(food_id: food_id).pluck(:customer_id)
    special_order_ids     = weekly_menu.orders.purchased_orders.where(customer_id: customer_with_allergy)
    
    special_orders_with_double_protein = LineItem.where(order_id: special_order_ids, food_id: food_id, double_protein: true)
  end

  def get_gluten_wise(food_id, weekly_menu_id)
    weekly_menu           = WeeklyMenu.find(weekly_menu_id)
    weekly_menu_food_ids  = weekly_menu.food_items.pluck(:food_id)

    return if !weekly_menu_food_ids.include?(food_id)

    LineItem.where(order_id: weekly_menu.orders.purchased_orders.ids, food_id: food_id, gluten_wise_option: true).sum(:quantity)
  end
  
  def get_double_protein(food_id, weekly_menu_id)
    weekly_menu           = WeeklyMenu.find(weekly_menu_id)
    weekly_menu_food_ids  = weekly_menu.food_items.pluck(:food_id)

    return if !weekly_menu_food_ids.include?(food_id)

    LineItem.where(order_id: weekly_menu.orders.purchased_orders.ids, food_id: food_id, double_protein: true).sum(:quantity)
  end

  def get_double_plus_gluten_wise(food_id, weekly_menu_id)
    weekly_menu           = WeeklyMenu.find(weekly_menu_id)
    weekly_menu_food_ids  = weekly_menu.food_items.pluck(:food_id)

    return if !weekly_menu_food_ids.include?(food_id)

    LineItem.where(order_id: weekly_menu.orders.purchased_orders.ids, food_id: food_id, double_protein: true, gluten_wise_option: true).sum(:quantity)
  end

  def display_ingredient_weight(weight)
    number_with_delimiter(weight, :delimiter => ',')
  end

  def calculate_missing_ingredient_weight(actual_weight, need_weight)
    if actual_weight && need_weight
      missing_weight = actual_weight - need_weight
      missing_weight.negative? ? "<i><h6>Missing #{display_ingredient_weight(missing_weight.abs)}</h6></i>".html_safe : ""
    end
  end

  def get_prep_icon?(record)
    icon = ""

    record.veggie_station ? (icon += '<i class="fas fa-carrot green"></i>') : ""
    record.sauce_station ? (icon += '<i class="fas fa-utensil-spoon red"></i>') : ""
    record.cook_station ? (icon += '<i class="fas fa-wine-bottle orange"></i>') : ""

    icon.html_safe
  end

  def display_prep_task(record)
    result = ""

    record.station ? (result += record.station + ")") : ""
    record.name ? (result += " " + record.name) : ""
    record.machine_required ? (result += " " + record.machine_required) : ""
    record.cut_method ? (" " + result += " " + record.cut_method) : ""
    record.size ? ( result += " " + record.size) : ""

    result.titleize
  end

  def display_in_packs(record, need_ingredient_weight)
    if record.is_pack
      pack_required = (need_ingredient_weight / record.pack_base_qty).round(1)
      box_number    = (pack_required / 12).round(1)

      "<span class='btn btn-info btn-sm'><i><b>#{pack_required} packs | #{box_number} boxes</b></i></span>".html_safe
    end
  end

  def display_in_packs_for_sauce(record, need_ingredient_weight)
    if record.is_pack
      pack_required = (need_ingredient_weight / record.pack_base_qty).round(1)
      box_number    = (pack_required / 12).round(1)

      "<span class='display-pack-sauce-tag'><i>#{pack_required} pk | #{box_number} bx</i></span>".html_safe
    end
  end

  def get_progress_status(status, weekly_menu_id, station)
    # count = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("recipe_ingredients.#{station}_station": true).where(weekly_menu_id: weekly_menu_id, status: status).count

    # if station == 'sauce'
    #   food_ids = WeeklyMenu.find(weekly_menu_id).food_items.pluck(:food_id)
    #   sauce_count = PrepTask.joins(:employee_prep_tasks).where(station: station, food_id: food_ids).where("employee_prep_tasks.status": status, "employee_prep_tasks.weekly_menu_id": weekly_menu_id).count
    #   # prep_task_ids = (prep_tasks.where(station: "sauce", food_id: food_ids) + PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": food_ids, station: station)).pluck(:id)
    #   sauce_count + count
    # else
    #   count
    # end
    @prep_date_range = get_prep_date_range

    if station == "veggie"
      employee_prep_tasks = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("recipe_ingredients.veggie_station": true).where(weekly_menu_id: weekly_menu_id, prep_date: @prep_date_range, status: status).count
    else
      @employee_prep_tasks = EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: weekly_menu_id, prep_date: @prep_date_range, status: status).where("prep_tasks.station": station).count

      # prep_tasks = PrepTask.where(station: station)
      # required_food_ids = get_meals(weekly_menu_id).pluck(:food_id) + get_everything_but_meals(weekly_menu_id).pluck(:food_id)
      # prep_tasks_without_ingredients = prep_tasks.where(station: station, food_id: required_food_ids).joins(:employee_prep_tasks).where("employee_prep_tasks.status": status, "employee_prep_tasks.weekly_menu_id": weekly_menu_id).count
      # prep_tasks_with_ingredients = PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": required_food_ids, station: station).joins(:employee_prep_tasks).where("employee_prep_tasks.status": status, "employee_prep_tasks.weekly_menu_id": weekly_menu_id).count

      # prep_tasks_without_ingredients + prep_tasks_with_ingredients
    end


    
  end

  def get_progress_status_for_indi(status=nil, weekly_menu_id, employee_id)
    @prep_date_range = get_prep_date_range

    status_count = EmployeePrepTask.where(weekly_menu_id: weekly_menu_id, status: status, employee_id: employee_id, prep_date: @prep_date_range).count
    total_count = EmployeePrepTask.where(weekly_menu_id: weekly_menu_id, employee_id: employee_id, prep_date: @prep_date_range).count 

    result = {
      status_count: status_count,
      total_count: total_count
    }
  end

  def other_prep_tasks(station, weekly_menu_id, date)

    
    @prep_date_range = get_prep_date_range

    prep_tasks = PrepTask.where(station: station)

    if date == "weekday"
      
      EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: weekly_menu_id, prep_date: @prep_date_range).where("prep_tasks.station": station)
      
      required_food_ids = Food.where(vendor_menu: true, food_type: "meal").pluck(:id).uniq
      prep_tasks = prep_tasks.where(station: station, food_id: required_food_ids) + PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": required_food_ids, station: station) + PrepTask.where(id: EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: weekly_menu_id, prep_date: @prep_date_range).where("prep_tasks.station": station).pluck(:prep_task_id))


      prep_tasks.uniq.sort { |a, b| a.food_ref_id <=> b.food_ref_id}
    else
      # EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: weekly_menu_id, prep_date: @prep_date_range)

      required_food_ids = (get_meals(weekly_menu_id).pluck(:food_id) + get_everything_but_meals(weekly_menu_id).pluck(:food_id) + @vendor_menu = Food.where(vendor_menu: true, food_type: "meal").pluck(:id)).uniq
      prep_tasks = prep_tasks.where(station: station, food_id: required_food_ids) + PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": required_food_ids, station: station)
  
      prep_tasks.sort { |a, b| a.food_ref_id <=> b.food_ref_id}
    end
  end

  def get_all_prep_tasks(date, weekly_menu_id, food_id)

    if date.to_date.on_weekday?
      required_food_ids = Food.where(vendor_menu: true, food_type: "meal").pluck(:id).uniq
      prep_tasks = PrepTask.where(food_ref_id: food_id)

      prep_tasks.sort { |a, b| a.food_ref_id <=> b.food_ref_id} 
    else
      required_food_ids = (get_meals(weekly_menu_id).pluck(:food_id) + get_everything_but_meals(weekly_menu_id).pluck(:food_id) + Food.where(vendor_menu: true, food_type: "meal").pluck(:id)).uniq
      prep_tasks = PrepTask.where(food_id: required_food_ids) + PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": required_food_ids)
  
      prep_tasks.sort { |a, b| a.food_ref_id <=> b.food_ref_id}
    end
  end

  def get_bag_division(food_id)
    if [29, 147, 151, 134].include?(food_id)
      18.0
    elsif [237, 233, 130].include?(food_id)
      12.0
    elsif [264].include?(food_id)
      15.0
    else
      12.0
    end
  end

  def vendor_order_status(week, vendor_id)
    
    if week == "weekday"
      cook_date = Date.today.beginning_of_week + 2.days
    elsif week == "weekend"
      cook_date = Date.today.end_of_week
    end

    {
      order: Vendor.find(vendor_id).temp_orders.find_by(cook_on: cook_date, everyday_meals: true),
      cook_date: cook_date
    }

    
  end

  #=========================================Layout CSS methods start==================================================#

  def headings_on_index_layout(heading)
    "<h1>#{heading}<h1>".html_safe
  end

  #=========================================Layout CSS methods end==================================================#


end















