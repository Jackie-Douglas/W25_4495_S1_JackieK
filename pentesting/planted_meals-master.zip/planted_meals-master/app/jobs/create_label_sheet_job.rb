class CreateLabelSheetJob < ApplicationJob
  queue_as :default

  def perform(grouped_orders, orders, grouped_other_orders)

      # orders = Order.where(id: order_ids)
      # vendor_snack_orders = TempOrder.where(id: vendor_snack_order_ids)

    # pdf = SnacksSheet.new(orders, vendor_snack_orders)
    #                 send_data pdf.render,
    #                 filename: "export.pdf",
    #                 type: 'application/pdf',
    #                 disposition: 'inline'

    # pdf = SnacksSheet.new(orders, vendor_snack_orders)


    # save_path = Rails.root.join("public", "issue835.pdf")

    # Don't regenerate the file if it already exists
    # return if File.exist?(save_path)

    # Render template as PDF
    # pdf_contents = ApplicationController.render(
    #   pdf: pdf.render
    # )

    # Simulate slow PDF generation
    # This saves the PDF to disk, but could put in the DB,
    # upload with ActiveStorage, attach to email, etc...
    
    # File.open(save_path, 'wb') { |file| file << pdf.render }
    
    # LabelMailer.send_email.deliver_now

    # pdf = OrdersSheet.new(@grouped_orders, @orders, @grouped_other_orders)
    #                 send_data pdf.render,
    #                 filename: "export.pdf",
    #                 type: 'application/pdf',
    #                 disposition: 'inline'
    #             end
  end



end