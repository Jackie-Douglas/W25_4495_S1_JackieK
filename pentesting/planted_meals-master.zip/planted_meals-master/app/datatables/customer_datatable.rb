class CustomerDatatable < ApplicationController
    delegate :params, to: :@view
    include ActionView::Helpers::NumberHelper
    
    def initialize(view)
        @view = view
    end

    def as_json(options = {})
        {
            recordsTotal: count,
            recordsFiltered: total_entries,
            data: data
        }
    end

    private

    def page
        params[:start].to_i / per_page + 1
    end

    def per_page
        params[:length].to_i > 0 ? params[:length].to_i : 10
    end

    def data
        customers.map do |customer|
            phone = customer.phone.nil? ? "" : ('<i class="fas fa-phone"></i> ' + number_to_phone(customer.phone))
            subscriber = customer.on_subscription? ? ("<span class='sub-icon'>Subscriber<s/pan>") : " "
            
            [].tap do |column|
                column << (customer.user.nil? ? ('<a class="btn btn-danger" data-method="post" href="/users/custom_user_create?customer_id=' + customer.id.to_s + '">' + 'create' + '</a>') : ('<a class="btn btn-success" data-method="post" href="/users/' + customer.user.id.to_s + '/impersonate" >' + "Login" + '</a>'))
                column << customer.id
                column << "#{customer.first_name} #{customer.last_name}" + '<br>' + subscriber
                column << '<i class="fas fa-at"></i> ' + customer.email + '<br>' + phone
                column << (customer.stripe_info.nil? ? "No" : (customer.stripe_info.default_source.blank? ? "No" : "Yes"))
                column << Order.where(customer_id: customer.id, purchased: true).count
                column << format_date_for_display_w_year(customer.created_at)
                column << '<a href="/customer/' + customer.id.to_s + '/edit" >' + "Edit" + '</a>' + '<br>' + '<a href="/admin_orders/new?customer_id=' + customer.id.to_s + '" >' + "New Order" + '</a>' + 
                          '<br>' + '<a href="/delete_customer/' + customer.id.to_s + '" data-confirm="are you sure" data-method="delete">Delete</a>' + '<br>' + '<a href="/customers/' + customer.id.to_s + '/allergies/new">' + "Add Allergies" + "</a>" + '<br>' +
                          ( customer.allergies.empty? ? "" : '<a href="/customers/' + customer.id.to_s + '/allergies">' + "All Allergies" + "</a>")

            end
        end
    end

    def count
        User.count
    end

    def total_entries
        customers.total_entries
    end

    def customers
       @customers ||= fetch_users 
    end

    def fetch_users
        search_string = []
        columns.each do |term|
            search_string << "#{term} ilike :search"
        end


        customers = Customer.where.not(email: nil).page(page).per_page(per_page)
        customers = customers.where(search_string.join(' or '), search: "%#{params[:search][:value]}%")
    end

    def columns
        %w(first_name last_name email)
        
    end

end

