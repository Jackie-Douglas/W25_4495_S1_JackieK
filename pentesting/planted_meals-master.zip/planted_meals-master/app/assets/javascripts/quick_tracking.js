$(document).on("turbolinks:load", function () {

    $("#subscription-choose-btn").on('click', function () {
        Rails.ajax({
            url: "/tracking",
            type: "POST",
            data: "subscription-choose-btn",
            success: function (data) {
                console.log("complete")
            },
            error: function (data) {

            }
        })
    });

    $("#inquery-choose-plan").on('click', function () {
        Rails.ajax({
            url: "/tracking",
            type: "POST",
            data: "subscription-inqury-btn",
            success: function (data) {
                console.log("complete")
            },
            error: function (data) {

            }
        })
    });

    $("#one-time-choose-btn").on('click', function () {
        Rails.ajax({
            url: "/tracking",
            type: "POST",
            data: "one-time-choose",
            success: function (data) {
                console.log("complete")
            },
            error: function (data) {

            }
        })
    });




    

});