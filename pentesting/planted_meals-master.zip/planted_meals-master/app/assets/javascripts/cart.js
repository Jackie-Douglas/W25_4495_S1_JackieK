$(document).on("turbolinks:load", function () {
    let counter = []
    
    $(".input-group-button").on("click", function() {
        let foodId   = $(this).parents('.menu-item-card').data('food-id');
        let imageSrc = $(this).parents(".card").children('.menu-form-img').attr("src");
        let foodName = $(this).parents('.menu-item-card').find('.card-title')[0].innerText.trim();
        let foodQuantity = $(this).parent('.input-number-group').find('input').val()
        let foodIdInTheCart = $("#cart").find("#" + foodId)
        counter.push(parseInt(foodQuantity))
        let totalSum = counter.reduce(function(a,b) {
        return a + b
        }, 0)


        console.log(counter);
        console.log(totalSum);

        if(foodIdInTheCart.length == 1) {
            // find the food id and change the value
            let newQuantity = `X ${foodQuantity}`
            foodIdInTheCart.find('.cart-food-quantity').html(newQuantity)
        } else {
            // if not add html

            let foodItem = `<div id='${foodId}' class="d-flex align-items-center my-cart-item">
                                <div>
                                    <img class="cart-food-image add-box-shadow" src="${imageSrc}" />
                                </div>
                                <div class="cart-food-name"> 
                                    ${foodName}
                                </div>
                                <div class="cart-food-quantity">
                                    X ${foodQuantity}
                                </div>
                            </div>`


            console.log("no")
            $("#cart .cart-card-body").append(foodItem)
        }
    });



});
