$(document).on("turbolinks:load", function() {

    $(".choose-delivery-radio-btn-div input[type='radio']:checked").closest('.box').addClass("redBackground")
    $(".choose-delivery-radio-btn-div input[type='radio']:checked").siblings("span").css("color", "#fff"); 

    var delivery_type  = $(".choose-delivery-radio-btn-div input[type='radio']:checked").val()

    if (delivery_type == "office") {
        $(".delivery-home").hide()
        $(".pick-up").hide()
        $(".delivery-day-div").hide();
        $(".pick-up-input").prop('disabled', true)
        $(".home-input").prop('disabled', true)
    } else if (delivery_type == "home") {
        $(".delivery-office").hide()
        $(".pick-up").hide()
        $(".company-name-div").hide();
        $(".pick-up-input").prop('disabled', true)
        $(".office-input").prop('disabled', true)
    } else {
        $(".delivery-office").hide()
        $(".delivery-home").hide()
        $(".delivery-day-div").hide();
        $(".company-name-div").hide();
        $(".office-input").prop('disabled', true)
        $(".home-input").prop('disabled', true)
    }
    

    $(".choose-delivery-radio-btn-div input[type='radio']").click(function(){
        
        if ($(this).is(':checked')) { 
            $(this).closest('.box').addClass('redBackground') 
            $(this).siblings("span").css("color", "#fff")
            $(".choose-delivery-radio-btn-div input[type='radio']:not(:checked)").siblings("span").css("color", "#666")
            removeDeliveryHighlightClass = $(".choose-delivery-radio-btn-div input[type='radio']:not(:checked)").closest('.box').removeClass('redBackground')
            $(this).parent('.box').hasClass('delivery_home') ? removeDeliveryHighlightClass : removeDeliveryHighlightClass
        }        
        
        
        if ($(this).val() === "pick up") {
            $(".disable-field-on-pick-up").prop("disabled", true)
            $(".delivery-office").hide()
            $(".delivery-home").hide()
            $(".company-name-div").hide();
            $(".delivery-day-div").hide();
            $(".pick-up").show()
            $(".pick-up-input").prop('disabled', false)
            $(".office-input").prop('disabled', true)
            $(".home-input").prop('disabled', true)

        } else {
            $(".disable-field-on-pick-up").prop("disabled", false)
            $(".pick-up").hide()
            $(".delivery-office").hide()
            $(".delivery-home").show()
            $(".pick-up-input").prop('disabled', true)
            $(".office-input").prop('disabled', true)
            $(".home-input").prop('disabled', false)
        }

        if ($(this).val() === "home") {
            $(".delivery-office").hide()
            $(".pick-up").hide()
            $(".company-name-div").hide();
            $(".delivery-home").show()
            $(".delivery-day-div").show();
            $(".pick-up-input").prop('disabled', true)
            $(".office-input").prop('disabled', true)
            $(".home-input").prop('disabled', false)


        } else if ($(this).val() === "office") {
            $(".delivery-office").show()
            $(".pick-up").hide()
            $(".company-name-div").show();
            $(".delivery-home").hide()
            $(".delivery-day-div").hide();
            $(".pick-up-input").prop('disabled', true)
            $(".office-input").prop('disabled', false)
            $(".home-input").prop('disabled', true)
        }

    });

    
    $('.input-number-increment').click(function () {
        var $input = $(this).parents('.input-number-group').find('.input-number');
        var val = parseInt($input.val(), 10);

        if (val == 500) {
            return false
        } else {
            $input.val(val + 1);
        }
    });

    $('.input-number-decrement').click(function () {
        var $input = $(this).parents('.input-number-group').find('.input-number');
        var val = parseInt($input.val(), 10);
        if (val == 0) {
            return false
        } else { 
            $input.val(val - 1);
        }
            
    })

    $(".forget-something-card input[type=number]").change(function(){
        console.log("helo")
    })

    $(".update_order_btn").hide()

    $(".review-checkout-increment").on('click', function() {
        $(".update_order_btn").show()
        $(".checkout_btn").hide()
    })

    $(".review-checkout-decrement").on('click', function () {
        $(".update_order_btn").show()
        $(".checkout_btn").hide()
    })
    

    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })

    var dataTable = $('#myTable').DataTable({
        "order": [[0, "DESC"]]
    });


    var serversideCustomersTable = $('#serversideCustomersTable').DataTable({
                                        processing: true,
                                        serverSide: true,
                                        ajax:  "/get_processed_dataset.json"
                                    });
                                                                                                                                                                                                                                                                                                    
    var weeklyMenuDataTable = $('#weeklyMenuTable').DataTable({
        "order": [[6, "desc"]]
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (weeklyMenuDataTable !== null) {
            weeklyMenuDataTable.destroy();
            weeklyMenuDataTable = null;
        }
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (serversideCustomersTable !== null) {
            serversideCustomersTable.destroy();
            serversideCustomersTable = null;
        }
    });

    

    var dataTableDash = $('#myTableDashboard').DataTable({
        "order": false
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (dataTable !== null) {
            dataTable.destroy();
            dataTable = null;
        }
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (dataTableDash !== null) {
            dataTableDash.destroy();
            dataTableDash = null;
        }
    });

    var dataTableDashWed = $('#myTableDashboardWed').DataTable({
        "order": false
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (dataTableDashWed !== null) {
            dataTableDashWed.destroy();
            dataTableDashWed = null;
        }
    });

    var dataTableVendorOrder = $('#myTableVendorOrder').DataTable({
        "order": [1, "desc"]
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (dataTableVendorOrder !== null) {
            dataTableVendorOrder.destroy();
            dataTableVendorOrder = null;
        }
    });

    var dataTableVendorHistoryOrder = $('#myTableVendorHistoryOrder').DataTable({
        columnDefs: [ { type: 'date', 'targets': [2] } ],
        "order": [2, "desc"]
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (dataTableVendorHistoryOrder !== null) {
            dataTableVendorHistoryOrder.destroy();
            dataTableVendorHistoryOrder = null;
        }
    });

    var myEmployeeWorkTable = $('#myEmployeeWorkTable').DataTable({
        "order": [0, "desc"]
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (myEmployeeWorkTable !== null) {
            myEmployeeWorkTable.destroy();
            myEmployeeWorkTable = null;
        }
    });

    var myWeeklyMenuDelieryTable = $('#myWeeklyMenuDeliveryTable').DataTable({
        "order": false
    });

    document.addEventListener("turbolinks:before-cache", function () {
        if (myWeeklyMenuDelieryTable !== null) {
            myWeeklyMenuDelieryTable.destroy();
            myWeeklyMenuDelieryTable = null;
        }
    });

    var driverDeliveryTable = $("#driverDeliveryTable").DataTable();

    document.addEventListener("turbolinks:before-cache", function () {
        if (driverDeliveryTable !== null) {
            driverDeliveryTable.destroy();
            driverDeliveryTable = null;
        }
    });
    
    var myReferralTable  = $('#refrralTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (myReferralTable !== null) {
            myReferralTable.destroy();
            myReferralTable = null;
        }
    });

    var myEmaillTable  = $('#myEmailTable').DataTable({
        "order": [3, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (myEmaillTable !== null) {
            myEmaillTable.destroy();
            myEmaillTable = null;
        }
    });

    

    var adminBagTable  = $('#adminBagTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (adminBagTable !== null) {
            adminBagTable.destroy();
            adminBagTable = null;
        }
    });

    var giftCardTable  = $('#giftCardTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (giftCardTable !== null) {
            giftCardTable.destroy();
            giftCardTable = null;
        }
    });

    var eatingInstructionsTable  = $('#eatingInstructionsTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (eatingInstructionsTable !== null) {
            eatingInstructionsTable.destroy();
            eatingInstructionsTable = null;
        }
    });
    
    var eatingInstructionsTable  = $('#eatingInstructionsTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (eatingInstructionsTable !== null) {
            eatingInstructionsTable.destroy();
            eatingInstructionsTable = null;
        }
    });

    
    var myNoticesTable  = $('#myNoticesTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (myNoticesTable !== null) {
            myNoticesTable.destroy();
            myNoticesTable = null;
        }
    });

    var vendorDeliveryTable  = $('#vendorDeliveryTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [1] } ],
        "order": [1, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (vendorDeliveryTable !== null) {
            vendorDeliveryTable.destroy();
            vendorDeliveryTable = null;
        }
    });

    var vendorTable  = $('#vendorTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"]
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (vendorTable !== null) {
            vendorTable.destroy();
            vendorTable = null;
        }
    });

    var ingredientOrderTable  = $('#ingredientOrderTable').DataTable({
        columnDefs: [ { type: 'date', 'targets': [0] } ],
        "order": [0, "DESC"],
        "pageLength": 100
    });
    
    document.addEventListener("turbolinks:before-cache", function () {
        if (ingredientOrderTable !== null) {
            ingredientOrderTable.destroy();
            ingredientOrderTable = null;
        }
    });


    $(".source-field").hide();
    $(".source-select").on('change', function() {

        if (this.value === "other") {
            $(".source-field").show();
        } else {
            $(".source-field").hide();
        }
        
    });

		$('#ocImg').hide();
		$('#cogsImg').hide();
    function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				var inputId = "#" + input.id
				var imgShowId = "#" + input.nextElementSibling.id

				reader.onload = function(e) {
				$(imgShowId).attr('src', e.target.result);
				$(imgShowId).show();
				};

				reader.readAsDataURL(input.files[0]);
			}
    }

		$("#monthly_report_oc_img").change(function(){
			readURL(this)
		});

		$("#monthly_report_cogs_img").change(function(){
			readURL(this)
		});


  $('form').on("click", ".add_fields", function(event) {
		time = new Date().getTime();
		regexp = new RegExp($(this).data('id'), 'g');
		$(this).before($(this).data('fields').replace(regexp, time))
		event.preventDefault();
	});

    var myVar = setInterval(myTimer, 1000);
    function myTimer() {
        var d = new Date();
        var t = d.toLocaleTimeString("en-US", {timeZone: "America/Vancouver"});
        $("#timeClock").html(t);
    }
});
