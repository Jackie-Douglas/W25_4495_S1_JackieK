$('document').ready(function() {
    console.log("hello")
    
    $("#_test").change(function() {
        var meal_count = $(this).val();
        $("div.meal-count").text(meal_count)
    });

    



















});