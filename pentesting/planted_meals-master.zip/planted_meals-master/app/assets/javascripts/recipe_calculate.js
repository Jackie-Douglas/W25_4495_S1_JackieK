$(document).on("turbolinks:load", function(event) {
  $(".recipeCalculateBtn").click(function(event){
    event.preventDefault();

    var modalId  = $(this).attr("data-recipeId");
    var quantity = []; 
    let sum      = 0     
    
    $("#" + modalId + ' tbody tr').each(function(index, value) {
      var newNeedAmount = parseInt($(this).closest(".recipe-calculation-table").find("#amount").val())

      var tableData     = $(this).find('td:eq(1)').html()
      
      if (tableData === undefined) {
         
      } else {
        var finalTableData = tableData.split(' ')
        var servingAmount = parseFloat(finalTableData[0])
        var newTotal      = newNeedAmount * servingAmount
        var unit          = finalTableData[1]
        var new_column    =  $(this).find('td:eq(3)')
        
        
        
        if (new_column.attr('id') === 'calculatedTotal') {
          quantity.forEach((el) => sum += el);
          console.log(quantity)

          new_column.html(sum)
          quantity = []
          sum      = 0
        } else {
          new_column.html(newTotal + " " + unit)
          quantity.push(newTotal)
        }
      }
    });
  })
});
