class VendorDeliveriesController < ApplicationController

  def index
    @driver = current_user.customer.employee
  end

  def show
    @driver = Employee.find(params[:id])
  end

  def toggle_checked
    @vendor_order = TempOrder.find(params[:id])
    @vendor_order.toggle!(:checked)
    
    respond_to do |format|
      format.html
      format.js
    end
  end


end