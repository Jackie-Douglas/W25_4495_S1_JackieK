class BagTrackersController < ApplicationController
	skip_before_action :authenticate_user!
	before_action :get_weekly_menu_for_delivery
	skip_before_action :verify_authenticity_token

	http_basic_authenticate_with name: "plantedmeals", password: "plantedrocks1234", only: :show

	def index
		@drivers = Employee.where(position: "driver")
	end

	def show
		Time.zone = "Pacific Time (US & Canada)"

		if params[:id] == "pick_up"
			@orders = @weekly_menu.orders.where(purchased: true)
			@pick_up_cusotmer_orders = Customer.where(id: @orders.pluck(:customer_id), delivery_to: ["pickup", "pick up"])
		else
			if Time.zone.today.strftime("%A") == "Monday" || Time.zone.today.strftime("%A") == "Tuesday"
				@driver = Employee.find(params[:id]).customer
				@orders = @weekly_menu.orders.where(purchased: true, employee_id: params[:id])

				@orders = @orders.joins(:customer).select("id", "subtotal", "customer_id", "total_meal_count", "comment", "purchased", "purchase_type", "weekly_menu_id", "charged_amount", "employee_id", "customers.first_name", "position", "customers.delivery_day").where.not("customers.delivery_day": "sunday").order("position")
			elsif Time.zone.today.strftime("%A") == "Sunday"
				@driver = Employee.find(params[:id]).customer
				@orders = @weekly_menu.orders.where(purchased: true, employee_id: params[:id])

				@orders = @orders.joins(:customer).select("id", "subtotal", "customer_id", "total_meal_count", "comment", "purchased", "purchase_type", "weekly_menu_id", "charged_amount", "employee_id", "customers.first_name", "position", "customers.delivery_day")
										.where("customers.delivery_day": "sunday").order("position")
			end
		end
	end

	def update
		@bag_tracker = BagTracker.find(params[:id])
		@employee_id = @weekly_menu.orders.find_by(customer_id: @bag_tracker.customer_id, purchased: true).employee_id
		current_counter = @bag_tracker.counter
		picked_up = params[:bag_tracker][:counter].to_i

		new_count = current_counter - picked_up

		@bag_tracker.update_attributes(counter: new_count.to_i)
		
		@employee_id.nil? ? (redirect_to bag_tracker_path("pick_up")) : (redirect_to bag_tracker_path(@employee_id))
	end
end
