class PrepTasksController < ApplicationController

  def index
    if is_between_weekly_date(params[:date].to_date)
      meals_with_vendor = Food.where(vendor_menu: true, food_type: "meal")
      employee_prep_tasks = EmployeePrepTask.where(weekly_menu_id: params[:weekly_menu_id], prep_date: get_weekday_date_range(params[:date].to_date))

      @scheduled_employees = Employee.where(id: employee_prep_tasks.pluck(:employee_id).uniq)
      @find_assigned_employee_prep_tasks = employee_prep_tasks.group_by { |x| x.employee_id }
    else
      meals_with_vendor = Food.where(vendor_menu: true, food_type: "meal") + Food.where(id: get_meals(params[:weekly_menu_id]).pluck(:food_id)) + Food.where(id: get_everything_but_meals(params[:weekly_menu_id]).pluck(:food_id))
      employee_prep_tasks = EmployeePrepTask.where(weekly_menu_id: params[:weekly_menu_id], prep_date: get_weekend_date_range(params[:date].to_date))

      @scheduled_employees = Employee.where(id: employee_prep_tasks.pluck(:employee_id).uniq)
      @find_assigned_employee_prep_tasks = employee_prep_tasks.group_by { |x| x.employee_id }
    end

    @meals = meals_with_vendor.uniq
    @other_items = Food.where(id: get_everything_but_meals(params[:weekly_menu_id]).pluck(:food_id)) + @meals
    
    @employee_prep_task = EmployeePrepTask.new
    @universal_prep_tasks = PrepTask.where(is_universal: true)
  end

  def new
    @sent_params = request.query_parameters.keys.join
    klass        = @sent_params.classify.constantize   
    @record = klass.find(params[@sent_params.to_sym])

    @prep_task = PrepTask.new
  end

  def create
    @sent_params = params.dig('prep_task', 'recipe_ingredient').nil? ? "food" : "recipe_ingredient"
    klass = @sent_params.classify.constantize
    @record = klass.find(params[:prep_task][@sent_params])

    @prep_task = @record.prep_tasks.build(prep_task_params)

    if @prep_task.save
      redirect_to recipe_ingredients_path(food_id: food_id(@prep_task))
    else
      render :new
    end
  end

  def edit
    @sent_params = request.query_parameters.keys.join
    klass        = @sent_params.classify.constantize   
    @record = klass.find(params[@sent_params.to_sym])

    @prep_task = PrepTask.find(params[:id])
  end

  def update
    @prep_task = PrepTask.find(params[:id])

    if @prep_task.update(prep_task_params)
      redirect_to recipe_ingredients_path(food_id: food_id(@prep_task))
    else
      render :new
    end
  end

  def show
    @prep_task = PrepTask.find(params[:id])
  end

  def destroy
    @prep_task = PrepTask.find(params[:id])
    @prep_task.destroy

    redirect_to recipe_ingredients_path(food_id: food_id(@prep_task))
  end

  private

  def prep_task_params
    params.require(:prep_task).permit(:name, :status, :machine_required, :cut_method, :size, :station, :food_id, :recipe_ingredient_id, :relation_type, :recipe_ref_id, :food_ref_id, :is_universal)
  end

  def food_id(record)
    record.food_id.nil? ? record.recipe_ingredient.recipe.food_id : record.food_id
  end
end

