class ShoppingListsController < ApplicationController

  def index
    
  end

end