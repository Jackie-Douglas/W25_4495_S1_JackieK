class ManagerDashboardsController < ApplicationController
    def index
    end
end