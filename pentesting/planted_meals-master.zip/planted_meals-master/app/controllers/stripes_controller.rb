class StripesController < ApplicationController
	skip_before_action :authenticate_user!

	def create
		Stripe.api_key = (Rails.env == "production" ? (root_url.include?("plantedmeals.io") ? "sk_test_Cho5zcx8EroV74ApGoBwkbuo" : Rails.application.credentials.stripe_secret_key) : "sk_test_Cho5zcx8EroV74ApGoBwkbuo")
		# Set your secret key: remember to change this to your live secret key in production
		# See your keys here: https://dashboard.stripe.com/account/apikeys

		# Token is created using Checkout or Elements!
		# Get the payment token ID submitted by the form:

		grand_total = Calculation::GrandTotal.new({order: find_order, coupon_id: params[:coupon_id]}).get_grand_total
		amount = (grand_total.to_f * 100).to_i

		customer = create_customer_if_new

		begin
			if is_subscription?
				subscription = Stripe::Subscription.create({ 
						customer: customer.id,
						items: [{ plan: get_stripe_subscription_id }],
						tax_percent: 5
				})
			else
				source = customer.stripe_info.default_source
				charge = Stripe::Charge.create({
						amount: amount,
						currency: 'cad',
						description: charge_description,
						customer: customer.stripe_info.stripe_customer_id,
						source: source
				})
																
				update_purchased_column_if_charge_status_is_successful(charge)
			end
			# render file: "#{Rails.root}/app/views/layouts/thank_you_purchase.html.erb", locals: { x: "test" }
			redirect_to thank_you_index_path(order_id: params[:order_id])
		rescue Stripe::CardError => e
			body = e.json_body
			error = body[:error]
			@message = error[:message]
			
			render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
		end
	end

# for the subscription to work, I first have to get plan_id from stripe and input it inside products table
# and then, create a subscription based on that plan_id

# To automatically invoice and bill you customer perodically
# 1. Define a serve product and pricing plan
# 2. Create a customer
# 3. Subscribe

	private

	def create_customer_if_new
		token = params[:stripeToken]
		email = params[:stripeEmail]
		
		customer = Customer.find_by(email: email)

		if customer.stripe_info.nil?
			customer_from_stripe = Stripe::Customer.create({ email: email, source: token })
				
			@stripe_info = StripeInfo.create(credit_card_type: customer_from_stripe.sources.data[0].brand,
																			 last_4: customer_from_stripe.sources.data[0].last4,
																			 default_source:  customer_from_stripe.default_source,
																			 stripe_customer_id: customer_from_stripe.id)
			customer.stripe_info = @stripe_info

			return customer
		else
			if customer.stripe_info.stripe_customer_id.blank?
				customer_from_stripe = Stripe::Customer.create({ email: email, source: token })
				customer.stripe_info.update_columns(credit_card_type: customer_from_stripe.sources.data[0].brand,
																						last_4: customer_from_stripe.sources.data[0].last4,
																						default_source:  customer_from_stripe.default_source,
																						stripe_customer_id: customer_from_stripe.id)

				return customer
			else
				updated_customer = Stripe::Customer.update(customer.stripe_info.stripe_customer_id, {source: token})
				customer.stripe_info.update_columns(credit_card_type: updated_customer.sources.data[0].brand,
																						last_4: updated_customer.sources.data[0].last4,
																						default_source:  updated_customer.default_source)

				return customer
			end
		end
	end

	def is_subscription?
		find_order.purchase_type == "subscription"
	end

	def charge_description
		snacks = find_order.line_items.includes(:food).where('foods.food_type = ?', 'snack', ).references(:food).map do |x|
								"#{x.name} X #{x.quantity}\n"
							end

		"Single Planted Meals X #{meal_count}\n
		#{snacks.join("\n")}
		Delivery Fee: $#{delivery_charge}\n
		Tax (5%)"
	end
  
	def find_quantity(food_id)
		begin
			find_order.line_items.find_by(food_id: food_id).quantity
		rescue
			return 0
		end
	end

	def delivery_charge
		find_order.subtotal > 80 ? 0 : customer_info.delivery.fee
	end

	def meal_count
		find_order.total_meal_count
	end

	def get_stripe_subscription_id
		find_product.stripe_product_id
	end

	def update_purchased_column_if_charge_status_is_successful(charge)
		charge_status = charge.status
		charge_amount = charge.amount

		if charge_status.downcase == "succeeded"
			find_order.update_columns(purchased: true, charged_amount: charge_amount) 
			CouponUsage.find_by(customer_id: customer_info.id, coupon_id: find_coupon.id).update_columns(purchased: true, order_ref_id: find_order.id) if !find_coupon.nil?
			update_coupon_number_available_count if !find_coupon.nil?
			PurchasedNotificationMailer.with(customer_info: customer_info, order_info: find_order).notification_email.deliver_now
			SendWeeklyFoodReviewWorker.perform_in(perform_in_day(find_order).days, find_order.id)
			# create user with the 
			# create_user_information if new_user?
			# upload information to klaviyo
			# initialize(klaviyo, order)
			KlaviyoSendEventWorker.perform_async(find_order.id) if Rails.env == "production"
			# update or create bag that when out to the customer
			BagTracking::UpdateCounter.new(find_order).call
			Referral::AddRewards.new({order: find_order, uuid: params[:uuid], user_id: referral_exist[:user_id]}).call if (!params[:uuid].blank? || referral_exist[:condition])
		end
	end

	def create_user_information
		user = User.create(email: customer_info.email, password: customer_info.email, confirmation_token: customer_info.email, confirmed_at: DateTime.now, confirmation_sent_at: DateTime.now)
		customer_info.update_columns(user_id: user.id)
		UserSignUpUpdateNotificationMailer.with(temp_pass: customer_info.email, email: user.email).notification_email.deliver_now
	end

	def customer_info
		Customer.find(find_order.customer_id)
	end

	def new_user?
		User.find_by(email: customer_info.email).nil?
	end

	def find_order
		Order.find(params[:order_id])
	end

	def find_coupon
		Coupon.find_by(uuid: params[:coupon_id])
	end
    
	def update_coupon_number_available_count
		previous_count = find_coupon.numbers_available
		new_count = previous_count - 1
		find_coupon.update_columns(numbers_available: new_count)
	end

	def referral_exist
		# find if the order was ever referrals by someone, this should be called if referral is found
		# get an email of a person that ordered
		# find referral with the email
		# get user of the referral
		email = customer_info.email
		was_it_a_referral = Referral.find_by(email: email)

		if was_it_a_referral
				@referral_hash = {
														condition: true,
														user_id: was_it_a_referral.user.id
													}
		else
				@referral_hash = {
														condition: false,
														user_id: nil
													}
		end
	end
end