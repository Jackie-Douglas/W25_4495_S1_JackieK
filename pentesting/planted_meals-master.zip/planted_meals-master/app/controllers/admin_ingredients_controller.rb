class AdminIngredientsController < ApplicationController

  def index
    @ingredient_categories = IngredientCategory.includes(:ingredients)
  end

end