class MenusController <  ApplicationController
    before_action :get_weekly_menu
    skip_before_action :authenticate_user!

    def index
        # @previous_menu = WeeklyMenu.find_by(week_start: @weekly_menu.week_start - 7.days, week_end: @weekly_menu.week_end - 7.days)
        # @next_week_menu = WeeklyMenu.find_by(week_start: @weekly_menu.week_start + 7.days, week_end: @weekly_menu.week_end + 7.days)
        @foods = Food.where(availability: true, display_in_menu: true)
        @grouped_foods = @foods.group_by{|x| x.food_category_id}
        @meals_count = @foods.where(food_type: "meal").count
    end

end