class AdminFoodReviewsController < ApplicationController
  
  def index
    @food = Food.all
  end

end