class EmVendorsController < ApplicationController
  before_action :authenticate_admin_or_manger
  before_action :get_weekly_menu_for_admin, only: :index

  def index
    @vendors = Vendor.where(everyday_meals: true)
    @wednesday_cook = @weekly_menu.week_start - 5.days
    @sunday_cook = @weekly_menu.week_start - 1.day

      respond_to do |format|
        format.html
        
        if params[:label_day] == "em sunday"
          format.pdf do
              pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @sunday_cook))
              send_data pdf.render,
              filename: "export.pdf",
              type: 'application/pdf',
              disposition: 'inline'
          end 
        elsif params[:label_day] == "em wednesday"
          format.pdf do
              pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @wednesday_cook))
              send_data pdf.render,
              filename: "export.pdf",
              type: 'application/pdf',
              disposition: 'inline'
          end 
        end
      end
  end

  def generate_em_invoice_pdf
    @orders = TempOrder.where(invoice_date: params[:from_date]..params[:to_date], everyday_meals: true).order(invoice_date: "ASC")

    respond_to do |format|
      format.html
      format.pdf do
        pdf = Invoice.new(@orders)
                send_data pdf.render,
                filename: "export.pdf",
                type: 'application/pdf',
                disposition: 'inline'
      end
    end
  end

end

  #         format.html

  #         if params[:delivery_day] == "thu_delivery"
  #             format.csv { send_data csv_information(TempOrder.where(cook_on: @wednesday_cook, delivery_day: "thu")), filename: "#{params[:delivery_day]} list.csv" }
  #         elsif params[:delivery_day] == "sun_delivery"
  #             format.csv { send_data csv_information(TempOrder.where(cook_on: @sunday_cook, delivery_day: "sun")), filename: "#{params[:delivery_day]} list.csv" }
  #         elsif params[:delivery_day] == "mon_delivery"
  #             format.csv { send_data csv_information(TempOrder.where(cook_on: @sunday_cook, delivery_day: "mon")), filename: "#{params[:delivery_day]} list.csv" }
  #         end



  #         if params[:label_day] == "wednesday"
  #             format.pdf do
  #                 pdf = VendorSheet.new(TempOrder.where(cook_on: @wednesday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end
  #         elsif params[:label_day] == "new wednesday"
  #             format.pdf do
  #                 pdf = NewVendorSheet.new(TempOrder.where(cook_on: @wednesday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end 
  #         elsif params[:label_day] == "new sunday"
  #             format.pdf do
  #                 pdf = NewVendorSheet.new(TempOrder.where(cook_on: @sunday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end 
  #         elsif params[:label_day] == "em sunday"
  #             format.pdf do
  #                 pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @sunday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end 
  #         elsif params[:label_day] == "em wednesday"
  #             format.pdf do
  #                 pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @wednesday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end 
  #         else
  #             format.pdf do
  #                 pdf = VendorSheet.new(TempOrder.where(cook_on: @sunday_cook))
  #                 send_data pdf.render,
  #                 filename: "export.pdf",
  #                 type: 'application/pdf',
  #                 disposition: 'inline'
  #             end
  #         end
      # end
  