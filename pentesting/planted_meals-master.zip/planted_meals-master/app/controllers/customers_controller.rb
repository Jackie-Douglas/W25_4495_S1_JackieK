class CustomersController < ApplicationController
  include ApplicationHelper
  skip_before_action :authenticate_user!, only: [:update, :create], if: :test

  def new
    @customer = Customer.new
  end

  def create
    returning_customer = Customer.find_by(email: params[:customer][:email].downcase)
    order = Order.find(params[:order_id])

    if returning_customer
      returning_customer.delivery_id = find_delivery_id 
      order.update_columns(customer_id: returning_customer.id)

      if returning_customer.update_attributes(customer_params)
        redirect_to uuid_filtered_url(review_checkout_path(order_id: params[:order_id]), params[:customer][:uuid])
      else
        flash[:alert] = returning_customer.errors
        redirect_to delivery_path(order_id: params[:order_id])
      end
      
    else
      new_customer = Customer.new(customer_params)
      new_customer.delivery_id = find_delivery_id

      if new_customer.save
        order.update_columns(customer_id: new_customer.id)
        redirect_to uuid_filtered_url(review_checkout_path(order_id: params[:order_id]), params[:customer][:uuid])
      else
        flash[:alert] = new_customer.errors
        redirect_to delivery_path(order_id: params[:order_id])
      end
    end
  end

  def update
    order = Order.find(params[:order_id])
    customer = Customer.find(order.customer_id)
    customer.delivery_id = find_delivery_id 

    if customer.update_attributes(customer_params)
      redirect_to uuid_filtered_url(review_checkout_path(order_id: params[:order_id]), params[:customer][:uuid])
    else
      flash[:alert] = customer.errors
      redirect_to delivery_path(order_id: params[:order_id])
    end
  end

  private

  def customer_params
    params.require(:customer).permit(:first_name, :last_name, :email,
                                     :phone, :address, :city, :province,
                                     :country, :postal_code, :on_subscription,
                                     :delivery_to, :shipping_address, :shipping_city, 
                                     :shipping_province, :shipping_country, :shipping_postal_code,
                                     :unit, :buzzer, :company_name, :delivery_day, :delivery_id, :food_note, :delivery_note,
                                     :unit_type, :source, :rate, :other
                                     )
  end

  def find_delivery_id
    delivery_location = params[:customer][:delivery_to] 

    if delivery_location == 'pick up'
      delivery_zone_id = Delivery.find_by(delivery: delivery_location).id
    else
      delivery_zone = params[:delivery_zone]
      delivery_zone_id = Delivery.find_by(zone: delivery_zone, delivery: delivery_location).id
    end
  end
end
