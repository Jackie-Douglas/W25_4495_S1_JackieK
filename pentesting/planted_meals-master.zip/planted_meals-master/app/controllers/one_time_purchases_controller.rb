class OneTimePurchasesController < ApplicationController
	skip_before_action :authenticate_user!
	before_action :get_weekly_menu
	before_action :redirect_to_portal_if_you_are_signed_in, only: :new

	def index
		@order = Order.new
		@food_items = @weekly_menu.food_items
		if @order.line_items.blank?
				@food_items.each do |f|
						@order.line_items.build(food_id: f.food_id)
				end
		end
		
		render :new
	end

	def new
		unless @weekly_menu.nil?
			@order = Order.new
			@food_items = @weekly_menu.food_items.where(vendor_only: false)
			
			if @order.line_items.blank?
				@food_items.each do |f|
						display_sequence = f.eating_order.nil? ? 99 : f.eating_order
						@order.line_items.build(food_id: f.food_id, display_sequence: display_sequence)
				end
			end
		else 
			render file: "#{Rails.root}/app/views/layouts/no_menu.html.erb"
		end
	end

	def create
		@order = Order.new(orders_params)
		@order.weekly_menu_id = @weekly_menu.id
		@order.purchase_type = "one time purchase"
		@food_items = @weekly_menu.food_items.where(vendor_only: false)

		if @order.line_items.blank?
			@food_items.each do |f|
					display_sequence = f.eating_order.nil? ? 99 : f.eating_order
					@order.line_items.build(food_id: f.food_id, display_sequence: display_sequence)
			end
		end

		if @order.save
			# customer = create_customer
			# @order.update_columns(customer_id: customer.id)
			redirect_to uuid_filtered_url(delivery_path(order_id: @order.id), params[:order][:uuid])
		else
			render :new
		end
	end

	def edit
		@order = Order.find(params[:id])
		@order.line_items
	end

	def update
		@order = Order.find(params[:id])
		
		if @order.update_attributes(orders_params)
				redirect_to uuid_filtered_url(delivery_path(order_id: @order.id), params[:uuid])
		else
				render :edit
		end
	end

	private

	def orders_params
		params.require(:order).permit(:order_number, :order_date, :total_price, 
																	:mon, :tue, :wed, :thu, :fri, :sat, :sun, 
																	:total_meal_count, :container_type, :single_cookie, 
																	:comment, :bundle_cookie, :ricotta, :brownie,
																	line_items_attributes: [:id, :quantity, :name, :price, :food_id, :order_id, :gluten_wise_option, :double_protein, :add_on_price]
																	)
	end
end
