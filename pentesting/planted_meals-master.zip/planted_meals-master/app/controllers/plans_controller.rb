class PlansController < ApplicationController
    before_action :authenticate_admin

    def new
        @plan = Plan.new
    end

    def create
        @plan = Plan.new(plan_params)
        
        if @plan.save
            redirect_to plan_path(@plan.id)
        else
            render :new
        end
    end

    def edit
        @plan = Plan.find(params[:id])
    end

    def update
        @plan = Plan.find(params[:id])

        if @plan.update_attributes(plan_params)
            redirect_to plan_path(@plan.id)
        else 
            render :edit
        end
    end



    def show
        @plan = Plan.first
    end

    private

    def plan_params
        params.require(:plan).permit(:title, :note)
    end

end