class ReferralsController <  ApplicationController
    # must have purchased once from planted meals (purcahsd:true)
    skip_before_action :authenticate_user!, only: [:new_referral, :create_customer_from_referral]
    before_action :get_weekly_menu

    def new
        @referral = Referral.new
    end

    def index   
        @referrals = current_user.is_admin ? Referral.all.order(created_at: :DESC).where(event_name: nil) : current_user.referrals
    end
    
    
    def create
        @referral = Referral.new(referral_params)
        @referral.user_id = current_user.id
        @email = @referral.email
        customer = Customer.find_by(email: @email).nil?

        if customer
            if @referral.save
                # send email
                # production will need actual email of a friend
                # send uuid
                
                Referral::SendReferral.new(uuid: @referral.uuid, email: @referral.email, current_user: current_user, weekly_menu_id: @weekly_menu.id).send("send_" + @referral.referral_type)

                redirect_to new_user_referral_path(current_user.id), notice: "Email was sent to #{@referral.email}"
            else
                render :new
                # redirect_to customer_dashboards_path, alert: "Something went wrong, please try again"
            end
        else
            flash[:alert] = "The email already exists in our system, please use a different email address"
            render :new
            # redirect_to customer_dashboards_path
        end
    end

    def update
        @referral = Referral.find(params[:id])
        Referral::SendReferral.new(uuid: @referral.uuid, email: @referral.email, current_user: current_user, weekly_menu_id: @weekly_menu.id).send("send_" + @referral.referral_type)
        redirect_to referrals_path, notice: "The email has been sent"
    end



    def new_referral
        @email = Referral.find_by(uuid: params[:uuid]).email
        @customer = Customer.new
        @redeemed = Referral.find_by(uuid: params[:uuid]).redeemed
    end

    def create_customer_from_referral
        @customer = Customer.new(customer_params)

        if Customer.find_by(email: @customer.email).nil?
        
            if @customer.save
                create_order
                Stripe.api_key = (Rails.env == "production" ? (root_url.include?("plantedmeals.io") ? "sk_test_Cho5zcx8EroV74ApGoBwkbuo" : Rails.application.credentials.stripe_secret_key) : "sk_test_Cho5zcx8EroV74ApGoBwkbuo")
                create_stripe

                amount = (10.5 * 100).to_i
                
                begin
                    source = @customer.stripe_info.default_source
                    @charge = Stripe::Charge.create({
                        amount: amount,
                        currency: 'cad',
                        description: charge_description,
                        customer: @customer.stripe_info.stripe_customer_id,
                        source: source
                    })
                    
                    update_purchased_column_if_charge_status_is_successful

                    render file: "#{Rails.root}/app/views/layouts/thank_you_purchase.html.erb"
                rescue Stripe::CardError => e
                    body = e.json_body
                    error = body[:error]
                    @message = error[:message]
                    
                    render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
                end

            else
                render :new_referral
            end

        else
            render plain: "You already have purchased this item, thank you"
        end

    end


    private
    
    def referral_params
        params.require(:referral).permit(:email, :event_name, :redeemed, :uuid, :user_id, :message, :referral_type, :first_name)
    end

    def customer_params
        params.require(:customer).permit(:first_name, :last_name, :email,
                                        :phone, :address, :city, :province,
                                        :country, :postal_code, :on_subscription,
                                        :delivery_to, :shipping_address, :shipping_city, 
                                        :shipping_province, :shipping_country, :shipping_postal_code,
                                        :unit, :buzzer, :company_name, :delivery_day, :delivery_id, :food_note,
                                        :delivery_note, :subscription_info, :stripe_id, :internal, :unit_type
                                        )
    end

    private

    def create_order
        @order = Order.create(mon: 1, tue: 1, wed: 1, thu: 1, fri: 1, weekly_menu_id: @weekly_menu.id, customer_id: @customer.id)
    end

    def create_stripe
        token = params[:stripeToken]
        email = params[:stripeEmail]
        

        customer_from_stripe = Stripe::Customer.create({
            email: email,
            source: token
        })

        @stripe_info = StripeInfo.create(
                credit_card_type: customer_from_stripe.sources.data[0].brand,
                last_4: customer_from_stripe.sources.data[0].last4,
                default_source:  customer_from_stripe.default_source,
                stripe_customer_id: customer_from_stripe.id,
                customer_id: @customer.id
        )
    end

    def charge_description
        "World Vegan Day Promo\n
        Tax (5%)"
    end

    def update_purchased_column_if_charge_status_is_successful
        charge_status = @charge.status
        charge_amount = @charge.amount

        if charge_status.downcase == "succeeded"
            @order.update_columns(purchased: true, charged_amount: charge_amount) 
            Referral.find_by(email: @customer.email).update_columns(redeemed: true)
            PurchasedNotificationMailer.with(customer_info: @customer, order_info: @order).notification_email.deliver_now
            # create user with the 
            create_user_information if new_user?
        end

    end

    def create_user_information
        user = User.create(email: @customer.email, password: @customer.email, confirmation_token: @customer.email, confirmed_at: DateTime.now, confirmation_sent_at: DateTime.now)
        @customer.update_columns(user_id: user.id)
        UserSignUpUpdateNotificationMailer.with(temp_pass: @customer.email, email: user.email).notification_email.deliver_now
    end

    def new_user?
        User.find_by(email: @customer.email).nil?
    end

    
end