class TvDashboardsController < ApplicationController
  skip_before_action :authenticate_user!
  before_action :get_weekly_menu_for_admin

  def index
    @display_condition = display_condition
    
    if @display_condition == "weekend" 
      meal_ids = get_meals(@weekly_menu.id).pluck(:food_id)
      meals = Food.where(id: meal_ids)
      vendor_menu = Food.where(vendor_menu: true, food_type: "meal")
      @meals = meals + vendor_menu
      @snacks_and_addons = Food.where(vendor_menu: true).where.not(food_type: "meal")

    else
      @vendor_menu = Food.where(vendor_menu: true).order(food_type: :DESC)
    end
  end

  private

  def display_condition
    Time.zone = "Pacific Time (US & Canada)"
    today = Date::DAYNAMES[Time.zone.today.wday]
    weekend  = ["Sunday", "Thursday", "Friday", "Saturday"]
    week_day = ["Monday", "Tuesday", "Wednesday"] 

    if weekend.include?(today)
      "weekend"
    else
      "week_day"
    end
  end
end
