class EatingInstructionsController < ApplicationController
    before_action :authenticate_admin

    def index
        @eating_instructions = EatingInstruction.all
    end

    def new 
        @eating_instruction = EatingInstruction.new
    end 

    def create
        @eating_instruction = EatingInstruction.new(eating_instruction_params)
        
        if @eating_instruction.save
            redirect_to eating_instructions_path
        else

        end
    end

    def edit
        @eating_instruction = EatingInstruction.find(params[:id])
    end

    def update
        @eating_instruction = EatingInstruction.find(params[:id])

        if @eating_instruction.update(eating_instruction_params)
            redirect_to eating_instructions_path
        else
        end
    end

    def destroy
        @eating_instruction = EatingInstruction.find(params[:id])
        @eating_instruction.destroy
        redirect_to eating_instructions_path
    end



    private

    def eating_instruction_params
        params.require(:eating_instruction).permit(:instructions)
    end


end