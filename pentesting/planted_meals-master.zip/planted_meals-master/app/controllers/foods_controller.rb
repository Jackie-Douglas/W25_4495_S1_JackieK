class FoodsController < ApplicationController
	before_action :authenticate_admin_or_manger

	def index
		@food = Food.all
	end

	def new
		@food = Food.new
	end

	def create
		@food = Food.new(food_params)

		if @food.save
			redirect_to foods_path
		else
			render :new
		end
	end

	def edit
		@food = Food.find(params[:id])
		@food.add_ons.build(food_id: @food.id)
	end

	def update
		@food = Food.find(params[:id])     

		if @food.update_attributes(food_params)
			redirect_to edit_food_path(params[:id])
		else
			render :edit
		end
	end

	def show
		date_range

		@food = Food.find(params[:id])
	end

	def destroy
		@food = Food.find(params[:id])
		@food.destroy
		redirect_to foods_path
	end

	private

	def food_params
		params.require(:food).permit(:image, :name, :description, :protein, :carbohydrates, 
																	:fat, :kcal, :note, :cost_per_dish, :gluten_wise, :vendor_menu,
																	:retail_price, :wholesale_price, :sale_price, :food_type, :sort_sequence, :availability, :allergens, :food_category_id,
																	:short_name, :eating_instructions, :snack_sort_sequence, :discount_available, :new_item, :ple, :spicy_level, 
																	:gluten_wise_option, :food_group_id, :unit, :eating_instruction_id, :mfp_url, :signature, :display_in_menu, :buffer, :everyday_meals, add_ons_attributes: [:id, :recipe_id, :food_id, :name, :price]
																	)
	end

	

	def date_range
		if (params[:start].nil? && params[:end].nil?)
			@start_date = Date.today - 4.months
			@end_date = Date.today + 1.week
			@date_range = @start_date..@end_date
			@weekly_menus_search_result = WeeklyMenu.where(week_start: @date_range).order(:week_start)
		else
			@start_date = params[:start].to_date
			@end_date = params[:end].to_date
			@date_range = @start_date..@end_date
			@weekly_menus_search_result = WeeklyMenu.where(week_start: @date_range).order(:week_start)
		end
	end
end