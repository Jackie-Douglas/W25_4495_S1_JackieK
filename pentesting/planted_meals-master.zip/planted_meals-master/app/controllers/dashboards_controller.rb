class DashboardsController < ApplicationController
  include WorkHoursHelper
  before_action :get_weekly_menu_for_admin
  before_action :get_previous_weekly_menu_for_admin
  before_action :authenticate_admin_or_manger, only: :index

  def index
    @q = WeeklyMenu.ransack(params[:q])
		@week_start = params[:q].present? ? params[:q]["week_start_eq"].to_date : @weekly_menu.week_start
		@week_end =  params[:q].present? ? params[:q]["week_end_eq"].to_date : @weekly_menu.week_end

    @weekly_menu = WeeklyMenu.find_by(week_start: @week_start, week_end: @week_end)
    @customers = Customer.all
    @office_customers = Customer.where(delivery: "office")
    @orders = Order.where(weekly_menu_id: @weekly_menu.id, purchased: true)
    @previous_orders = Order.where(weekly_menu_id: @previous_weekly_menu.id, purchased: true)
    @snacks = Food.where(food_type: "snack", availability: true)
    @vendor_menu = Food.where(vendor_menu: true, food_type: "meal")
    @vendor_snacks = Food.where(vendor_menu: true, food_type: "dessert")
    @vendor_addons = Food.where(vendor_menu: true).where.not(food_type: ["dessert", "meal"])
    
    @meals = get_meals(@weekly_menu.id)
    @monthly_reports = MonthlyReport.all.order(report_date: :DESC)
  end
end
