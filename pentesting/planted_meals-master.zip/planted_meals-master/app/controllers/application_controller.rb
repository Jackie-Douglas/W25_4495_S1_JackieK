class ApplicationController < ActionController::Base
  before_action :authenticate_user!
  # before_action :redirect_to_weebly_after_number, if: :production
  protect_from_forgery with: :exception
  impersonates :user
  before_action :initialize_klaviyo
  before_action :configure_permitted_parameters, if: :devise_controller?

  # def redirect_to_weebly_after_number
  #   last_counter = WebCounter.last.blank? ? 0 : WebCounter.last.counter
  #   counter = WebCounter.last.update_columns(counter: (last_counter + 1)) if (params[:controller] == "products" && params[:action] == "choose_plan" && params[:subdomain] == "shop")
  #   last_count = WebCounter.last.counter
  #   if  last_count >= 500
  #     redirect_to "https://www.plantedmeals.ca/order-now-real.html"
  #   else
  #     return if last_count <= 500
  #     redirect_to choose_plan_path
  #   end

  # end

  def gtm_id
    ((Rails.env == "production") && root_url.include?("plantedmeals.ca")) == true ? "GTM-NFDSLDK" : "GTM-MXZLT2N"
  end
  helper_method :gtm_id

  def price_to_float(price)
      price.to_f
  end
  helper_method :price_to_float

  def uuid_filtered_url(url, uuid)
    modified_url = url.include?("?") ? "&uuid=#{uuid}" : "?uuid=#{uuid}"
    uuid.blank? ? url : (url + modified_url)
  end
  helper_method :uuid_filtered_url

  def redirect_to_portal_if_you_are_signed_in
    redirect_to root_url.sub("shop", "portal") + "customer_dashboards" if (user_signed_in? && request.url.include?("shop") && !current_user.is_admin)
  end

  def initialize_klaviyo
    @klaviyo = Klaviyo::Client.new(Rails.application.credentials.send("#{Rails.env.downcase}_klaviyo_public_api"))
  end

  if Rails.env == "production"
    rescue_from ActionController::RoutingError, with: :render_404
    rescue_from StandardError, with: :render_404
  end

  def authenticate_admin
    # redirect_to :back if !current_user.is_admin?
    # render :file => "#{Rails.root}/public/401.html", :status => 401, :layout => false if !admin && (current_user.customer.nil? ? (current_user.user_type == "vendor") : !current_user.customer.employee)
    render :file => "#{Rails.root}/public/401.html", :status => 401, :layout => false if !current_user.is_admin?
  end

  def authenticate_admin_or_manger
    if current_user.is_admin? || current_user.manager?
    else 
      render :file => "#{Rails.root}/public/401.html", :status => 401, :layout => false 
    end
  end


  def redirect_to_time_sheet_page_on_admin_plantedmeals
    redirect_to employees_index_path if current_user.email == "admin@plantedmeals.ca"
  end
  
  def week_start
    Time.zone = "Pacific Time (US & Canada)"

    if after_cut_off_time
      Time.zone.today.next_week.beginning_of_week(:monday) + 1.week
    else
      Time.zone.today.next_week.beginning_of_week(:monday)
    end
  end
  helper_method :week_start

  def week_end
    Time.zone = "Pacific Time (US & Canada)"

    if after_cut_off_time
      Time.zone.today.next_week.end_of_week(:saturday) + 1.week
    else
      Time.zone.today.next_week.end_of_week(:saturday)
    end
  end
  helper_method :week_end
  
  def delivery_day
    Time.zone.today.next_week.beginning_of_week(:monday)
  end
  helper_method :delivery_day

  def get_delivery_charge(meal_count, delivery_fee)
    meal_count >= 8 ? 0 : delivery_fee
  end
  helper_method :get_delivery_charge
  
  def after_cut_off_time
    Time.zone = "Pacific Time (US & Canada)"

    current_time = Time.zone.now
    cut_off_date =  Time.zone.now.beginning_of_week(:monday) + 2.days
    # cut_off_date =  Time.zone.now.beginning_of_week(:monday) + 2.days
    year = cut_off_date.year
    month = cut_off_date.month
    day = cut_off_date.day
    cut_off_date_w_time = DateTime.new(year, month, day, 8, 01, 0).in_time_zone("Pacific Time (US & Canada)")
    
    current_time > cut_off_date_w_time
  end
  helper_method :after_cut_off_time
  
  def get_weekly_menu
      @weekly_menu = WeeklyMenu.find_by(week_start: week_start,  week_end: week_end)
  end

  def get_weekly_menu_for_inventory
    Time.zone           = "Pacific Time (US & Canada)"

    current_time        = Time.zone.now
    inventory_order_day = Date::DAYNAMES[current_time.wday].downcase

    if ["monday", "tuesday"].include?(inventory_order_day)
      week_start = current_time.beginning_of_week + 1.week
      wee_end    = current_time.end_of_week + 1.week - 2.days

      @weekly_menu = WeeklyMenu.find_by(week_start: week_start, week_end: week_end)
    elsif ["wednesday", "thursday", "friday", "saturday", "sunday"].include?(inventory_order_day)
      week_start = current_time.beginning_of_week + 1.week
      week_end    = current_time.end_of_week + 1.week - 2.days
      # week_start = Time.zone.today.next_week.beginning_of_week(:monday) + 1.week
      # week_end   = Time.zone.today.next_week.end_of_week(:saturday) + 1.week

      @weekly_menu = WeeklyMenu.find_by(week_start: week_start, week_end: week_end)
    end
  end

  def get_weekly_menu_for_admin
      Time.zone = "Pacific Time (US & Canada)"

      # if Time.zone.now >= Time.zone.parse('19:00:00')
      #   week_start = Time.zone.today.next_week.beginning_of_week(:monday) + 1.week
      #   week_end = Time.zone.today.next_week.end_of_week(:saturday) + 1.week
      # else
        week_start = Time.zone.today.next_week.beginning_of_week(:monday)
        week_end = Time.zone.today.next_week.end_of_week(:saturday)
      # end

      @weekly_menu = WeeklyMenu.find_by(week_start: week_start,  week_end: week_end)
      # @weekly_menu = WeeklyMenu.find_by(week_start: week_start - 1.week,  week_end: week_end - 1.week)
  end
  helper_method :get_weekly_menu_for_admin

  def get_previous_weekly_menu_for_admin
    Time.zone = "Pacific Time (US & Canada)"
    week_start = Time.zone.today.next_week.beginning_of_week(:monday) - 1.week
    week_end = Time.zone.today.next_week.end_of_week(:saturday) - 1.week

    @previous_weekly_menu = WeeklyMenu.find_by(week_start: week_start,  week_end: week_end)
  end
  helper_method :get_previous_weekly_menu_for_admin

  def get_weekly_menu_for_delivery
    Time.zone = "Pacific Time (US & Canada)"
    
    if Time.zone.today.strftime("%A") == "Monday" || Time.zone.today.strftime("%A") == "Tuesday"
      # if today is 13th Monday and 14th Tuesday
      # week_start should be 13 and week_end 17
      
      beginning_of_week = Time.zone.today.beginning_of_week
      end_of_week = Time.zone.today.beginning_of_week + 4.days

    elsif Time.zone.today.strftime("%A") == "Sunday"
      # if delivery day is sunday Sep 12th
      # week_start should be 13 and week_end 17
      beginning_of_week = Time.zone.today + 1.day
      end_of_week = Time.zone.today + 5.days
    end
    @weekly_menu = WeeklyMenu.find_by(week_start: beginning_of_week,  week_end: end_of_week)
  end
  helper_method :get_weekly_menu_for_delivery


  def format_date_for_display(date)
    date.strftime("%B %d")
  end
  helper_method :format_date_for_display

  def format_date_for_display_w_year(date)
    date&.strftime("%B %d, %Y")
  end
  helper_method :format_date_for_display_w_year

  def format_date_for_display_w_year_short(date)
    date.strftime("%b %d, %y")
  end
  helper_method :format_date_for_display_w_year_short

  def format_time_zone_and_display_w_day(date)
    set_local_time_zone

    date = format_date_for_display_w_year(Time.zone.now)
  end
  helper_method :format_time_zone_and_display_w_day

  def format_time_zone_and_display_with_day
    set_local_time_zone
    date = Time.zone.now.strftime("%A, %B %d, %Y")
  end
  helper_method :format_time_zone_and_display_with_day

  def today_date_with_time_zone
    set_local_time_zone
    
    Time.zone.today
  end
  helper_method :today_date_with_time_zone

  def current_time_with_time_zone
    set_local_time_zone

    Time.zone.now
  end
  helper_method :current_time_with_time_zone

  def set_local_time_zone
    Time.zone = "Pacific Time (US & Canada)"
  end

  def weekday_date_range
    set_local_time_zone

    begining_of_week = Time.zone.today.beginning_of_week(:monday)
    end_of_week = begining_of_week + 2.days

    date_range = [begining_of_week..end_of_week]
  end
  helper_method :weekday_date_range

  def get_weekday_date_range(date)
    begining_of_week = date.beginning_of_week(:monday)
    end_of_week = begining_of_week + 2.days

    date_range = [begining_of_week..end_of_week]
  end
  helper_method :get_weekday_date_range
  

  def is_between_weekly_date(date)
    set_local_time_zone

    begining_of_week = date.beginning_of_week(:monday)
    end_of_week = begining_of_week.end_of_week - 4.days

    (begining_of_week..end_of_week).cover?(date)
  end
  helper_method :is_between_weekly_date

  def weekend_date_range
    set_local_time_zone

    begining_of_week = Time.zone.today.end_of_week - 3.days
    end_of_week = begining_of_week + 2.days

    date_range = [begining_of_week..end_of_week]
  end
  helper_method :weekend_date_range

  def get_weekend_date_range(date)

    begining_of_week = date.end_of_week - 3.days
    end_of_week = begining_of_week + 2.days

    date_range = [begining_of_week..end_of_week]
  end
  helper_method :get_weekend_date_range


  #############################################
  # current lasagna count, quick fix


  def current_lasagna_count
    orders = Order.where(weekly_menu_id: get_weekly_menu.id, purchased: true)
    LineItem.where(order_id: orders.pluck(:id), food_id: 24).sum(:quantity)
  end
  helper_method :current_lasagna_count

  def current_food_item_ordered_count(food_id)
    orders = Order.where(weekly_menu_id: get_weekly_menu.id, purchased: true)
    LineItem.where(order_id: orders.pluck(:id), food_id: food_id).sum(:quantity)
  end
  helper_method :current_food_item_ordered_count

  def food_item_available_count(food_id)
    FoodItem.find_by(weekly_menu_id: get_weekly_menu.id, food_id: food_id).quantity
  end
  helper_method :food_item_available_count

  def current_butter_count
    orders = Order.where(weekly_menu_id: get_weekly_menu.id, purchased: true)
    LineItem.where(order_id: orders.pluck(:id), food_id: 96).sum(:quantity)
  end
  helper_method :current_butter_count

  def current_thai_count
    orders = Order.where(weekly_menu_id: get_weekly_menu.id, purchased: true)
    LineItem.where(order_id: orders.pluck(:id), food_id: 94).sum(:quantity)
  end
  helper_method :current_thai_count


  def redirect_if_not_admin
    redirect_to customer_dashboards_path unless current_user.is_admin
  end

  def order_meal_count(order)
    order.total_meal_count
  end
  helper_method :order_meal_count

  def other_category
    FoodCategory.where.not(name: "meal")
  end
  helper_method :other_category

  def other_foods
    other_foods = Food.where(food_category_id: other_category.ids, availability: true)
    other_foods = other_foods.order(short_name: :ASC)
  end
  helper_method :other_foods

  def filtered_other_foods_for_dashboard_display
    other_foods.group_by(&:food_group_id)
  end
  helper_method :filtered_other_foods_for_dashboard_display

  def vendor_other_foods
    vendor_food_items = Food.where(food_category_id: other_category.ids, vendor_menu: true)
    vendor_food_items = vendor_food_items.order(short_name: :ASC)
  end
  helper_method :vendor_other_foods

  def filtered_vendor_other_foods_for_dashboard_display
    vendor_other_foods.group_by(&:food_group_id)
  end
  helper_method :filtered_vendor_other_foods_for_dashboard_display

  def get_weekly_cook_on_date_range(weekly_menu)
    date_start = weekly_menu.week_end - 2.day - 1.week
    date_end   = weekly_menu.week_end + 2.day - 1.week

    date_start..date_end
  end 
  helper_method :get_weekly_cook_on_date_range


  #############################################

  def check_referrer(url)
    request.referrer.include?(url)
  end

  def get_meal_price(food)
    if food.food_type == "meal"
      if request.subdomain.include?("portal") && current_user.customer.on_subscription
        subscription_price = current_user.customer.subscription_price
        final_price = subscription_price.nil? ? food.retail_price : (food.discount_available ? subscription_price.price.to_f : food.retail_price)
        
        if !food.sale_price.blank?
          food.sale_price > final_price ? final_price : food.sale_price        
        else
          final_price
        end


      elsif !food.sale_price.blank?
        food.sale_price
      else
        food.retail_price
      end
    else 
      if !food.sale_price.blank?
        food.sale_price
      else
        food.retail_price
      end
    end

  end
  helper_method :get_meal_price

  def grouped_orders(orders, delivery_to)
    return if orders.nil?

    
    order_data = orders.joins(:customer).select("id", "customer_id", "total_meal_count", "weekly_menu_id", "customers.first_name", "customers.last_name", "customers.delivery_to",
    "customers.shipping_postal_code", "customers.company_name", "customers.shipping_address", "customers.unit", "customers.delivery_day", "employee_id", "position", "special")

        order_data = order_data.order([:special, :employee_id, :delivery_day, :position])

        # case delivery_to
        # when "home office"
        #     # order_data.where("customers.delivery_to": ["home", "office"]).group_by(&:shipping_address)
        #     order_data.where("customers.delivery_to": ["home", "office"]).group_by { |x| [x.shipping_address, x.unit] }
        # when "other"
        #     order_data.where.not("customers.delivery_to": ["home", "office"])
        # end

        order_data.group_by { |x| x.special }
  end

  def application_test
    puts "from application test"
  end

  def get_scheduled_employees(date)
    Employee.where(id: WorkSchedule.where(work_date: date).pluck(:employee_id))
  end
  helper_method :get_scheduled_employees

  def get_meals(weekly_menu_id)
    weekly_menu = WeeklyMenu.find(weekly_menu_id)

    weekly_menu.food_items.joins("LEFT OUTER JOIN foods ON foods.id = food_items.food_id")
    .select("id", "weekly_menu_id", "food_id", "foods.food_type", "eating_order")
    .where("foods.food_type = ?", "meal").where(vendor_only: false)
  end
  helper_method :get_meals

  def get_everything_but_meals(weekly_menu_id)
    weekly_menu = WeeklyMenu.find(weekly_menu_id)

    weekly_menu.food_items.joins("LEFT OUTER JOIN foods ON foods.id = food_items.food_id")
    .select("id", "weekly_menu_id", "food_id", "foods.food_type", "eating_order")
    .where("foods.food_type != ?", "meal")
  end
  helper_method :get_everything_but_meals

  def filter_weekly_menu
    if params[:date]
      @date_start = params[:date].to_date.beginning_of_week(:monday)
      @date_end   = params[:date].to_date.end_of_week
    else
      @date_start = Date.today.beginning_of_week(:monday)
      @date_end   = Date.today.end_of_week
    end

    @find_weekly_menu = WeeklyMenu.find_by(week_start: @date_start.next_week)
  end

  def get_prep_date_range
    date = params[:date].to_date
    @prep_date_range = params[:work_day] == "weekday" ? [date..date + 2.days]: [date + 3.days..date + 5.days]
  end
  helper_method :get_prep_date_range

  def perform_in_day(order)
		today = format_time_zone_and_display_with_day.to_date
		((order.weekly_menu.week_end - 1.day) - today).to_i
	end

  private
  
  def render_404(exception = nil)
      if exception
          logger.info "Rendering 404: #{exception.message}"
      end
      
      message = create_error_message_for_sms(exception)
      
      Twilio::SendSms.new(message).send_sms
      render :file => "#{Rails.root}/public/404.html", :status => 404, :layout => false
  end

  def create_error_message_for_sms(exception_object)
    <<-HEREDOC.strip_heredoc
      name: #{current_user.customer.first_name}
      email: #{current_user.customer.email}
      controller: #{controller_name}
      action: #{action_name}
      error: #{exception_object.message}
      backtrace[0]: #{exception_object.backtrace[0]} 
      backtrace[1]: #{exception_object.backtrace[1]}
    HEREDOC
  end

  def filtered_vendor_orders(delivery_day)
		case delivery_day.to_date.strftime("%a").downcase

		when "thu"
			cook_date = delivery_day.to_date - 1.day
		when "sun"
			cook_date = delivery_day.to_date
		when "mon"
			cook_date = delivery_day.to_date - 1.day
		end
    
		vendor_orders = TempOrder.where(cook_on: cook_date.to_date, delivery_day: [delivery_day.to_date.strftime("%a").downcase, delivery_day.to_date.strftime("%A").downcase])
	end
  helper_method :filtered_vendor_orders

  protected

  def after_sign_in_path_for(resource)

    if current_user.is_admin || current_user.manager?
      dashboards_path(subdomain: 'portal')
    elsif current_user.user_type == "vendor"
      vendor_dashboards_path(subdomain: "portal")
    # elsif current_user.customer.employee&.position == "driver"
    #   root_url(subdomain: "delivery") + "vendor_deliveries"
    else
      customer_dashboards_path(subdomain: 'portal')
    end
  end

  def after_sign_out_path_for(resource_or_scope)
    new_user_session_path(subdomain: "portal")
  end

  def production
    (Rails.env == "production") && (params[:controller] == "products" && params[:action] == "choose_plan" && params[:subdomain] == "shop")
  end

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:account_update, keys: [:user_type])
  end

end
  