class FoodReviewsController < ApplicationController
  skip_before_action :authenticate_user!, only: [:weekly_food_review, :create, :update]

  def index
    @orders = current_user.customer.orders.where(purchased: true)
  end

  def new
    @order = Order.find(params[:order_id])
    @food_review = FoodReview.new 
  end

  def create
    @order = Order.find(params[:food_review][:order_id])
    food = Food.find(params[:food_review][:food_id])
    food_review = food.food_reviews.build(food_review_params)
    food_review.customer_id = @order.customer.id

    if food_review.save
        respond_to do |format|
        format.html { redirect_to new_member_weekly_menu_path }
        format.js { @food = Food.find(params[:food_review][:food_id]) }
      end
    else
      render :new
    end
  end

  def edit
    @food_review = FoodReview.find(params[:id])
    @food = Food.find(params[:food_id])
  end

  def update
    @order = Order.find(params[:food_review][:order_id])
    @food_review = FoodReview.find(params[:id])
    @food = @food_review.food

    if @food_review.update(food_review_params)
      respond_to do |format|
        format.html { redirect_to new_member_weekly_menu_path }
        format.js { @food_review }
      end
      
    else
      render :edit
    end
  end

  def weekly_food_review
    @order = Order.find(params[:order_id])
    @food_review = FoodReview.new 
	end

  private

  def food_review_params
    params.require(:food_review).permit(:ratings, :review, :food_id, :customer_id, :order_ref_id)
  end

end

 