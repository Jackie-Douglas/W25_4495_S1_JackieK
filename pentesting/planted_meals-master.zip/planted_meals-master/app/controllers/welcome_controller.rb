class WelcomeController < ApplicationController
  skip_before_action :authenticate_user!
  before_action :get_weekly_menu_for_admin
  # before_action :get_weekly_menu


  def index
    #render file: "#{Rails.root}/app/views/layouts/thank_you_purchase.html.erb"
  end
  
  def delivery_test
    # @current_user = current_user
    # @order_info = Order.find(32154)
    # @customer_info = Customer.find(@order_info.customer_id)    
    # @message = "Your card has been delicned, please check with your provider"
    
    # @meals = @weekly_menu.food_items.where(food_id: Food.where(food_type: "meal")).where.not(food_id:  29).joins("LEFT JOIN foods ON foods.id = food_items.food_id").select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions").order("eating_order" => "ASC")
    # @others = @weekly_menu.food_items.where.not(food_id: Food.where(food_type: "meal")).where.not(food_id: [89, 93, 92]).joins("LEFT JOIN foods ON foods.id = food_items.food_id").select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions").order("eating_order" => "ASC")
    # @current_user = User.find(5)
    # add_on_items
    # @gift_card = GiftCard.first
    # # render file: "#{Rails.root}/app/views/gift_card_mailer/gift_card_email.html.erb", layout: false
    @line_items = Order.find(45230).line_items.where.not(quantity: 0)
    render file: "#{Rails.root}/app/views/notification_mailer/weekly_food_review_notification.html.erb", layout: false
    
    # render file: "#{Rails.root}/app/views/user_sign_up_update_notification_mailer/account_update_email.html.erb", layout: false
    # render file: "#{Rails.root}/app/views/layouts/weekly_menu_template.html.erb", layout: false
    # render file: "#{Rails.root}/app/views/referral_mailer/referral_email.html.erb", layout: false
    # render file: "#{Rails.root}/app/views/referral_mailer/referral_email.html.erb", layout: false
  end

  def tracking
    tracker = Tracker.find_by(action: params.keys.first)

    if !tracker.nil?
      count = tracker.count += 1
      tracker.update_columns(count: count)
    else 
      Tracker.create(action: params.keys.first)
    end

    head 200
  end

  def meal_items
    @meals = @weekly_menu.food_items.where(food_id: Food.where(food_type: "meal"))
    .joins("LEFT JOIN foods ON foods.id = food_items.food_id")
    .select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions")
    .order("eating_order" => "ASC")
  end

  def add_on_items
        @others = @weekly_menu.food_items.where.not(food_id: Food.where(food_type: "meal")).where.not(food_id: [89, 93, 92, 139])
        .joins("LEFT JOIN foods ON foods.id = food_items.food_id")
        .select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions")
        .order("eating_order" => "ASC")
    end


end




