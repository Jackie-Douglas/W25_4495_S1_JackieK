class VendorDashboardsController < ApplicationController
	# before_action :get_weekly_menu_for_admin
	before_action :get_weekly_menu

	def index
		rotating_food = Food.where(id: get_food_id_from_rotating_menu)
		@vendor = current_user.vendor

		@thu_order = TempOrder.new
		@thu_menu = Food.where(vendor_menu: true, availability: true)

		@thu_menu.each do |f|
			@thu_order.line_items.build(name: f.name, food_id: f.id, price: f.wholesale_price)
		end

		@sun_order = TempOrder.new
		@sun_menu = Food.where(vendor_menu: true, availability: true) + rotating_food

		@sun_menu.uniq.each do |f|
			@sun_order.line_items.build(name: f.name, food_id: f.id, price: f.wholesale_price)
		end

		@mon_order = TempOrder.new
		@foods = Food.where(vendor_menu: true, availability: true)

		@mon_menu = @foods + rotating_food

		@mon_menu.uniq.each do |f|
			@mon_order.line_items.build(name: f.name, food_id: f.id, price: f.wholesale_price)
		end
	end

	def review_order
		@order = TempOrder.find(params[:order_id])
		@vendor = @order.vendor
	end

	def vendor_order_history
		@orders = current_user.vendor.temp_orders
	end

	def confirm_order
		@order = TempOrder.find(params[:order_id])
		@order.update_columns(purchased: true)

		redirect_to temp_order_path(@order.id)
	end

	def edit
		@order = TempOrder.find(params[:id])
		@vendor = @order.vendor 
	end

	private

	def get_food_id_from_rotating_menu
		meal_ids = Food.where(food_type: "meal").pluck(:id)
		meals = @weekly_menu.food_items.where(food_id: meal_ids).pluck(:food_id)
	end
end
