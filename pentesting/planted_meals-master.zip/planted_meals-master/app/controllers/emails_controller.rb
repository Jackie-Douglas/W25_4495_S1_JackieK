class EmailsController < ApplicationController
    before_action :authenticate_admin

    def index
        @emails = EmailTemplate.all
    end

    def edit
        @email = EmailTemplate.find(params[:id])
    end

    def update
        @email = EmailTemplate.find(params[:id])
        if @email.update_attributes(email_template_params)
            Klaviyo::CrudTemplate.new(@email).update
            redirect_to email_path(@email.id), notice: "Updated"
        else 
            render :edit
        end
    end
    
    def show
        @email_template = EmailTemplate.find(params[:id])
        render layout: false
    end

    def send_email
        email_template = EmailTemplate.find(params[:email_id])
        
        if email_template.email_type == "weekly_menu"
            result = Klaviyo::SendWeeklyMenuCampaign.new(email_template).send_campaign
        else
            # SendEmailWorker.perform_async(params[:email_id])
            puts ">>>>>>>>>send email from email controlle"

            Klaviyo::SendEatingOrderCampaign.new(email_template).send_campaign
        end
        
        redirect_to emails_path, notice: "Successfully Sent"
    end

    def destroy
        @email_template = EmailTemplate.find(params[:id])
        
        ActiveRecord::Base.transaction do
            @email_template.destroy    
            Klaviyo::CrudTemplate.new(@email_template).destroy
        end
        
        redirect_to emails_path, notice: "Successfully Removed"
    end


    private

    def email_template_params
        params.require(:email_template).permit(:html_code, :email_type, :weekly_menu_id, :subject, :list_ref_id)
    end

end