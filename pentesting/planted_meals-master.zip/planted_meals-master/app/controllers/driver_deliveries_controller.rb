class DriverDeliveriesController < ApplicationController
	require "csv"
	before_action :get_weekly_menu_for_admin
	before_action :customer_orders, except: [:index, :assign_driver, :remove_driver, :vendor_driver_index, :vendor_driver_show, :assign_vendor_driver, :remove_vendor_driver]
	before_action :authenticate_admin

	def index
		@weekly_menu = WeeklyMenu.order(created_at: "DESC").limit(5)
	end

	def driver_index
		@drivers = Employee.where(position: "driver")
		@lat_and_lng = @orders.joins(:customer).select("id", "customers.latitude", "customers.longitude", "employee_id", "customers.delivery_to", "customers.phone", "customers.shipping_address", "customers.shipping_city", "customers.first_name").map do |x| 
			first_name = x.employee_id.nil? ? "" : Employee.find(x.employee_id).customer.first_name.downcase
			shipping_address = "#{x.shipping_address}, #{x.shipping_city}"
			phone = x.phone
			delivery = x.delivery_to
			{ lat: x.latitude, 
				lng: x.longitude, 
				name: first_name.gsub(" ", "\\"),
				customerName: x.first_name.gsub(" ", "\\"),
				shippingAddress: shipping_address.gsub(" ", "\\"),
				phone: phone,
				delivery_to: delivery
			}
		end
	end

	def vendor_driver_index
		@drivers = Employee.where(position: "driver")
	end

	def show
		@employee = Employee.find(params[:id])
		# @orders = @weekly_menu.orders.where(purchased: true)
		@driver_orders = @orders.where(employee_id: @employee.id)
		@req_orders = @orders.where(employee_id: nil).joins(:customer).select("id", "customer_id", "employee_id", "customers.shipping_city").order("customers.shipping_city")
		@grouped_orders_by_city = @req_orders.joins(:customer).select("id", "customers.shipping_city").group_by { |x| x.shipping_city }
	end

	def vendor_driver_show
		@employee = Employee.find(params[:id])

		@vendor_orders = filtered_vendor_orders(params[:delivery_date])
		@assigned_vendor_orders = @vendor_orders.where(employee_id: @employee.id)
		@req_orders = @vendor_orders.where(employee_id: nil)
	end

	def assign_vendor_driver
		@vendor_order = TempOrder.find(params[:temp_order_id])
		@vendor_order.update(employee_id: params[:driver_id])
		@updated_vendor_order = @vendor_order

		@employee = Employee.find(params[:driver_id])
		@vendor_orders = filtered_vendor_orders(params[:delivery_date])
		@assigned_vendor_orders = @vendor_orders.where(employee_id: params[:id])
		@req_orders = @vendor_orders.where(employee_id: nil)

		respond_to do |format|
			format.html
			format.js
		end
		# redirect_to driver_delivery_path(params[:driver_id])
	end

	def assign_driver
		@order = Order.find(params[:order_id])
		@order.update_attributes(employee_id: params[:driver_id])
		@updated_order = @order

		@employee = Employee.find(params[:driver_id])
		@orders = @weekly_menu.orders.where(purchased: true)
		@driver_orders = @orders.where(employee_id: @employee.id)
		@req_orders = @orders.where(employee_id: nil)

		respond_to do |format|
				format.html
				format.js
		end
		# redirect_to driver_delivery_path(params[:driver_id])
	end

	def remove_vendor_driver
		@vendor_order = TempOrder.find(params[:temp_order_id])
		@vendor_order.update(employee_id: nil)

		@vendor_orders = filtered_vendor_orders(params[:delivery_date])
		@req_orders = @vendor_orders.where(employee_id: nil)

		respond_to do |format|
				format.html
				format.js
		end
		# redirect_to driver_delivery_path(params[:driver_id])
	end

	def remove_driver
		@order = Order.find(params[:order_id])
		@order.update_columns(employee_id: nil)
		@orders = @weekly_menu.orders.where(purchased: true)
		@req_orders = @orders.where(employee_id: nil)

		respond_to do |format|
				format.html
				format.js
		end
		# redirect_to driver_delivery_path(params[:driver_id])
	end

	def download_csv
		driver_id = params[:driver_id]
		weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
		orders = weekly_menu.orders.where(purchased: true, employee_id: driver_id).where.not(customer_id: orders_to_exclude)
		employee = Employee.find(driver_id).customer
		

		respond_to do |format|
				format.csv { send_data csv_information(Customer.where(id: orders.pluck(:customer_id))), filename: "#{employee.first_name}, delivery list for #{display_delivery_week(weekly_menu.id)}.csv" }
		end
	end

	def import_delivery_id_from_last_week
		# get the weekly_menu_id
		# get week start and week end date and go back 7 days
		# loop through last weeks and find the order by customer id and if the order existis update with employee_id
		@weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
		week_start = @weekly_menu.week_start - 7.days
		week_end = @weekly_menu.week_end - 7.days

		@previous_weekly_menu = WeeklyMenu.find_by(week_start: week_start, week_end: week_end).orders.where(purchased: true).where.not(customer_id: orders_to_exclude)
														
		@previous_weekly_menu.each do |x|
			customer_id = x.customer_id
			is_ordered = @orders.find_by(customer_id: customer_id)   

			next if is_ordered.nil?

			previous_employee_id = x.employee_id
			if is_ordered
				is_ordered.update_columns(employee_id: previous_employee_id)
			end
		end

		redirect_to all_drivers_path(weekly_menu_id: params[:weekly_menu_id])
	end

	def import_from_cigo
		ImportCigoWorker.perform_async(params[:weekly_menu_id])
		redirect_to driver_deliveries_path
	end

	private

	def customer_orders
		@orders = WeeklyMenu.find(params[:weekly_menu_id]).orders.where(purchased: true).where.not(customer_id: orders_to_exclude)
	end

	def orders_to_exclude
		pick_up_id = Delivery.find_by(delivery: "pick up").id
		pick_up_customers = Customer.where(delivery_id: pick_up_id).pluck(:id)
		employee_ids = Employee.pluck(:customer_id)
		combined_ids = employee_ids + pick_up_customers
	end

	def csv_information(customer_data)
		attributes = %w{first_name last_name phone_number mobile_number	email_address address apt postal_code delivery_date branch_id preference comments}

		CSV.generate(headers: true) do |csv|
			csv << attributes

			customer_data.each do |customer|
				csv << [customer.first_name, customer.last_name, customer.phone, customer.phone, customer.email, "#{customer.shipping_address}, #{customer.shipping_city}", 
								customer.unit, customer.shipping_postal_code, "", 1, "", "Buzzer: #{customer.buzzer}, "",  Note: #{customer.delivery_note}"]
			end
		end
	end


	def display_delivery_week(weekly_menu_id)
		weekly_menu = WeeklyMenu.find(weekly_menu_id)
		week_start = format_date_for_display_w_year(weekly_menu.week_start)
		week_end = format_date_for_display_w_year(weekly_menu.week_end)
		
		"#{week_start} - #{week_end}"
	end
end







# var totalCount = $("#total_order_count")[0].innerText
# var totalCount = parseInt(totalCount) + 1
# $("#total_order_count").html(totalCount)

# var assignedCount = $("#assigned_delivery_count")[0].innerText
# var assignedCount = parseInt(assignedCount) - 1
# $("#assigned_delivery_count").html(assignedCount)