class AnalyticsController < ApplicationController
	include WorkHoursHelper
	before_action :authenticate_admin

	def index
		date_range
		
		respond_to do |format|
			format.html
			if params[:type] == 'weekly'
				format.csv { send_data weekly_csv_information(date_range), filename: "Meal weekly Analytics.csv" }
			elsif params[:type] == 'daily hour'
				format.csv { send_data daily_labour_hour_csv_information, filename: "Daily Labour Hour.csv" }
			else
				format.csv { send_data csv_information(date_range), filename: "Meal Weekend Analytics.csv" }
			end
		end
	end

	def coupon_usage
		@coupons = CouponUsage.where(id: params[:coupon_ids], purchased: true)
	end

	private

	def daily_labour_hour_csv_information
		array = Array.new
		date_range = params[:start].to_date..params[:end].to_date

		date_range.each_with_index do |d, index|
			work_hours = WorkHour.where(work_date: d)
			total_work_hours = calculate_total_hours(work_hours)
			date = d.strftime("%^a | %b %d, %Y")
			
			array << [date, total_work_hours, index]
		end

		array = array.sort {|a,b| b[2] <=> a[2]}

		CSV.generate do |csv|
			date = array.collect { |ind| ind[0] }
			hours = array.collect { |ind| ind[1] }

			csv << date
			csv << hours
		end
	end

	def date_range
		if (params[:start].nil? && params[:end].nil?)
			@start_date = Date.today - 4.months
			@end_date = Date.today + 1.week
			@date_range = @start_date..@end_date
			@weekly_menus_search_result = WeeklyMenu.where(week_start: @date_range).order(:week_start)
		else
			@start_date = params[:start].to_date
			@end_date = params[:end].to_date
			@date_range = @start_date..@end_date
			@weekly_menus_search_result = WeeklyMenu.where(week_start: @date_range).order(:week_start)
		end
	end

	def csv_information(weekly_menus)
		hash_data = Hash.new{ |h,k| h[k] = Hash.new({}) }
		work_hour_data = Array.new
		dollar_value_data = Array.new
		dollar_value = 0
					
		weekly_menus.each do |x|
			order_ids = x.orders.where(purchased: true).ids
			
			grouped_line_items = LineItem.where(order_id: order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					hash_data[cook_date][line_item.name] = (hash_data[cook_date][line_item.name].blank? ? 0 : hash_data[cook_date][line_item.name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			grouped_line_items = LineItem.where(order_id: order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where.not("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					hash_data[cook_date][line_item.name] = (hash_data[cook_date][line_item.name].blank? ? 0 : hash_data[cook_date][line_item.name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			cook_on_date = x.week_start - 1.day
			temp_order_ids = TempOrder.where(cook_on: cook_on_date).ids
			grouped_line_items = LineItem.where(temp_order_id: temp_order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					vendor_item_name = "V |" + " #{line_item.name}"
					hash_data[cook_date][vendor_item_name] = (hash_data[cook_date][vendor_item_name].blank? ? 0 : hash_data[cook_date][vendor_item_name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			cook_on_date = x.week_start - 5.day
			temp_order_ids = TempOrder.where(cook_on: cook_on_date).ids
			grouped_line_items = LineItem.where(temp_order_id: temp_order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where.not("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					vendor_item_name = "V |" + " #{line_item.name}"
					hash_data[cook_date][vendor_item_name] = (hash_data[cook_date][vendor_item_name].blank? ? 0 : hash_data[cook_date][vendor_item_name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			grouped_line_items = LineItem.where(order_id: order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where.not("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					hash_data[cook_date][line_item.name] = (hash_data[cook_date][line_item.name].blank? ? 0 : hash_data[cook_date][line_item.name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			work_hour_date_range = (x.week_start - 3.day)..(x.week_start - 1.day)
			work_hours = WorkHour.where(work_date: work_hour_date_range)
			work_hour_data << [work_hour_date_range, calculate_total_hours(work_hours)]
			dollar_value_data << dollar_value.round
			dollar_value = 0
		end


		CSV.generate do |csv|
			date = hash_data.keys

			date.each_with_index do |d, index|
				csv <<  hash_data[d].keys.prepend([nil, nil]).prepend(d).flatten
				csv << hash_data[d].values.prepend(work_hour_data[index]).prepend("count").flatten
				csv << ["Dollar Value", dollar_value_data[index]]
			end

			# 2.times do 
			#     csv << ["date", "meal1", "meal2", "meal3", "meal4"]
			#     csv << ["count", "100", "200", "300", "400"]
			# end
		end
	end

	def weekly_csv_information(weekly_menus)
		hash_data = Hash.new{ |h,k| h[k] = Hash.new({}) }
		work_hour_data = Array.new
		dollar_value_data = Array.new
		dollar_value = 0

					
	weekly_menus.each do |x|
			order_ids = x.orders.where(purchased: true).ids
			grouped_line_items = LineItem.where(order_id: order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0
					cook_date = x.week_start - 1.day
					hash_data[cook_date][line_item.name] = (hash_data[cook_date][line_item.name].blank? ? 0 : hash_data[cook_date][line_item.name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			cook_on_wed_date = x.week_start - 5.day
			cook_on_sun_date = x.week_start - 1.day
			
			temp_order_ids = TempOrder.where(cook_on: [cook_on_wed_date, cook_on_sun_date]).ids
			grouped_line_items = LineItem.where(temp_order_id: temp_order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0

					cook_date = x.week_start - 1.day
					vendor_item_name = "V |" + " #{line_item.name}"
					hash_data[cook_date][vendor_item_name] = (hash_data[cook_date][vendor_item_name].blank? ? 0 : hash_data[cook_date][vendor_item_name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			grouped_line_items = LineItem.where(temp_order_id: temp_order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where.not("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0

					cook_date = x.week_start - 1.day
					vendor_item_name = "V |" + " #{line_item.name}"
					hash_data[cook_date][vendor_item_name] = (hash_data[cook_date][vendor_item_name].blank? ? 0 : hash_data[cook_date][vendor_item_name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			grouped_line_items = LineItem.where(order_id: order_ids).joins("INNER JOIN foods ON  food_id = foods.id").where.not("foods.food_type": "meal").group_by { |x| x.name }
			keys = grouped_line_items.keys

			keys.each do |key|
				grouped_line_items[key].each do |line_item|
					next if line_item.quantity == 0

					cook_date = x.week_start - 1.day
					hash_data[cook_date][line_item.name] = (hash_data[cook_date][line_item.name].blank? ? 0 : hash_data[cook_date][line_item.name]) + line_item.quantity
					dollar_value += (line_item.quantity * line_item.price.to_f)
				end
			end

			work_hour_date_range = (x.week_start - 7.day)..(x.week_start - 1.day)
			work_hours = WorkHour.where(work_date: work_hour_date_range)
			work_hour_data << [work_hour_date_range, calculate_total_hours(work_hours)]
			dollar_value_data << dollar_value.round
			dollar_value = 0
		end


		CSV.generate do |csv|
			date = hash_data.keys

			date.each_with_index do |d, index|
					csv <<  hash_data[d].keys.prepend([nil, nil]).prepend(d).flatten
					csv << hash_data[d].values.prepend(work_hour_data[index]).prepend("count").flatten
					csv << ["Dollar Value", dollar_value_data[index]]
			end

				# 2.times do 
				#     csv << ["date", "meal1", "meal2", "meal3", "meal4"]
				#     csv << ["count", "100", "200", "300", "400"]
				# end
		end
	end
end
