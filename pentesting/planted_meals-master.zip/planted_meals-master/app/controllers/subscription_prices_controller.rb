class SubscriptionPricesController < ApplicationController

    def index
        @subscription_prices = SubscriptionPrice.all
    end

    def new
        @subscription_price = SubscriptionPrice.new
    end

    def create
        @subscription_price = SubscriptionPrice.new(subscription_price_params)
        
        if @subscription_price.save
            redirect_to subscription_prices_path
        else
            render :new
        end
    end



    private
    
    def subscription_price_params
        params.require(:subscription_price).permit(:price)
    end

end