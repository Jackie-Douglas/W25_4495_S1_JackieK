class FoodItemsController < ApplicationController
	before_action :get_weekly_menu_for_admin

	def new
		@weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
		@food_item = FoodItem.new
	end

	def create
		@food_item = FoodItem.new(food_item_params)
		@food_item.weekly_menu_id = params[:weekly_menu_id]

		if @food_item.save
			redirect_to edit_weekly_menu_path(params[:weekly_menu_id]) 
		else
			render :new
		end
	end

	def show
		@food_item = FoodItem.find(params[:id])
		order_ids = WeeklyMenu.find(params[:weekly_menu_id]).orders.purchased_orders.ids
		@line_items = LineItem.where(order_id: order_ids)  
	end

	def destroy
		food_item = FoodItem.find_by(weekly_menu_id: params[:weekly_menu_id], id: params[:id])
		food_item.destroy
		redirect_to edit_weekly_menu_path(params[:weekly_menu_id]) 
	end

	private

	def food_item_params
		params.require(:food_item).permit(:food_id, :weekly_menu_id, :quantity, :vendor_order_quantity)
	end
end