class  VendorIngredientOrdersController < ApplicationController

  def create
    vendor_ingredient_order = VendorIngredientOrder.new(vendor_ingredient_order_params)

    redirect_to weekly_menu_path(vendor_ingredient_order.weekly_menu_id) if vendor_ingredient_order.save
  end

  def update
    vendor_ingredient_order = VendorIngredientOrder.find(params[:id])

    redirect_to weekly_menu_path(vendor_ingredient_order.weekly_menu_id) if vendor_ingredient_order.update(vendor_ingredient_order_params)
  end

  private

  def vendor_ingredient_order_params
    params.require(:vendor_ingredient_order).permit(:unit, :quantity, :weekly_menu_id, :order_date, :vendor_name, :ingredient_id)
  end

end



