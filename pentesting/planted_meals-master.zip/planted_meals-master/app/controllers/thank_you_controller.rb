class ThankYouController < ApplicationController
	skip_before_action :authenticate_user!
	before_action :get_weekly_menu

	def index
		@order = Order.find(params[:order_id])
		count = @order.render_count + 1
		@order.update_columns(render_count: count)
	end
end