class ProductsController < ApplicationController
	skip_before_action :authenticate_user!
	before_action :get_weekly_menu, only: [:review_checkout, :checkout]

	def choose_plan;end

  def food;end

	def delivery
		@order = Order.find(params[:order_id])
		@customer_id = @order.customer_id

		if @customer_id
				@customer = Customer.find(@customer_id)
		else
				@customer = Customer.new
		end

		@subtotal = @order.subtotal
	end
    
	def review_checkout
		@order = Order.find(params[:order_id])
		@customer = Customer.find(@order.customer_id)
	end
    
	def checkout
		@order = Order.find(params[:order_id])
		@customer = Customer.find(@order.customer_id)
	end

	############subdomain: "admin"##################
	def new
		@product = Product.new
	end
	################################################

	def validate_coupon
		result = CouponValidation.new({coupon_code: params[:coupon_code].downcase, 
																		order_id: params[:order_id]}).call

		coupon = Coupon.find_by(coupon_code: params[:coupon_code].downcase)
		uuid = params[:uuid].nil? ? "" : "&uuid=#{params[:uuid]}" 

		if result
			redirect_to (checkout_path(order_id: params[:order_id], coupon_id: coupon.uuid) + uuid), notice: "Coupon has been applied"    
		else
			redirect_to (checkout_path(order_id: params[:order_id]) + uuid), notice: "Coupon is not valid or it has already been used"
		end
	end

	def strip_trailing_zero(n)
			n.to_s.sub(/\.?0+$/, '')
	end
end
