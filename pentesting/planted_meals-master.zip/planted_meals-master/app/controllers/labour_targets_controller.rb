class LabourTargetsController <  ApplicationController
	before_action :get_weekly_menu_for_admin
	before_action :authenticate_admin, only: :index
	skip_before_action :authenticate_admin, only: :show
	skip_before_action :authenticate_user!, only: :show

	def index
		@labour_target = LabourTarget.new
		@q = WeeklyMenu.ransack(params[:q])

		if params[:q].nil?
			@weekly_menus = WeeklyMenu.last(10).sort {|a,b| b <=> a }
		else
			@weekly_menus = WeeklyMenu.where(week_start: params[:q]["week_start_eq"].to_date..params[:q]["week_end_eq"].to_date).sort {|a,b| b <=> a }
		end
	end

	def create
		@labour_target = LabourTarget.new(labour_target_params)

		if @labour_target.save
			redirect_to labour_targets_path
		else
			redirect_to labour_targets_path 
		end
	end

	def edit
		@labour_target = LabourTarget.find(params[:id])
	end

	def update
		@labour_target = LabourTarget.find(params[:id])

		if @labour_target.update_attributes(labour_target_params)
			redirect_to labour_targets_path
		else
			render :edit
		end
	end

	def destroy
		@labour_target = LabourTarget.find(params[:id])
		@labour_target.destroy
		
		redirect_to labour_targets_path
	end

	def show
		@labour_target = LabourTarget.last(2).first
	end

	private

	def labour_target_params
		params.require(:labour_target).permit(:weekly_menu_id, :description)
	end
end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             