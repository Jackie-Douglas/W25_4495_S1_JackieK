class SettingsController < ApplicationController
    def index
        
    end

    def delivery_edit
        @customer = current_user.customer || current_user.vendor
    end

    def delivery_update
        @customer = current_user.customer || current_user.vendor

        if @customer.update_attributes(customer_params)
            path = request.referrer.include?("order_id") ? member_review_checkout_path(order_id: request.referrer.split("order_id=").last.to_i) : delivery_edit_path
            redirect_to path, notice: "Information sucessfully updated"
        else
            render :delivery_edit
        end

    end

    def billing_edit
        @billing = current_user.customer.stripe_info
    end

    def update_credit_card_info

        stripe_result = Stripe::ChargeCustomer.new(current_user, nil, nil, nil, nil, nil, params[:stripeToken], 0.0, root_url).update_card_information

        if stripe_result == nil
            redirect_to billing_edit_path, notice: "Credit card information updated"
                
        else
            body = stripe_result.json_body
            error = body[:error]
            @message = error[:message]
            render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
        end
        
        
    end

    private

    def customer_params
        if current_user.vendor
            params.require(:vendor).permit(:first_name, :last_name, :email, :phone, 
                                    :shipping_address, :shipping_city, :shipping_province, 
                                    :shipping_country, :shipping_postal_code, :company_name,
                                    :store_name
                                    )
        else
            params.require(:customer).permit(:delivery_to, :shipping_address, :shipping_city, 
                                        :shipping_province, :shipping_country, :shipping_postal_code,
                                        :unit, :buzzer, :company_name, :delivery_day, :delivery_id,
                                        :first_name, :last_name, :phone, :delivery_note, :food_note,
                                        :unit_type, :email
                                        )
        end
                                        
    end

    
end