class AdminBagTrackersController < ApplicationController
    before_action :authenticate_admin
    
    def index
        @employee_ids = Employee.pluck(:customer_id)
        @bags = BagTracker.where.not(customer_id: @employee_ids)
    end

    def edit
        @bag = BagTracker.find(params[:id])
    end

    def update
        @bag = BagTracker.find(params[:id])

        if @bag.update_attributes(bag_tracker_params)
            redirect_to admin_bag_trackers_path
        else
            render :edit
        end
    end

    private

    def bag_tracker_params
        params.require(:bag_tracker).permit(:counter)
    end


end