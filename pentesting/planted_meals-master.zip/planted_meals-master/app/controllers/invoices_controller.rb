class InvoicesController < ApplicationController
	require "csv"

	def index
		if params[:vendor] == "em"
			@vendors = Vendor.where(everyday_meals: true)
		else
			@vendors = Vendor.all
		end
	end

	def invoice_index
		@orders = TempOrder.all
	end

	def create
		from = params[:from]
		to = params[:to]
		vendor_ids = params[:vendor_ids]

		orders = vendor_ids.map do |vendor|
				if params[:vendor] == "em"
					orders = TempOrder.where(vendor_id: vendor, everyday_meals: true)
				else
					orders = TempOrder.where(vendor_id: vendor, everyday_meals: false)
				end
				filtered_orders = orders.where(invoice_date: from..to).order(invoice_date: "ASC")
		end

		attributes = %w{Name Invoice_Number PO_Number Invoice_date Subtotal}

		csv = CSV.generate(headers: true) do |csv|
				
				csv << attributes

				orders.each do |order|
						order.each do |o|
								csv << [o.vendor.company_name, o.invoice_number, o.po_number, o.invoice_date, "$#{o.subtotal}"]
						end
				end

		end

		send_data csv, filename: "#{from} - #{to}.csv" 
	end
    
end