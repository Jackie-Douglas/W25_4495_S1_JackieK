class IngredientsController < ApplicationController 
  layout 'inventory_layout'
  before_action :set_ingredient, only: :new
  before_action :find_ingredient, only: :update
  before_action :authenticate_admin_or_manger
  # before_action :get_weekly_menu
  before_action :get_weekly_menu_for_inventory

  def index
    @weekly_menu = WeeklyMenu.find(params[:weekly_menu_id].nil? ? @weekly_menu.id : params[:weekly_menu_id])
    redirect_to ingredients_path(date: today_date_with_time_zone.on_weekday? ? "weekday" : "weekend", weekly_menu_id: @weekly_menu.id) if params[:date].nil?

    @ingredient_categories = IngredientCategory.includes(:ingredients)

    food_ids                       = get_meals(@weekly_menu.id).pluck(:food_id)
    vendor_food_ids                = Food.where(vendor_menu: true).pluck(:id)
    other_food_ids                 = get_everything_but_meals(@weekly_menu.id).pluck(:food_id).uniq
    
    all_item_ids                   = food_ids + vendor_food_ids + other_food_ids
    all_recipe_ids                 = Recipe.where(food_id: all_item_ids.uniq)
    vendor_recipe_ids              = Recipe.where(food_id: vendor_food_ids)
    @recipe_ingredient_ids         = RecipeIngredient.where(recipe_id: all_recipe_ids).pluck(:ingredient_id).uniq
    @vendor_recipe_ingredient_ids  = RecipeIngredient.where(recipe_id: vendor_recipe_ids).pluck(:ingredient_id).uniq

    # @weekday_inventory_ingredients = Ingredient.find(@recipe_ingredient_ids)
    # @weekend_inventory_ingredients = Ingredient.find(@vendor_recipe_ingredient_ids)
    @weekday_inventory_ingredients = Ingredient.where(id: @recipe_ingredient_ids)
    @weekend_inventory_ingredients = Ingredient.where(id: @vendor_recipe_ingredient_ids)
  end

  def all_ingredients
    @ingredient_categories = IngredientCategory.includes(:ingredients)

    @q = Ingredient.ransack(params[:q])
    @result = @q.result(distinct: true) 
    @results = @result.group_by { |x| x.ingredient_category_id }
  end

  def all_ingredient_lists_index
    @ingredients = Ingredient.order(:position)
  end

  def new;end

  def create
    @ingredient = Ingredient.new(ingredient_params)

    if @ingredient.save
      redirect_to ingredients_path
    else
      render :new
    end
  end

  def update 
    if @ingredient.update(ingredient_params)
      respond_to do |format|
        format.html { redirect_to ingredients_path }
        format.js {}
      end
    else
      redirect_to ingredients_path
    end
  end

  def download_inventory_csv
    respond_to do |format|
      format.csv { send_data(csv_information) }
    end
  end

  def reset_ingredient
    @ingredient = Ingredient.find(params[:ingredient_id])
    @ingredient.update(updated_at: DateTime.now - 3.days)

    respond_to do |format|
      format.js
    end
  end

  def toggle_flag
    @ingredient = Ingredient.find(params[:id])

    @ingredient.toggle!(:is_flagged)
    respond_to do |format|
      format.js
    end
  end

  def destroy
    @ingredient = Ingredient.find(params[:id])
    
    if @ingredient.ingredient_group_id
      updated_ingredient_id = Ingredient.where(ingredient_group_id: @ingredient.ingredient_group_id).where.not(id: @ingredient.id).first.id
      @ingredient.recipe_ingredients.update_all(ingredient_id: updated_ingredient_id)
    end

    @ingredient.destroy
    @updated_ingredient = Ingredient.find(updated_ingredient_id)
    
    respond_to do |format|
      format.js
    end
  end

  private

  def ingredient_params
    params.require(:ingredient).permit(:name, :ingredient_category_id, :on_hand, :base_qty, :unit, :ingredient_group_id, :position, :note, :is_flagged, :precut_percentage, :section, :vendor)
  end

  def set_ingredient
    @ingredient = Ingredient.new
  end

  def find_ingredient
    @ingredient = Ingredient.find(params[:id])
  end

  def csv_information
		headers = %w{primary_id name unit on_hand position}

    CSV.generate(headers: true) do |csv|
      csv << headers

      grouped_ingredients = Ingredient.all.order(id: :ASC).group_by { |x| x.ingredient_group_id }

      grouped_ingredients.each do |k, v|
        if k == nil
          v.each do |y|
            csv << [y.id, y.name, y.unit, y.total_on_hand, y.position]
          end
        else
           total_on_hand = v.map(&:total_on_hand).sum.to_f

          ingredient = v.first
          csv << [ingredient.id, ingredient.name, ingredient.unit, total_on_hand, ingredient.position]
        end
      end
    end
	end

end