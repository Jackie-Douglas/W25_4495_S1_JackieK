class SmsMessagesController < ApplicationController
  include ApplicationHelper

  def new
    @sms_message = SmsMessage.new
  end

  def create
    @sms_message = SmsMessage.new(sms_message_params)

    if @sms_message.save
      redirect_to dashboards_path(subdomain: subdomain_resource)
    else
      render :new
    end
  end

  def twilio_send_sms
    SendSmsWorker.perform_async
    redirect_to dashboards_path
  end


  private

  def sms_message_params
    params.require(:sms_message).permit(:message)
  end

end
