class RegistrationsController < Devise::RegistrationsController

  def new
    @user = User.new
  end

  def create
    @user = User.new(user_params)

    if find_gift_card.nil?
      if @user.save
        update_customer_user_id_or_create_customer
        render file: "#{Rails.root}/app/views/layouts/email_confirmation_message.html.erb"
      else
        render :new
      end
    else
      @gift_card_information = find_gift_card

      if @user.save
        create_a_customer

        render file: "#{Rails.root}/app/views/layouts/email_confirmation_message.html.erb"
      else
        render :new
      end
    end
  end

  protected

  def after_update_path_for(resource)
    edit_user_registration_path(subdomain: 'portal')
  end

  # def after_inactive_sign_up_path_for(resource)
  #   '/welcome_message'
  # end

  private

  def user_params
    params.require("user").permit(:user_type, :email, :password, :password_confirmation)
  end

  def create_a_customer
    first_name = @gift_card_information.to_first_name
    last_name  = @gift_card_information.to_last_name
    email      = @gift_card_information.to_email
    phone      = @gift_card_information.to_phone
    
    @user.build_customer({first_name: first_name, last_name: last_name, email: email, phone: phone}).save(validate: false)
    @gift_card_information.update(user_id: @user.id)
  end

  def find_gift_card
    GiftCard.find_by(uuid: params[:user][:uuid])
  end

  def update_customer_user_id_or_create_customer
    if find_customer
      find_customer.update(user_id: @user.id)
    else
      @user.build_customer(email: @user.email).save(validate: false)
    end
  end

  def find_customer
    Customer.find_by(email: @user.email)
  end
end