class IngredientInformationsController < ApplicationController
  skip_before_action :authenticate_user!

  def create
    plating_component      = PlatingComponent.find(params[:plating_component_id])
    ingredient_information = plating_component.ingredient_informations.build(ingredient_information_params)

    if ingredient_information.save
      redirect_to plating_guide_path(plating_component.plating_guide_id, date: params[:date])
    else
      redirect_to plating_guide_path(plating_component.plating_guide_id, date: params[:date])
    end
  end

  def update
      ingredient_information = IngredientInformation.find(params[:id])

      if ingredient_information.update(ingredient_information_params)
        redirect_to plating_guide_path(ingredient_information.plating_component.plating_guide.id, date: params[:date])
      else
        redirect_to plating_guide_path(ingredient_information.plating_component.plating_guide.id, date: params[:date])
      end
  end

  private

  def ingredient_information_params
    params.require(:ingredient_information).permit(:plating_component_id, :extra, :weekly_menu_id, :food_id, :have)
  end
end



