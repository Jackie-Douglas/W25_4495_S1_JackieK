class RecipesController < ApplicationController
  layout 'index_layout'
  before_action :get_weekly_menu_for_admin


  def index
    @food    = Food.find(params[:food_id])
    @recipes = Recipe.where(food_id: params[:food_id])
  end

  def new
    @food = Food.find(params[:food_id])
    @recipe = Recipe.new
    @recipe_ingredient = RecipeIngredient.new
  end

  def create
    @food = Food.find(params[:food_id])
    @recipe = @food.recipes.build(recipe_params)

    if @recipe.save
      redirect_to recipe_path(@recipe.id)
    else
      render :new
    end
  end

  def show
    @recipe = Recipe.find(params[:id])
    @recipe_ingredient = RecipeIngredient.new
    @recipe_instruction = RecipeInstruction.new
  end

  def update
    @recipe = Recipe.find(params[:id])
    @recipe.update(recipe_params)

    redirect_to recipe_path(@recipe.id)
  end

  private

  def recipe_params
    params.require(:recipe).permit(:name, :recipe_type ,recipe_ingredients_attributes: [:id, :ingredient_id, :unit, :quantity, :recipe_id, :task_name, :veggie_station], 
                                   recipe_instructions_attributes: [:id, :step, :instruction, :recipe_id])
  end
  
end



 