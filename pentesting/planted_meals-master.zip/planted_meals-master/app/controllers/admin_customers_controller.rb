class AdminCustomersController < ApplicationController

    def new
       @customer = Customer.new
       @customer.build_stripe_info
    end

    def create
        @customer = Customer.new(customer_params)
        
        if @customer.save
            user = User.new(email: @customer.email, password: @customer.email, confirmation_token: @customer.email, confirmed_at: DateTime.now, confirmation_sent_at: DateTime.now)
            if user.save
                Customer.find_by(email: @customer.email).update_columns(user_id: user.id)
            else
                puts "something went wrong"
            end
            redirect_to users_path
        else
            render :new
        end
    end

    private

    def customer_params
        params.require(:customer).permit(:first_name, :last_name, :email,
                                        :phone, :address, :city, :province,
                                        :country, :postal_code, :on_subscription,
                                        :delivery_to, :shipping_address, :shipping_city, 
                                        :shipping_province, :shipping_country, :shipping_postal_code,
                                        :unit, :buzzer, :company_name, :delivery_day, :delivery_id, :food_note,
                                        :delivery_note, :subscription_info, :stripe_id, :internal, :unit_type, :tester,
                                        stripe_info_attributes: [:id, :last_4, :stripe_customer_id, :default_source, :credit_card_type]
                                        )
    end

end