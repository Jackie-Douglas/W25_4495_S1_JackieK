require "csv"

class OrdersController < ApplicationController
	skip_before_action :authenticate_user!
	before_action :get_weekly_menu, except: [:update, :show, :index]
	before_action :get_weekly_menu_for_admin, only: :index
	before_action :authenticate_admin_or_manger, only: :index

	def index
		@q = WeeklyMenu.ransack(params[:q])
		@week_start = params[:q].present? ? params[:q]["week_start_eq"].to_date : @weekly_menu.week_start
		@week_end =  params[:q].present? ? params[:q]["week_end_eq"].to_date : @weekly_menu.week_end

		begin
			@orders = params[:q].present? ? @q.result.last.orders.where(purchased: true) : @weekly_menu.orders.where(purchased: true)
			@grouped_orders = grouped_orders(@orders, "home office")
			@grouped_other_orders = grouped_orders(@orders, "other")
		rescue
			@orders = []            
		end 

		@vendor_snack_orders = TempOrder.where(cook_on: @week_start - 1.day)

		respond_to do |format|
				format.html
				if params[:delivery_location] == "sunday home"
					format.csv { send_data csv_information(Customer.where(id: @orders.pluck(:customer_id), delivery_to: "home", delivery_day:["sunday", "", nil]), @orders), filename: "#{params[:delivery_location]}, modify date.csv" }
				elsif params[:delivery_location] == "monday home"
					format.csv { send_data csv_information(Customer.where(id: @orders.pluck(:customer_id), delivery_to: "home", delivery_day: "monday"), @orders), filename: "#{params[:delivery_location]}, modify date.csv" }
				elsif params[:delivery_location] == "office"
					format.csv { send_data csv_information(Customer.where(id: @orders.pluck(:customer_id), delivery_to: params[:delivery_location]), @orders), filename: "#{params[:delivery_location]}, modify date.csv" }
				elsif params[:delivery_location] == "pick up"
					customers = Customer.where(id: @orders.pluck(:customer_id), delivery_to: ["pickup", "pick up"])
					assign_numbers(customers.ids, @orders)
					format.csv { send_data csv_information(customers, @orders), filename: "#{params[:delivery_location]}.csv" }
				elsif params[:delivery_location] == "internal"
					employee_customer_ids = Employee.all.pluck(:customer_id)
					employee_orders = @orders.where(customer_id: employee_customer_ids)
					format.csv { send_data internal_csv_information(employee_orders), filename: "#{params[:delivery_location]}.csv" }
				end
							
				if params[:label_type] == "food note"
					format.pdf do
					pdf = FoodNoteSheet.new(@orders)
						send_data pdf.render,
						filename: "export.pdf",
						type: 'application/pdf'
						# disposition: 'inline'
					end
				elsif params[:label_type] == "snack sticker"
					format.pdf do
					pdf = SnackStickerSheet.new(@orders, @vendor_snack_orders)
						send_data pdf.render,
						filename: "export.pdf",
						type: 'application/pdf',
						disposition: 'inline'
					end
				elsif params[:label_type] == "double protein"
					format.pdf do
					pdf = DoubleProteinSheet.new(@orders)
						send_data pdf.render,
						filename: "export.pdf",
						type: 'application/pdf',
						disposition: 'inline'
					end
				elsif params[:label_type] == "order" || params[:label_type] == "snack"
					if Rails.env == "production"
						LabelWorker.perform_async(label_type: params[:label_type], order_ids: @orders.ids, vendor_snack_order_ids: @vendor_snack_orders.ids)
						flash[:notice] = "#{params[:label_type]} label has been sent to team@plantedmeals.ca"
						format.html { redirect_to orders_path }
					else
							# for testing, instead of sending an email
						if params[:label_type] == "snack"
							format.pdf do 
								pdf = SnacksSheet.new(@orders, @vendor_snack_orders)        
								send_data pdf.render,
								filename: "export.pdf",
								type: 'application/pdf',
								disposition: 'inline'
							end
						elsif params[:label_type] == "order"
							format.pdf do
								pdf = OrdersSheet.new(@grouped_orders, @orders, @grouped_other_orders)
								send_data pdf.render,
								filename: "export.pdf",
								type: 'application/pdf',
								disposition: 'inline',
								page_size: 'A6'
							end
						end
					end
					elsif params[:label_type] == "test"
						format.pdf do
							pdf = TestSheet.new(@grouped_orders, @orders, @grouped_other_orders)
							send_data pdf.render,
							filename: "export.pdf",
							type: 'application/pdf',
							disposition: 'inline'
						end
					elsif params[:label_type] == "individual"
						format.pdf do
								pdf = IndividualSheet.new(params[:order_id])
								send_data pdf.render,
								filename: "export.pdf",
								type: 'application/pdf',
								disposition: 'inline'
						end
					end
			end
	end

	def update
		@order = Order.find(params[:id])

		if @order.update_attributes(orders_params) && !params["page"].blank?
			update_order_information

			redirect_to uuid_filtered_url(review_checkout_path(order_id: params[:id]), params[:order][:uuid])
		elsif @order.update_attributes(orders_params)
			update_order_information

			redirect_to uuid_filtered_url(checkout_path(order_id: @order.id), params[:order][:uuid])
		else            
			redirect_to uuid_filtered_url(review_checkout_path(order_id: params[:id]), params[:order][:uuid]), notice: "We require minimum 2 meals"
		end
	end

	def show
		@order = Order.find(params[:id])
		@customer = @order.customer
	end

	def print_order_sheet
		@orders = Order.where(id: params[:orders])
		@grouped_orders = grouped_orders(@orders)
	end

  private

	def orders_params
		params.require(:order).permit(:order_number, :order_date, :total_price, 
																	:mon, :tue, :wed, :thu, :fri, :sat, :sun, 
																	:total_meal_count, :container_type, :single_cookie, 
																	:comment, :bundle_cookie, :ricotta, :brownie,
																	line_items_attributes: [:id, :quantity, :name, :price, :food_id, :order_id])
	end

	def create_customer
		Customer.create(delivery_id: nil)
	end

	def find_meal_count
		product_id = params[:order][:total_meal_count]
		Product.find(product_id).meal_count
	end

	def update_order_information
		updated_subtotal = Calculation::Subtotal.new(@order).get_subtotal
		
		@order.update_columns(subtotal: updated_subtotal)
	end

	def csv_information(customer_data, orders)
		attributes = %w{position first_name last_name phone_number mobile_number email_address address apt postal_code delivery_date branch_id preference comments reference_id}

		CSV.generate(headers: true) do |csv|
			csv << attributes

			customer_data.each do |customer|
				order = orders.find_by(customer_id: customer.id)
				csv << [order.position, customer.first_name, customer.last_name, customer.phone, customer.phone, customer.email, "#{customer.shipping_address}, #{customer.shipping_city}", 
								customer.unit, customer.shipping_postal_code, "", 1, "", "Buzzer: #{customer.buzzer}, "",  Note: #{customer.delivery_note}", customer.id]
			end
		end
	end

	def internal_csv_information(order_data)
		weekly_menu_id = order_data.pluck(:weekly_menu_id).uniq.join.to_i
		food_items = Food.where(id: WeeklyMenu.find(weekly_menu_id).food_items.pluck(:food_id)).where(food_type: "meal").order(:id)
		attributes = food_items.map { |x| x.name }
		attributes = attributes.prepend(nil)

		CSV.generate(headers: true) do |csv|
			csv << attributes

			order_data.each do |order|
					array = [order.customer.first_name]
					food_items.each do |food_item|
							food_item = order.line_items.find_by(name: food_item.name)
							array << (food_item.blank? ? 0 : food_item.quantity)
					end
					csv << array
			end
		end
	end

	def assign_numbers(customers_ids, orders)
		orders = orders.where(customer_id: customers_ids)

		count = 0
		orders.each do |x|
				count = count += 1
				x.update_columns(position: count)
		end
	end
end

