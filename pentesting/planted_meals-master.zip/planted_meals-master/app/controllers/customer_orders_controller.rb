class CustomerOrdersController < ApplicationController
	include ProductsHelper

	def index
		@orders = current_user.customer.orders.where(purchased: true)
	end

	def show
		@customer = current_user.customer
		@order = Order.find(params[:id])
		@used_coupon = CouponUsage.find_by(order_ref_id: @order.id, purchased: true)

		# @referral_transaction = ReferralTransaction.find_by(order_ref_id: @order.id) if ReferralTransaction.find_by(order_ref_id: @order.id).user.wallet == current_user
	end
    
end