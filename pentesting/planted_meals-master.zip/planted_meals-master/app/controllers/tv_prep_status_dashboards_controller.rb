class TvPrepStatusDashboardsController < ApplicationController
  skip_before_action :authenticate_user!
  before_action :redirect_if_date_nil, only: :index
  before_action :get_prep_date_range
  before_action :filter_weekly_menu
  
  def index
    @prep_tasks = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("prep_tasks.station": [nil, "", " "]).where(weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id")
  end

  private

  def redirect_if_date_nil
    @is_week_day = is_between_weekly_date(today_date_with_time_zone) ? "weekday" : "weekend"

    redirect_to tv_prep_status_dashboards_path(work_day: @is_week_day, date: today_date_with_time_zone.beginning_of_week) if params[:work_day].nil?
  end
  
end