class PlatingGuidesController < ApplicationController
  before_action :find_food, only: [:new, :create, :edit]
  before_action :get_weekly_menu_for_admin
  before_action :filter_weekly_menu, only: [:index, :show, :allergie_index_for_plating]
  skip_before_action :authenticate_user!, only: [:show, :index, :allergie_index_for_plating]
  before_action :find_plating_stat, only: [:show]

  def index;end

  def new
    @plating_guide = PlatingGuide.new
  end

  def create 
    plating_guide = @food.build_plating_guide(plating_guide_params)

    if plating_guide.save
      redirect_to foods_path
    else
      render :new
    end
  end

  def edit
    @plating_guide = PlatingGuide.find(params[:id])
  end

  def update
    plating_guide = PlatingGuide.find(params[:id])

    if plating_guide.update(plating_guide_params)
      redirect_to foods_path
    else
      render :edit
    end
  end

  def show
    @plating_guide = PlatingGuide.find(params[:id])
  end

  def allergie_index_for_plating
    @meals = get_meals(@find_weekly_menu.id)
  end

  private

  def plating_guide_params
    params.require(:plating_guide).permit(:food_id, :image, plating_components_attributes: [:id, :name, :tool, :portion, :ingredient_type, :plating_guide_id, :mixed, :_destroy, plating_ingredients_attributes: [:id, :recipe_ingredient_id, :cooked_method]])
  end

  def find_food
    @food = Food.find(params[:food_id])
  end

  def find_plating_stat
    plating_guide  = PlatingGuide.find(params[:id])
    @plating_stat  = PlatingStat.find_by(plating_guide_id: plating_guide.id, weekly_menu_id: @find_weekly_menu.id, food_id: plating_guide.food.id)
  end
end