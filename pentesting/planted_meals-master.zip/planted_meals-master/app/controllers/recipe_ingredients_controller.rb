class RecipeIngredientsController < ApplicationController
  before_action :find_recipe_ingredient, except: [:index, :create]
  before_action :get_weekly_menu_for_admin, only: [:index]
  

  def index
    @food              = Food.find(params[:food_id])
    recipe_ids         = Recipe.where(food_id: params[:food_id])
    @recipe_ingredient = RecipeIngredient.where(recipe_id: recipe_ids)
    @recipe_ingredient = @recipe_ingredient.where(veggie_station: true).or(@recipe_ingredient.where(sauce_station: true)).or(@recipe_ingredient.where(cook_station: true))
    @other_tasks       = PrepTask.where(food_id: params[:food_id])
  end

  def create 
    @recipe = Recipe.find(params[:recipe_id])
    @recipe.recipe_ingredients.create(recipe_ingredient_params)

    redirect_to recipe_path(@recipe.id)
  end

  def destroy
    @recipe = Recipe.find(params[:recipe_id])
    @recipe_ingredient = RecipeIngredient.find(params[:id])
    @recipe_ingredient.destroy

    redirect_to recipe_path(@recipe.id)
  end

  def edit;end

  def update
    if @recipe_ingredient.update(recipe_ingredient_params)
      redirect_to recipe_path(@recipe_ingredient.recipe_id)
    else
      render :edit
    end
  end
  

  private

  def recipe_ingredient_params
    params.require(:recipe_ingredient).permit(:ingredient_id, :unit, :quantity, :recipe_id, :task_name, :veggie_station, :precut_percentage, :cook_station, :sauce_station, :ingredient_id, :group_id)
  end

  def find_recipe_ingredient
    @recipe_ingredient = RecipeIngredient.find(params[:id])
  end
end