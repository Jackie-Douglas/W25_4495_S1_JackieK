class CustomerDashboardsController < ApplicationController
	before_action :get_weekly_menu

	def index
		flash[:alert] = "Please update your delivery zone information" if current_user.customer.delivery_id.nil?
		
		@orders = current_user.customer.orders.where(purchased: true).order(created_at: "DESC")
		@this_week_order = current_user.customer.orders.find_by(weekly_menu_id: @weekly_menu.id, purchased: true) if @weekly_menu
		@referral = Referral.new
	end
end