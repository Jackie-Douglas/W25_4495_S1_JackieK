class EmployeesController < ApplicationController
    before_action :authenticate_admin

    def index
        # @employees = Customer.where.not(email: nil, internal: false)
        @employees = Employee.includes(:customer).where(archive: false, position: ["cook", "driver"])
        @archived_employees = Employee.includes(:customer).where(archive: true, position: ["cook", "driver"])
    end

end