class FoodGroupsController < ApplicationController
	def new
		@food_group = FoodGroup.new
	end

	def create
		@food_group = FoodGroup.new(food_group_params)

		if @food_group.save
			redirect_to foods_path, notice: "Food group created."
		else
			render :new
		end
	end

	private

	def food_group_params
		params.require(:food_group).permit(:name)
	end

end