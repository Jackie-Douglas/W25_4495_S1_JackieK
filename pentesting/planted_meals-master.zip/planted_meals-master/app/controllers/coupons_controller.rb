class CouponsController < ApplicationController
    before_action :authenticate_admin

    def index
        @coupons = Coupon.all
    end

    def new
        @coupon = Coupon.new
    end

    def create
        @coupon = Coupon.new(coupon_params)
        
        if @coupon.save 
            redirect_to coupons_path
        else
            render :new
        end
    end

    def show
        @coupon_usage = CouponUsage.where(coupon_id: params[:id], purchased: true)
    end
    
    def edit 
        @coupon = Coupon.find(params[:id])
    end

    def update
        @coupon = Coupon.find(params[:id])

        if @coupon.update_attributes(coupon_params)
            redirect_to coupons_path
        else
            render :edit
        end
    end

    def destroy
        @coupon = Coupon.find(params[:id])
        @coupon.destroy
        redirect_to coupons_path
    end


    private

    def coupon_params
        params.require(:coupon).permit(:coupon_code, :discount_type, :discount_amount, :numbers_available, :special)
    end

end








     
