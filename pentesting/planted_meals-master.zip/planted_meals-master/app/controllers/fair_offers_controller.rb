class FairOffersController < ApplicationController
  skip_before_action :authenticate_user!
  
  def new
    @fair_offer = FairOffer.new
  end

  def create
    @fair_offer = FairOffer.new(fair_offer_params)

    if @fair_offer.save
      redirect_to fair_offer_path(@fair_offer.coupon_code)
      NotificationMailer.with(fair_offer_information: @fair_offer, root_url: root_url).fair_coupon_notification.deliver_now
    else
      render :new
    end
  end

  def show
    @coupon = Coupon.find_by(coupon_code: params[:id])
  end

  private

  def fair_offer_params
    params.require(:fair_offer).permit(:email, :fair_name, :coupon_code)
  end
end