class Api::V1::StripeController < ApplicationController

  protect_from_forgery :except => :webhook
  
  def webhook
    render json: {
      status: 200
    }
  end


end
