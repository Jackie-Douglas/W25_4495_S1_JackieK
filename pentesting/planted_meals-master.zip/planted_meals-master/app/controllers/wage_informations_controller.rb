class WageInformationsController < ApplicationController
  layout 'index_layout'
  before_action :authenticate_user!

  def index
    # @employees = Customer.where.not(email: nil, internal: false)
    @employees = Employee.includes(:customer).where(archive: false, position: ["cook"])
    @archived_employees = Employee.includes(:customer).where(archive: true, position: ["cook"])
  end

  def new
    @employee = Employee.find(params[:employee_id])
    @wage_information = WageInformation.new
  end

  def create
    @employee = Employee.find(params[:employee_id])
    @wage_information = @employee.wage_informations.build(wage_information_params)

    if @wage_information.save
      redirect_to wage_informations_path
    else

    end
  end

  def destroy
    @wage_information = WageInformation.find(params[:id])
    @wage_information.destroy

    redirect_to wage_informations_path
  end

  private

  def wage_information_params
    params.require(:wage_information).permit(:hourly, :salary, :employee_id, :raise_date)
  end
end