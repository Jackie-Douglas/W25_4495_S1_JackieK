class PdfsController < ApplicationController
	before_action :authenticate_admin_or_manger
	before_action :get_weekly_menu_for_admin, only: [:index, :print_sun]
	before_action :find_orders

	def index;end

	def print_sun
		@grouped_orders = grouped_orders(@orders, "home office")
		@grouped_other_orders = grouped_orders(@orders, "other")
		klass = params[:print_type].constantize

		if params[:print_type] == "TestSheet"
			pdf = klass.new(@grouped_orders, @orders, @grouped_other_orders)

			if drivers_not_set
				flash[:alert] = "Drivers are not set!"
				redirect_to pdfs_path
			else
				send_data(pdf.render, filename: "export.pdf", type: 'application/pdf', disposition: 'inline')
			end
		else
			pdf = klass.new(@orders)

			send_data(pdf.render, filename: "export.pdf", type: 'application/pdf', disposition: 'inline')
		end
	end

	def show
		@pdf = Pdf.find(params[:id])
		label = params[:label_type]

		respond_to do |format|
			format.html
			format.pdf do
				send_data(@pdf.pdf_text, filename: "#{label}.pdf", type: 'application/pdf')
			end
		end
	end

	private

	def find_orders
		@orders = @weekly_menu.orders.where(purchased: true)
	end

	def drivers_not_set
		@orders.pluck(:employee_id).compact.empty?
	end
end

