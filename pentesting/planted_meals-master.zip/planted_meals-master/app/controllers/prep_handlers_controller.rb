class PrepHandlersController < ApplicationController
  before_action :get_weekly_menu_for_admin
  before_action :redirect_if_date_nil, only: [:choose_employee]
  before_action :get_prep_date_range, only: [:choose_employee, :assigned_prep_task, :all_assigned_prep_tasks, :prep_task_toggle_status]
  skip_before_action :authenticate_user!
  
  before_action :get_previous_weekly_menu_for_admin
  before_action :filter_weekly_menu

  def choose_employee
    # @prep_tasks          = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where(weekly_menu_id: @weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id")
    # @prep_tasks_count    = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("recipe_ingredients.veggie_station": true).where(weekly_menu_id: @weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id").count
    # employee_ids         = @prep_tasks.pluck(:employee_id).uniq
    
    # @scheduled_employees = Employee.includes(:customer).order("customers.first_name").where(id: employee_ids)
    
    @prep_tasks          = EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id")
    @prep_tasks_count    = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("recipe_ingredients.veggie_station": true).where(weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id").count
    employee_ids         = @prep_tasks.pluck(:employee_id).uniq
    
    @scheduled_employees = Employee.includes(:customer).order("customers.first_name").where(id: employee_ids)
    
    if params[:date]
      @date_start = params[:date].to_date.beginning_of_week(:monday)
      @date_end   = params[:date].to_date.end_of_week
    else
      @date_start = Date.today.beginning_of_week(:monday)
      @date_end   = Date.today.end_of_week
    end
  end

  def assigned_prep_task
    @employee              = Employee.find(params[:employee_id])
    # joined_prep_table          = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).order("ingredients.name")
    
    @employee_prep_tasks_joined_with_prep_tasks  = EmployeePrepTask.joins(:prep_task).where(weekly_menu_id: @find_weekly_menu.id, employee_id: @employee.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id")
    @employee_prep_tasks_joined_with_ingredients = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where(weekly_menu_id: @find_weekly_menu.id, employee_id: @employee.id, prep_date: @prep_date_range).order("ingredients.name")

    @employee_prep_tasks = (@employee_prep_tasks_joined_with_ingredients + @employee_prep_tasks_joined_with_prep_tasks).uniq
    @ready_tasks         = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where(weekly_menu_id: @find_weekly_menu.id, status: ["ready for processing", "processing in progress", "finished"], prep_date: @prep_date_range).where("prep_tasks.station": [nil, "", " "]).where.not(employee_id: @employee.id).order("ingredients.name")
    
        
    # @ready_tasks               = EmployeePrepTask.where(weekly_menu_id: @weekly_menu.id, status: ["ready for processing", "processing in progress", "finished"]).where.not(employee_id: @employee.id).order("ingredients.name")

    # duplicate_ingredients_ids  = @employee_prep_tasks.pluck("ingredients.id")
    # @duplicate_ingredients_ids = duplicate_ingredients_ids.select{ |e| duplicate_ingredients_ids.count(e) > 1 }.uniq
  end

  def all_assigned_prep_tasks
    @prep_tasks = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("prep_tasks.station": [nil, "", " "]).where(weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id")
    @veggie_prep_tasks_count    = EmployeePrepTask.joins(prep_task: [{recipe_ingredient: :ingredient}]).where("recipe_ingredients.veggie_station": true).where(weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range).order("prep_tasks.food_ref_id").count
    
    
    @customers = Customer.all
    @office_customers = Customer.where(delivery: "office")
    @orders = Order.where(weekly_menu_id: @find_weekly_menu.id, purchased: true)
    @previous_orders = Order.where(weekly_menu_id: @previous_weekly_menu.id, purchased: true)
    @snacks = Food.where(food_type: "snack", availability: true)
    @vendor_menu = Food.where(vendor_menu: true, food_type: "meal")
    @vendor_snacks = Food.where(vendor_menu: true, food_type: "dessert")
    @vendor_addons = Food.where(vendor_menu: true).where.not(food_type: ["dessert", "meal"])
    
    @meals = get_meals(@find_weekly_menu.id)
    @monthly_reports = MonthlyReport.all.order(report_date: :DESC)
  end

  def prep_task_toggle_status
    
    if request.referer.include?("all_assigned_prep_tasks")
      @prep_task = PrepTask.find(params[:id])
      @employee_prep_task = EmployeePrepTask.find_by(prep_task_id: @prep_task.id, weekly_menu_id: @find_weekly_menu.id, prep_date: @prep_date_range)
      
      if @employee_prep_task.nil? 
        set_date = @prep_date_range.map { |x| x.first }
        @employee_prep_task = EmployeePrepTask.create(prep_task_id: @prep_task.id, weekly_menu_id: @find_weekly_menu.id, prep_date: set_date[0])
      end
      
      if @employee_prep_task.status.blank?
        @employee_prep_task.update(status: "processing in progress", process_start_time: DateTime.now)
      else
        @employee_prep_task.update(status: "finished", process_end_time: DateTime.now)
      end
      # redirect_to all_assigned_prep_tasks_path(station: "veggie")
    else
      @prep_task = EmployeePrepTask.find(params[:id])

      if @prep_task.prep_task.station.blank?
        if @prep_task.status.blank?
          @prep_task.update(status: "prep in progress", prep_start_time: DateTime.now)
        elsif @prep_task.status == "prep in progress"
          @prep_task.update(status: "ready for processing", prep_end_time: DateTime.now)
        elsif @prep_task.status == "ready for processing"
          @prep_task.update(status: "processing in progress", process_start_time: DateTime.now)
        else
          @prep_task.update(status: "finished", process_end_time: DateTime.now)
        end
      else
        if @prep_task.status.blank?
          @prep_task.update(status: "processing in progress", process_start_time: DateTime.now)
        else
          @prep_task.update(status: "finished", process_end_time: DateTime.now)
        end

      end

      # redirect_to show_assigned_prep_tasks_path(employee_id: @prep_task.employee_id), turbolinks: false
    end
    
    respond_to do |format|
      format.js
      format.html
    end
  end

  def task_prioritize_toggle
    
    @prep_task = EmployeePrepTask.find(params[:id])
    @prep_task.toggle!(:is_prioritize)

    respond_to do |format|
      format.html
      format.js
    end
     
  end

  def other_task_prioritize_toggle
    @employee_prep_tasks = EmployeePrepTask.where(prep_task_id: params[:id], weekly_menu_id: @find_weekly_menu.id)

    if @employee_prep_tasks.empty?
      @employee_prep_task = EmployeePrepTask.create(prep_task_id: params[:id], weekly_menu_id: @find_weekly_menu.id)

      @employee_prep_task.toggle!(:is_prioritize)
    else
      if @employee_prep_tasks.pluck(:is_prioritize).include?(true)
        @employee_prep_tasks.update_all(is_prioritize: true)
        @employee_prep_tasks.update_all(is_prioritize: false)
      else
        @employee_prep_tasks.update_all(is_prioritize: false)
        @employee_prep_tasks.update_all(is_prioritize: true)
      end
    end

    redirect_to all_assigned_prep_tasks_path(station: params[:station], date: params[:date])

    # @employee_prep_task = EmployeePrepTask.find_or_create_by(prep_task_id: params[:id], weekly_menu_id: @weekly_menu.id)
    # @employee_prep_task.toggle!(:is_prioritize)
  end 

  def reset_prep_task
    @prep_task = EmployeePrepTask.find(params[:id])
    station    = @prep_task.prep_task.station
    @prep_task.update(status: reset_status(@prep_task.status, station))

    respond_to do |format|
      format.html
      format.js { render "prep_task_toggle_status" }
    end
  end

  private
  
  def get_task_counts(status)
    EmployeePrepTask.where(weekly_menu_id: @find_weekly_menu.id, status: status).count
  end

  def get_employee_task_counts(status, employee_id)
    EmployeePrepTask.where(weekly_menu_id: @find_weekly_menu.id, status: status, employee_id: employee_id).count
  end

  def other_prep_tasks
    prep_tasks = PrepTask.where(station: params[:station])
    required_food_ids = get_meals(@find_weekly_menu.id).pluck(:food_id) + get_everything_but_meals(@find_weekly_menu.id).pluck(:food_id)
    prep_tasks = prep_tasks.where(station: params[:station], food_id: required_food_ids) + PrepTask.joins(recipe_ingredient: :recipe).where("recipes.food_id": required_food_ids, station: params[:station])
  end

  def reset_status(status, station)
    if station == "veggie"
      case status

      when "prep in progress"
        nil
      when "ready for processing"
        nil
      when "processing in progress"
        "ready for processing"
      when "finished"
        "ready for processing"
      end
    else
      case status
      
      when "processing in progress"
        nil
      when "finished"
        "processing in progress"
      end

    end 


  end

  def redirect_if_date_nil
    @is_week_day = is_between_weekly_date(today_date_with_time_zone) ? "weekday" : "weekend"

    redirect_to choose_employee_path(work_day: @is_week_day, date: today_date_with_time_zone.beginning_of_week) if params[:work_day].nil?
  end
end
