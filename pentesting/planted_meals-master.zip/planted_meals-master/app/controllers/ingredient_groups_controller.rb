class IngredientGroupsController <  ApplicationController
  layout 'index_layout'
  before_action :find_ingredient_category, only: [:edit, :update, :destroy]

  def index
    @ingredient_groups = IngredientGroup.all 

  end

  def new
    @ingredient_group = IngredientGroup.new
  end

  def create
    @ingredient_group = IngredientGroup.new(ingredient_category_params)

    if @ingredient_group.save
      redirect_to ingredient_groups_path
    else
      render :new
    end
  end

  def edit;end

  def update
    if @ingredient_group.update(ingredient_category_params) 
      redirect_to ingredient_groups_path
    else
      render :edit
    end
  end

  def destroy
    @ingredient_group.destroy
    redirect_to ingredient_groups_path
  end

  private

  def ingredient_category_params
    params.require(:ingredient_group).permit(:name)
  end

  def find_ingredient_category
    @ingredient_group = IngredientGroup.find(params[:id])
  end
end  