class VendorsController < ApplicationController
    before_action :get_weekly_menu_for_admin, only: :index
    before_action :authenticate_admin_or_manger

    def index
        @vendors = Vendor.all
        @wednesday_cook = @weekly_menu.week_start - 5.days
        @sunday_cook = @weekly_menu.week_start - 1.day

        respond_to do |format|
            format.html

            if params[:delivery_day] == "thu_delivery"
                format.csv { send_data csv_information(TempOrder.where(cook_on: @wednesday_cook, delivery_day: "thu")), filename: "#{params[:delivery_day]} list.csv" }
            elsif params[:delivery_day] == "sun_delivery"
                format.csv { send_data csv_information(TempOrder.where(cook_on: @sunday_cook, delivery_day: "sun")), filename: "#{params[:delivery_day]} list.csv" }
            elsif params[:delivery_day] == "mon_delivery"
                format.csv { send_data csv_information(TempOrder.where(cook_on: @sunday_cook, delivery_day: "mon")), filename: "#{params[:delivery_day]} list.csv" }
            end

            if params[:label_day] == "wednesday"
                format.pdf do
                    pdf = VendorSheet.new(TempOrder.where(cook_on: @wednesday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end
            elsif params[:label_day] == "new wednesday"
                format.pdf do
                    pdf = NewVendorSheet.new(TempOrder.where(cook_on: @wednesday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end 
            elsif params[:label_day] == "new sunday"
                format.pdf do
                    pdf = NewVendorSheet.new(TempOrder.where(cook_on: @sunday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end 
            elsif params[:label_day] == "em sunday"
                format.pdf do
                    pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @sunday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end 
            elsif params[:label_day] == "em wednesday"
                format.pdf do
                    pdf = EverydayMealsSheet.new(TempOrder.where(cook_on: @wednesday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end 
            else
                format.pdf do
                    pdf = VendorSheet.new(TempOrder.where(cook_on: @sunday_cook))
                    send_data pdf.render,
                    filename: "export.pdf",
                    type: 'application/pdf',
                    disposition: 'inline'
                end
            end
        end
    end

    def new
        @vendor = Vendor.new
    end

    def create
        @vendor = Vendor.new(vendors_params)

        if @vendor.save
            redirect_to vendors_path, notice: "vendor has been successfully created"
        else
            render :new
        end
    end

    def edit
        @vendor = Vendor.find(params[:id])
    end

    def update
        @vendor = Vendor.find(params[:id])
        
        if @vendor.update_attributes(vendors_params)
            redirect_to edit_vendor_path(@vendor.id), notice: "Vendor has been successfully updated"
        else
            render :edit
        end
    end 

    def generate_pdf
        @orders = TempOrder.where(invoice_date: params[:from_date]..params[:to_date], everyday_meals: false).order(invoice_date: "ASC")

        respond_to do |format|
            format.html
            format.pdf do
                pdf = Invoice.new(@orders)
                        send_data pdf.render,
                        filename: "export.pdf",
                        type: 'application/pdf',
                        disposition: 'inline'
            end
        end
    end

    def vendor_user 
        vendor = Vendor.find(params[:vendor_id])
        find_user = User.find_by(email: vendor.email)

        if find_user
            vendor.update_columns(user_id: find_user.id)
        else
            user = User.create(email: vendor.email, password: vendor.email, confirmation_token: vendor.email, confirmed_at: DateTime.now, confirmation_sent_at: DateTime.now, user_type: "vendor")
            vendor.update_columns(user_id: user.id)
        end

        redirect_to vendors_path, notice: "User created"
    end

    private

    def vendors_params
        params.require(:vendor).permit(:first_name, :last_name, :email, :phone, 
                                       :shipping_address, :shipping_city, :shipping_province, 
                                       :shipping_country, :shipping_postal_code, :company_name,
                                       :store_name, :note, :everyday_meals
                                       )
    end

    def csv_information(order_data)

        attributes = %w{delivery_day, company_name, first_name, last_name, email, phone, address}

        CSV.generate(headers: true) do |csv|
            
            csv << attributes

            order_data.each do |order|
                vendor = order.vendor
                csv << [order.delivery_day, vendor.company_name, vendor.first_name, vendor.last_name, vendor.email, vendor.phone, "#{vendor.shipping_address}, #{vendor.shipping_city}"]

            end

        end
    end

end



    