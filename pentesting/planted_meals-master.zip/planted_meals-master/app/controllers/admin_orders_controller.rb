class AdminOrdersController < ApplicationController
    before_action :authenticate_admin
    before_action :get_weekly_menu_for_admin

    def new
        @order = Order.new
        @food_items = @weekly_menu.food_items
        
        if @order.line_items.blank?
            @food_items.each do |f|
                @order.line_items.build(food_id: f.food_id)
            end
        end

        @customer = Customer.find(params[:customer_id])
    end

    def create
        @order = Order.new(orders_params)
        @order.total_meal_count = update_total_meal_count(@order)
        @order.subtotal = Calculation::Subtotal.new(@order).get_subtotal  
        
        if @order.save
            BagTracking::UpdateCounter.new(@order).call
            redirect_to orders_path, notice: "order created"
        else
            render :new
        end
    end

    def edit
    	@order = Order.find(params[:id])
      @customer = Customer.find(params[:customer_id])
    end

    def update
			@order = Order.find(params[:id])
			@customer = @order.customer
			
			if @order.update_attributes(orders_params)
					redirect_to order_path(@order.id), notice: "order has been updated"
			else
					render :edit
			end
    end

    def destroy
        @order = Order.find(params[:id])
        @order.destroy
        redirect_to orders_path
    end

    def update_special_order
        order = Order.find(params[:order_id])

        if order.special
            order.update(special: false)
        else
            order.update(special: true)
        end

        redirect_to orders_path

        
    end


    private

    def orders_params
        params.require(:order).permit(:order_number, :order_date, :total_price, 
                                    :mon, :tue, :wed, :thu, :fri, :sat, :sun, 
                                    :total_meal_count, :container_type, :single_cookie, 
                                    :comment, :bundle_cookie, :ricotta, :brownie, :customer_id, 
                                    :weekly_menu_id, :purchase_type, :purchased, :cookie_dough, :overnight_oats,
                                    line_items_attributes: [:id, :quantity, :name, :price, :food_id, :order_id, :gluten_wise_option, :double_protein, :add_on_price]
                                    )
    end

    def update_total_meal_count(order)
        count = sort_meals_to_snacks(order.line_items).map(&:quantity).sum
    end

    def sort_meals_to_snacks(items)
    food_ids = items.map(&:food_id)
    meal_ids = Food.where(id: food_ids).where(food_type: [nil, "meal"]).ids

    items.select do |x|
      x if meal_ids.include?(x.food_id)
    end
  end
    
    
end