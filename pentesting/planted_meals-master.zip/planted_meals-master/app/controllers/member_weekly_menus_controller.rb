class MemberWeeklyMenusController < ApplicationController
    before_action :get_weekly_menu
    
    def index
        
    end

    def new
        if @weekly_menu
            @order = Order.new
            @food_items = @weekly_menu.food_items.where(vendor_only: false)
            if @order.line_items.blank?
                @food_items.each do |f|
                    @order.line_items.build(food_id: f.food_id)
                end
            end
        end

        @this_weeks_order = current_user.customer.orders.find_by(weekly_menu_id: @weekly_menu.id, purchased: true) if !@weekly_menu.nil?
    end

    def create
        @order = Order.new(orders_params)
        @order.customer_id = current_user.customer.id
        @order.weekly_menu_id = @weekly_menu.id
        purchase_type = current_user.customer.on_subscription ? "subscription" : "one time purchase"

        @order.purchase_type = purchase_type

        if @order.save
            # if current_user.customer.on_subscription
            #    PurchasedNotificationMailer.with(customer_info: current_user.customer, order_info: @order).notification_email.deliver_now
            #    @order.update_columns(purchased: true)
            #    BagTracking::UpdateCounter.new(@order).call
            #    redirect_to customer_order_path(@order.id), notice: "Your order has been successfully submitted, thank you"
            # else
               redirect_to member_review_checkout_path(order_id: @order.id)
            # end 
        else
            render :new
        end
    end

    def edit
        @order = Order.find(params[:id])
        @this_weeks_order = current_user.customer.orders.find_by(weekly_menu_id: @weekly_menu.id, purchased: true)
    end

    def update
        @order = Order.find(params[:id]) 

        if @order.update_attributes(orders_params)
            redirect_to member_review_checkout_path(order_id: @order.id)
        else
            render :edit
        end
    end
    

    def review_checkout
        @order = Order.find(params[:order_id])
        @customer = current_user.customer

            # need to create a method that check the following
            # check if the referral credit or giftcard credit exists?
            # check if the amount is a valid amount

        #    params[:gift_card_credit_amount]
        #    params[:order_id]
        #    params[:credit_amount]

            # valid = credit_validator(order_id: params[:order_id], gift_card_credit_amount: params[:gift_card_credit_amount], referral_credit: params[:credit_amount])

            # if valid

            # else

            # end


            if params[:gift_card_credit_amount] && params[:credit_amount]
                if current_user.gift_cards.exists? && current_user.wallet.exsits?
                    # double check the balance
                else

                end

            elsif params[:gift_card_credit_amount]
                            
                if params[:gift_card_credit_amount].to_f > current_user.gift_cards.sum(:amount).to_f

                    flash[:gift_card_credit_alert] = "Not enough credit not available"
                    redirect_to member_review_checkout_path(order_id: params[:order_id])
                else

                end

            elsif params[:credit_amount]

            else

            end

    end

    def charge_member

        # either a giftcard so no charge or there is a charge
        @order = Order.find(params[:order_id])
        @coupon = Coupon.find_by(uuid: params[:coupon_id]) if params[:coupon_id]
        calculate_amount = Calculation::GrandTotal.new({order: @order, coupon_id: params[:coupon_id], credit_amount: params[:credit_amount]})
        grand_total = calculate_amount.get_grand_total

        gift_card_amount = params[:gift_card_credit_amount] == nil ? 0.0 : params[:gift_card_credit_amount].to_f
        
        amount = (grand_total.to_f - gift_card_amount) * 100
        amount = amount.to_i

        if current_user.customer.on_subscription
           PurchasedNotificationMailer.with(customer_info: current_user.customer, order_info: @order).notification_email.deliver_now
           SendWeeklyFoodReviewWorker.perform_in(perform_in_day(@order).days, @order.id)
           @order.update_columns(purchased: true, purchase_type: "subscription")
           BagTracking::UpdateCounter.new(@order).call
           redirect_to customer_order_path(@order.id), notice: "Your order has been successfully submitted, thank you"
        elsif amount == 0.0
            # update giftcard transaction
            # update referral if they exists
            @order.update(purchased: true)
            Referral::AddRewards.new({order: @order, uuid: nil, user_id: referral_exist[:user_id]}).call if referral_exist[:condition]
            GiftCard::DebitAmount.new(user: current_user, debit_amount: gift_card_amount, order: @order).call
            PurchasedNotificationMailer.with(customer_info: current_user.customer, order_info: @order).notification_email.deliver_now
            SendWeeklyFoodReviewWorker.perform_in(perform_in_day(@order).days, @order.id)
            
            redirect_to customer_order_path(@order.id, {"order": "successful_submit"}), notice: "Your order has been successfully submitted, thank you"
        else
            Stripe::CreateStripeCustomer.new(current_user, @order, params[:stripeToken], root_url).call if current_user.customer.stripe_info.nil? || current_user.customer.stripe_info.default_source.blank?

            stripe_result = Stripe::ChargeCustomer.new(current_user.reload, amount, @order, @coupon, @klaviyo, params[:credit_amount], nil, gift_card_amount, root_url).call
            
            if stripe_result == nil
                    redirect_to customer_order_path(@order.id, {"order": "successful_submit"}), notice: "Your order has been successfully submitted, thank you"
            else
                    body = stripe_result.json_body
                    error = body[:error]
                    @message = error[:message]
                    render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
            end
        end
        
    end

    def validate_coupon
        result = CouponValidation.new({ coupon_code: params[:coupon_code].downcase, 
                                        order_id: params[:order_id]
                             }).call

        coupon = Coupon.find_by(coupon_code: params[:coupon_code].downcase)

        if result
            redirect_to member_review_checkout_path(order_id: params[:order_id], coupon_id: coupon.uuid), notice: "Coupon has been applied"    
        else
            redirect_to member_review_checkout_path(order_id: params[:order_id]), notice: "Coupon is not valid"
        end
    end

    def apply_credit

        if credit_amount_is_less_than_available_amount_and_greater_than_zero
            redirect_to member_review_checkout_path(order_id: params[:order_id], credit_amount: params[:credit])
        else 
            flash[:credit_alert] = "Credit not valid"
            redirect_to member_review_checkout_path(order_id: params[:order_id])
        end
    end

    def apply_gift_card_credit

        if (params[:gift_card_credit_amount].to_f > params[:grand_total].to_f) || (params[:gift_card_credit_amount].to_f == 0)
            flash[:gift_card_credit_alert] = "Credit amount cannot be more than the subtotal or be zero"
            redirect_to member_review_checkout_path(order_id: params[:order_id])
        else
            redirect_to member_review_checkout_path(order_id: params[:order_id], gift_card_credit_amount: params[:gift_card_credit_amount])
        end

    end


    private

    def orders_params
        params.require(:order).permit(:order_number, :order_date, :total_price, 
                                    :mon, :tue, :wed, :thu, :fri, :sat, :sun, 
                                    :total_meal_count, :container_type, :single_cookie, 
                                    :comment, :bundle_cookie, :ricotta, :brownie,
                                    line_items_attributes: [:id, :quantity, :name, :price, :food_id, :order_id, :gluten_wise_option, :double_protein, :add_on_price]
                                    )
    end

    def discounted_price(coupon_id, product_price)
        product_price  - discount_amount(coupon_id, product_price)
    end

    def discount_amount(coupon_id, product_price)
        coupon = Coupon.find_by(uuid: coupon_id)

        case coupon.discount_type
        when "$"
            coupon.discount_amount
        when "%"
            discount_percentage(coupon_id) * product_price
        end
    end

    def discount_percentage(coupon_id)
        coupon = Coupon.find_by(uuid: coupon_id)

        case coupon.discount_type
        when "$"
            coupon.discount_amount
        when "%"
            coupon.discount_amount.to_f / 100
        end
    end

    def credit_amount_is_less_than_available_amount_and_greater_than_zero
        available_credit = current_user.wallet.credit_amount.to_i
        credit_amount = params[:credit].to_i

        credit_amount <= available_credit && credit_amount > 0
    end


    def credit_validator(opt={})
    # check if the gift card or wallet exists 

        if opts[:gift_card_credit_amount]
            if current_user.gift_cards.empty?
                false
            else

            end

        elsif opts[:credit_amount]

        end
    end

    def referral_exist
            # find if the order was ever referrals by someone, this should be called if referral is found
                # get an email of a person that ordered
                # find referral with the email
                # get user of the referral

            email = current_user.customer.email
            was_it_a_referral = Referral.find_by(email: email)

            if was_it_a_referral

                @referral_hash = {
                                    condition: true,
                                    user_id: was_it_a_referral.user.id
                                }
            else
                @referral_hash = {
                                    condition: false,
                                    user_id: nil
                                }
            end

    end




end


# def charge_member
#         @order = Order.find(params[:order_id])
#         @coupon = Coupon.find_by(uuid: params[:coupon_id]) if params[:coupon_id]
        
#         if current_user.customer.stripe_info.nil? || current_user.customer.stripe_info.default_source.blank?

#             Stripe::CreateStripeCustomer.new(current_user, @order, params[:stripeToken]).call

#             grand_total = Calculation::GrandTotal.new({order: @order, coupon_id: params[:coupon_id]}).get_grand_total
#             amount = (grand_total.to_f * 100).to_i

#             stripe_result = Stripe::ChargeCustomer.new(current_user.reload, amount, @order, @coupon, @klaviyo).call

            

#             if stripe_result == nil
#                 redirect_to customer_order_path(@order.id, {"order": "successful_submit"}), notice: "Your order has been successfully submitted, thank you"
#             else
#                 body = stripe_result.json_body
#                 error = body[:error]
#                 @message = error[:message]
#                 render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
#             end
#         else
#             grand_total = Calculation::GrandTotal.new({order: @order, coupon_id: params[:coupon_id]}).get_grand_total
#             @amount = (grand_total.to_f * 100).to_i

            
#             stripe_result = Stripe::ChargeCustomer.new(current_user, @amount, @order, @coupon, @klaviyo).call

#             if stripe_result == nil
#                 redirect_to customer_order_path(@order.id, {"order": "successful_submit"}), notice: "Your order has been successfully submitted, thank you"
#             else
#                 body = stripe_result.json_body
#                 error = body[:error]
#                 @message = error[:message]
#                 render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
#             end
            
#         end
#     end