class WalletsController < ApplicationController
    before_action :authenticate_admin
    
    def update
        @wallet = Wallet.find(params[:id])

        if @wallet.update(wallet_params)
            redirect_to user_wallet_path(params[:user_id], @wallet.id), notice: "Wallet has been successfully updated!!!"
        else
            render :show
        end

    end

    def show
        @user = User.find(params[:user_id])
        @wallet = Wallet.find(params[:id])
    end

    private

    def wallet_params
        params.require(:wallet).permit(:credit_amount)
    end

end