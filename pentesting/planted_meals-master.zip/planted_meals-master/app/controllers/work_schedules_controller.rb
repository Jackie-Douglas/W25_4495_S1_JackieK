class WorkSchedulesController < ApplicationController 
  include WorkHoursHelper
  
  before_action :get_weekly_menu_for_admin
  before_action :find_work_schedule, only: [:destroy, :update]
  before_action :authenticate_admin_or_manger, except: [:show, :show_employee_work_schedules]
  skip_before_action :authenticate_user!, only: [:show, :show_employee_work_schedules]

  def index
    if params[:date]
      @date_start = params[:date].to_date.beginning_of_week(:monday)
      @date_end   = params[:date].to_date.end_of_week
    else
      @date_start = Date.today.beginning_of_week(:monday)
      @date_end   = Date.today.end_of_week
    end

    @find_weekly_menu = WeeklyMenu.find_by(week_start: @date_start.next_week)

    respond_to do |format|
      format.html
      format.pdf do
        pdf = WorkScheduleSheet.new(@weekly_menu)        
              send_data pdf.render,
              filename: "export.pdf",
							type: 'application/pdf',
							disposition: 'inline'
      end
    end
  end

  def new
    @work_schedule = WorkSchedule.new
    @work_scheduled = WorkSchedule.where(work_date: params[:date].to_date)
    @last_week_work_scheduled = WorkSchedule.where(work_date: params[:date].to_date - 1.week)
    
    @employees = Employee.includes(:customer).where(position: "cook", archive: false).where.not(id: @work_scheduled.pluck(:employee_id))
  end

  def create
    @work_schedule = WorkSchedule.new(work_schedule_params)
    set_work_start
    set_work_end
    
    if @work_schedule.save
      respond_to do |format|
        format.html
        format.js
      end
    else
    end
  end

  def update
    @work_scheduled = WorkSchedule.where(work_date: @work_schedule.work_date)
    @work_schedule.assign_attributes(work_schedule_params)
    set_work_start
    set_work_end

    if @work_schedule.save
      respond_to do |format|
        format.html
        format.js
      end
    else
    end
  end

  def destroy
    @work_schedule.destroy

    respond_to do |format|
      format.html
      format.js
    end
  end

  def show
    @date_start = params[:date].to_date
    @date_end   = @date_start.end_of_week
    @employee = Employee.find_by(uuid: params[:id])

    WorkSchedule.where(work_date: [@date_start..@date_end], employee_id: @employee.id).update_all(confirmed: true)
  end

  def send_text
    SendSmsWorker.perform_async(params[:date], root_url)
    redirect_to work_schedules_path(date: params[:date]) 
  end

  def show_employee_work_schedules
    if params[:date]
      @date_start = params[:date].to_date.beginning_of_week(:monday)
      @date_end   = params[:date].to_date.end_of_week
    else
      @date_start = Date.today.beginning_of_week(:monday)
      @date_end   = Date.today.end_of_week
    end

    

    @work_schedules = WorkSchedule.where(work_date: [@date_start..@date_end]).group_by(&:employee_id)

    @data = Hash.new {|h,k| h[k] = [] }

    (@date_start + 1.day.. @date_end - 1.day).each do |d|
      @work_schedules.each do |k, v|
        find_work_schedule = WorkSchedule.find_by(work_date: d, employee_id: k)

        if find_work_schedule
          @data[k] << "#{display_work_hour(find_work_schedule.work_start)} - #{display_work_hour(find_work_schedule.work_end)}"
        else
          @data[k] << ""
        end
        
      end
    end

    @data
  end

  private
  
  def work_schedule_params
    params.require(:work_schedule).permit(:work_date, :work_start, :work_end, :total_hours, :note, :employee_id)
  end

  def set_work_start
    Time.zone = 'America/Vancouver' # just in case
    time = [params[:work_schedule].values_at("work_start(4i)", "work_start(5i)").join(":")]
    date = params[:work_schedule].values_at(:work_date)

    start_time  = (date + time).join(' ')
    start_time = Time.zone.parse(start_time)
    @work_schedule.work_start = start_time
  end

  def set_work_end
    Time.zone = 'America/Vancouver' # just in case
    time = [params[:work_schedule].values_at("work_end(4i)", "work_end(5i)").join(":")]
    date = params[:work_schedule].values_at(:work_date)

    end_time = (date + time).join(' ')
    end_time = Time.zone.parse(end_time)
    @work_schedule.work_end = end_time
  end

  def find_work_schedule
    @work_schedule = WorkSchedule.find(params[:id])
  end

  def display_work_hour(date)
    date.in_time_zone('America/Vancouver').strftime("%I:%M %p")
  end

end