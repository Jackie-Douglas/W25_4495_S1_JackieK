class PlatingStatsController < ApplicationController
  before_action :filter_weekly_menu
  skip_before_action :authenticate_user!
  before_action :find_plating_stat, only: [:update, :add_bag_counter, :subtract_bag_counter]
  
  def create
    @plating_guide  = PlatingGuide.find(params[:plating_guide_id])
    
    plating_stat = PlatingStat.find_or_initialize_by(plating_guide_id: @plating_guide.id, weekly_menu_id: @find_weekly_menu.id, food_id: @plating_guide.food.id, start_time: DateTime.now).save
    redirect_to plating_guide_path(@plating_guide.id, date: params[:date])
  end

  def update
    plating_stat = PlatingStat.find_by(plating_guide_id: @plating_guide.id, weekly_menu_id: @find_weekly_menu.id, food_id: @plating_guide.food.id)
    plating_stat.update(end_time: DateTime.now)

    redirect_to plating_guide_path(@plating_guide.id, date: params[:date])
  end

  def add_bag_counter
    new_counter = @plating_stat.bag_count + 1
    @plating_stat.update(bag_count: new_counter)

    redirect_to plating_guide_path(params[:plating_guide_id], date: params[:date])
  end

  def subtract_bag_counter
    new_counter = @plating_stat.bag_count - 1
    @plating_stat.update(bag_count: new_counter)

    redirect_to plating_guide_path(params[:plating_guide_id], date: params[:date])
  end

  private

  def find_plating_stat
    @plating_guide  = PlatingGuide.find(params[:plating_guide_id])
    @plating_stat  = PlatingStat.find_by(plating_guide_id: @plating_guide.id, weekly_menu_id: @find_weekly_menu.id, food_id: @plating_guide.food.id)
  end
end

