class GiftCardsController < ApplicationController
    skip_before_action :authenticate_user!
    
    def new
        @gift_card = GiftCard.new
    end

    def create
        @gift_card = GiftCard.new(gift_card_params)

        if @gift_card.save
            # 1. send mail
                redirect_to gift_card_path(@gift_card)
        else

        end
    end

    def edit
        @gift_card = GiftCard.find(params[:id])
    end

    def update
        @gift_card = GiftCard.find(params[:id])

        if @gift_card.update(gift_card_params)
            redirect_to gift_card_path(@gift_card) 
        else
            render :edit
        end
    end

    def show
        @gift_card = GiftCard.find(params[:id])
    end

    def charge_gift_card_payment
        token = params[:stripeToken]
        email = params[:stripeEmail]
        amount = params[:amount]
        @gift_card = GiftCard.find(params[:gift_card_id])

        stripe_result = Stripe::ChargeCustomer.new(email, amount, nil, nil, nil, nil, token, 0, root_url).charge_gift_card


        if stripe_result == nil
                GiftCardMailer.with(gift_card_info: @gift_card, root_url: root_url).gift_card_email.deliver_now
                @gift_card.update(purchased: true)
                create_referral_if_account_exists
                render file: "#{Rails.root}/app/views/layouts/thank_you_gift_card_purchase.html.erb"
        else
                body = stripe_result.json_body
                error = body[:error]
                @message = error[:message]
                render file: "#{Rails.root}/app/views/layouts/card_declined.html.erb"
        end
    end

    private

    def gift_card_params
        params.require(:gift_card).permit(:to_first_name, :to_last_name, :to_email, :to_phone, :message, :amount, 
                                          :from_first_name, :from_last_name, :from_email, :from_phone, :user_id, :uuid, :purchased)
    end

    def create_referral_if_account_exists
        referral_user = User.find_by(email: @gift_card.from_email)

        referral = Referral.create(referral_data(@gift_card.to_email, referral_user.id)) if referral_user
    end

    def referral_data(email, user_id)
        {
            email: email,
            user_id: user_id,
            redeemed: true 
        }
    end


end






