class TempOrdersController < ApplicationController
	before_action :get_weekly_menu_for_admin
	before_action :authenticate_admin, only: :index

	def index
		@vendor = Vendor.find(params[:vendor_id])    
		@orders = params[:company] == "em" ? @vendor.temp_orders.where(everyday_meals: true) : @vendor.temp_orders.where(everyday_meals: false)
	end

	def new
		@vendor_id = params[:vendor_id].nil? ? params[:em_vendor_id] : params[:vendor_id]

		@vendor = Vendor.find(@vendor_id)
		@order = TempOrder.new
		@foods = Food.where(vendor_menu: true).order(sort_sequence: "ASC")
		rotating_food = Food.where(id: get_food_id_from_rotating_menu)
		@food_menu = @foods + rotating_food
		
		@food_menu.each do |f|
			@order.line_items.build(name: f.name, food_id: f.id, price: f.wholesale_price)
		end
	end

	def create
		@vendor = Vendor.find(params[:vendor_id])
		@order = @vendor.temp_orders.build(order_params)
		# @order.vendor_id = current_user.vendor.id if request_from_vendor_controller
		set_cook_date_for_admin if current_user.is_admin

		if @order.save
			@subtotal = calculate_subtotal(@order)
			@order.update(vendor_delivery_fee: delivery_charge)
			@order.update(subtotal: @subtotal)

			redirect_to request_from_vendor_controller ? vendor_review_order_path(order_id: @order.id, delivery_date: params[:temp_order][:delivery_date]) : temp_order_path(@order.id)
		else
			if request_from_vendor_controller
				flash[:alert] = "It looks like you've already entered an order!"
				redirect_to vendor_dashboards_path
			else
				render :new
			end
		end
	end

	def show
		@order = TempOrder.find(params[:id])    
		@vendor = @order.vendor
		file_name = "#{@vendor.company_name} | #{@order.po_number}"
		
		respond_to do |format|
			format.html
			format.pdf do
				pdf = Invoice.new(@order)
							send_data pdf.render,
							filename: "#{file_name}.pdf",
							type: 'application/pdf',
							disposition: 'inline'
				end
			end
	end

	def edit
		@order = TempOrder.find(params[:id])
		@vendor = @order.vendor 
	end

	def update
		@order = TempOrder.find(params[:id])
		@vendor = @order.vendor
		set_cook_date_for_admin if current_user.is_admin
		
		if @order.update(order_params)
			@subtotal = calculate_subtotal(@order)
			@order.update(subtotal: @subtotal, vendor_delivery_fee: delivery_charge)

			redirect_to request_from_vendor_controller ? vendor_review_order_path(order_id: @order.id) : vendors_path
		else 
			render :edit
		end
	end

	def destroy
		@order = TempOrder.find(params[:id])
		@order.destroy
		
		redirect_url = check_referrer("vendor_order_history") ? vendor_order_history_path : temp_orders_path(vendor_id: @order.vendor_id)
		redirect_to redirect_url
	end

	def invoice_status
		@order = TempOrder.find(params[:temp_order_id])
		
		if @order.invoice_paid
			@order.update(invoice_paid: false)
		else
			@order.update(invoice_paid: true)
		end

		respond_to do |format|
			format.html {redirect_to temp_orders_path(vendor_id: @order.vendor_id)}
			format.js
		end
	end

	private

	def order_params
		params.require(:temp_order).permit(:order_number, :order_date, :subtotal, :customer_id, :total_meal_count, 
																				:comment, :purchased, :purchase_type, :weekly_menu_id, :charged_amount, :po_number,
																				:vendor_delivery_fee, :vendor_id, :invoice_number, :cook_on, :invoice_date, :invoice_paid, :delivery_day, :everyday_meals,
																				line_items_attributes: [:id, :quantity, :name, :price, :food_id, :temp_order_id, :vendor_delivery_fee]
																				)
			
	end

	def calculate_subtotal(order)
		Calculation::Subtotal.new(order).get_subtotal_new
	end

	def get_food_id_from_rotating_menu
		meal_ids = Food.where(food_type: "meal").pluck(:id)
		meals = @weekly_menu.food_items.where(food_id: meal_ids).pluck(:food_id)
	end

	def request_from_vendor_controller
		request.referer.include?("vendor_dashboards")
	end

	def delivery_charge
		if current_user.is_admin
			@order.vendor_delivery_fee
		else
			@subtotal.to_f >= 110 ? 0 : 5
		end
	end

	def set_cook_date_for_admin
		@order.cook_on = @order.invoice_date
	end
end

 
 
