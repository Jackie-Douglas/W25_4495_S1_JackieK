class WorkHoursController < ApplicationController
	before_action :authenticate_admin_or_manger, except: [:employees_index, :new, :edit, :create, :update, :clock_lunch_break, :employee_work_hour_log]
	skip_before_action :authenticate_user!, only: [:employees_index, :new, :edit, :create, :update, :clock_lunch_break, :employee_work_hour_log]

	def index
		@q = WorkHour.ransack(params[:q])
		@result = @q.result.group_by { |x| x.employee_id }
		@period_start = params[:q][:work_date_gteq] if params[:q]
		@period_end = params[:q][:work_date_lteq] if params[:q]
		
		if !params[:employee_id].nil?
			@employee = Employee.find(params[:employee_id])
			@work_hours = @employee.work_hours
		end
	end

	def admin_work_hour_new
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.new        
	end

	def admin_work_hour_edit
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.find(params[:id]) 
	end

	def employees_index
		@employees = Employee.includes(:customer).where(position: "cook", archive: false, salary: false).order("customers.first_name")
	end

	def new
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.new
	end

	def create
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.new(work_hour_params)
		@work_hour.employee_id = @employee.id
		
		if request.referrer.include?("admin_work") ? @work_hour.save(validate: false) : @work_hour.save
			
			if request.referrer.include?("admin_work")
					redirect_to employee_work_hours_path(@employee.id), notice: "Your hours has been successfully submitted!"
			elsif current_user.nil?
				redirect_to employees_index_path, notice: "Your hours has been successfully submitted!"
			elsif current_user.manager?
					redirect_to employees_index_path, notice: "Your hours has been successfully submitted!" 
			elsif current_user.customer.employee
					redirect_to customer_dashboards_path, notice: "Your hours has been successfully submitted!"
			else
					redirect_to employees_index_path, notice: "Your hours has been successfully submitted!"
			end
		else
			render :new
		end
	end

	def edit
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.find(params[:id]) 
	end

	def update
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.find(params[:id])

		if @work_hour.update(work_hour_params)
			if request.referrer.include?("admin_work")
				redirect_to employee_admin_work_hour_edit_path(@employee,  @work_hour), notice: "Updated successfully"
			else
				redirect_to employees_index_path, notice: "Your hours has been successfully submitted!"
			end
		else
			if request.referrer.include?("admin_work")
				render :admin_work_hour_edit
			else
				render :edit
			end
		end
	end

	def employee_work_hour_log
		@employee = Employee.find(params[:employee_id])
		@work_hours = WorkHour.where(employee_id: params[:employee_id])
	end

	def destroy
		@employee = Employee.find(params[:employee_id])
		@work_hour = WorkHour.find(params[:id])     
		@work_hour.destroy
		redirect_to employee_work_hours_path(@employee.id), notice: "Your hours has been successfully deleted!"
	end

	def clock_lunch_break
		@work_hour = WorkHour.find(params[:work_hour_id])    

		if @work_hour.break_time_start_hour.blank? 
			@work_hour.update(break_time_start_hour: current_time_with_time_zone.strftime("%I").to_i, 
											  break_time_start_min: current_time_with_time_zone.min, 
												break_time_start_am_or_pm: current_time_with_time_zone.strftime("%p")) 
			
			redirect_to employees_index_path, notice: "Your hours has been successfully submitted!"
		else
			@work_hour.update(break_time_end_hour: current_time_with_time_zone.strftime("%I").to_i, 
											  break_time_end_min: current_time_with_time_zone.min, 
												break_time_end_am_or_pm: current_time_with_time_zone.strftime("%p")) 
												
			redirect_to employees_index_path, notice: "Your hours has been successfully submitted!"
		end
	end

	private

	def work_hour_params
		params.require(:work_hour).permit(:start_hour, :start_min, :start_am_or_pm, :end_hour, 
																			:end_min, :end_am_or_pm, :work_date, :employee_code,
																			:break_time_start_hour, :break_time_start_min, :break_time_start_am_or_pm,
																			:break_time_end_hour, :break_time_end_min, :break_time_end_am_or_pm)
	end
end