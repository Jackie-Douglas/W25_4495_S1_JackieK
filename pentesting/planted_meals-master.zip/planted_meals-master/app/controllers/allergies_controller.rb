class AllergiesController < ApplicationController
  layout 'index_layout'
  before_action :find_record

  def index
    
  end

  def new
  end

  def create
    save_allergies
    redirect_to customer_allergies_path(@customer.id)
  end

  def destroy
    @allergy = Allergy.find(params[:id])
    @allergy.destroy

    redirect_to customer_allergies_path(@customer.id)
  end

  private

  def allergy_params
    params.require(:customer).permit(:customer_id, allergies_attributes: [
      :id, :food_id, :description, :_destroy
    ])
  end

  def find_record
    if params[:customer_id]
      @customer = Customer.find(params[:customer_id])
    elsif params[:food_id]
      @food = Food.find(params[:food_id])
    end
  end

  def save_allergies
    allergy_params[:allergies_attributes].each do |i|
      item = i[1]
      next if item[:_destroy].to_i == 0 && item[:id].blank?

      allergy = @customer.allergies.find_or_initialize_by(food_id: item[:food_id])

      if item[:_destroy].to_i == 0 
        allergy.destroy
        next
      end

      allergy.description = item[:description]
      allergy.save
    end
  end
end