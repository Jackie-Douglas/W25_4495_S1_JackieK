class MonthlyReportsController < ApplicationController
  before_action :authenticate_admin_or_manger
  before_action :set_monthly_report, only: [:edit, :show, :destroy, :update]

  def index;end

  def new
    @monthly_report = MonthlyReport.new
  end

  def create
    @monthly_report = MonthlyReport.new(monthly_report_params)

    if @monthly_report.save
      redirect_to dashboards_path
    else
      render :new
    end
  end

  def edit;end

  def update
    if @monthly_report.update(monthly_report_params)
      redirect_to dashboards_path
    else
      render :edit
    end
  end

  def show;end

  def destroy
    @monthly_report.destroy
    redirect_to dashboards_path
  end

  private
  
  def monthly_report_params
    params.require(:monthly_report).permit(:report_date, :cogs, :labour, :food_cost, :oc_img, :cogs_img)
  end

  def set_monthly_report
    @monthly_report = MonthlyReport.find(params[:id])
  end
end