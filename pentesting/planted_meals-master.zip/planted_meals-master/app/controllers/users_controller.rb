class UsersController < ApplicationController
	before_action :authenticate_admin, except: [:stop_impersonating, :resend_user_confirmation_email]
	skip_before_action :authenticate_user!, only: :resend_user_confirmation_email

	def index
		@customers = Customer.where.not(email: nil)
	end

	def customer_edit
		@customer = Customer.find(params[:id])
		@stripe_info = @customer.stripe_info ||= @customer.build_stripe_info
		@employee = @customer.employee ||= @customer.build_employee if @customer.internal == true
	end

	def custom_user_create
		customer = Customer.find(params[:customer_id])
		find_user = User.find_by(email: customer.email)

		if find_user
				customer.update_columns(user_id: find_user.id)
		else
				user = User.create(email: customer.email, password: customer.email, confirmation_token: customer.email, confirmed_at: DateTime.now, confirmation_sent_at: DateTime.now)
				customer.update_columns(user_id: user.id)
		end

		redirect_to users_path, notice: "User created"
	end

	def customer_update
		@customer = Customer.find(params[:id])
		
		if @customer.update_attributes(customer_params)
			redirect_to customer_edit_path(@customer.id), notice: "updated"
		else 
			render :customer_edit
		end
	end

	def customer_delete
		customer = Customer.find(params[:id])
		customer.user.destroy if customer.user
		customer.destroy

		redirect_to users_path
	end

	def destroy
		customer = Customer.find(params[:id])
		customer.user.destroy
		customer.destroy

		redirect_to users_path
	end

	def impersonate
		user = User.find(params[:id])
		impersonate_user(user)
		redirect_path = user.user_type == "vendor" ? vendor_dashboards_path : customer_dashboards_path

		redirect_to redirect_path
	end

	def stop_impersonating
		stop_impersonating_user
		redirect_to users_path
	end


	def get_processed_dataset
		respond_to do |format|
			format.html
			format.json { render json: CustomerDatatable.new(view_context) }            
		end
	end

	def resend_user_confirmation_email
		@user = User.find_by(email: params[:email])
		@user.send_confirmation_instructions
    
		render file: "#{Rails.root}/app/views/layouts/email_confirmation_message.html.erb"
  end

	private

	def customer_params
		params.require(:customer).permit(:first_name, :last_name, :email,
																		 :phone, :address, :city, :province,
																		 :country, :postal_code, :on_subscription,
																		 :delivery_to, :shipping_address, :shipping_city, 
																		 :shipping_province, :shipping_country, :shipping_postal_code,
																		 :unit, :buzzer, :company_name, :delivery_day, :delivery_id, :food_note,
																		 :delivery_note, :subscription_info, :stripe_id, :internal, :unit_type, :rate, :tester, :subscription_price_id,
																		 stripe_info_attributes: [:id, :last_4, :stripe_customer_id, :default_source, :credit_card_type],
																		 employee_attributes: [:id, :customer_id, :position, :archive, :salary])
	end
end