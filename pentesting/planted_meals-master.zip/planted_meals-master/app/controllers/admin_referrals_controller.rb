class AdminReferralsController < ApplicationController
    before_action :authenticate_admin
    
    def index
        @referrals = Referral.all.order(created_at: :DESC).where(event_name: nil)
    end

    def new
        @referral = Referral.new
    end

    def create
        @referral = Referral.new(referral_params)

        if condition_are_met[:condition]
            @referral.user_id = condition_are_met[:from_user].id
            @referral.redeemed = true

            if @referral.save
                ActiveRecord::Base.transaction do
                    add_rewards
                    redirect_to admin_referral_path(@referral.id), notice: "Referral has been successfully created!"
                end
            else    
                render :new
            end
        else
            flash[:alert] = "Users don't exists"
            render :new
        end

    end

    def show
        referral = Referral.find(params[:id])
        referred_customer = Customer.find_by(email: referral.email)
        referred_customer_purchased_order_ids = referred_customer.orders.where(purchased: true) if referred_customer

        @user = User.find(referral.user_id)
        @user_wallet = @user.wallet
        @transactions = @user_wallet.referral_transactions.where(order_ref_id: referred_customer_purchased_order_ids) if @user_wallet
    end

#     id: 1,
#   order_ref_id: 26302,
#   order_subtotal: 0.828e2,
#   credit_amount: 0.6e0,
#   transaction_type: "reward",
#   created_at: Thu, 25 Feb 2021 02:31:57 UTC +00:00,
#   updated_at: Thu, 25 Feb 2021 02:31:57 UTC +00:00,
#   wallet_id: 1>,

    private

    def referral_params
        params.require(:referral).permit(:email, :event_name, :redeemed, :uuid, :user_id, :message, :referral_type, :first_name)
    end

    def condition_are_met
        from_email = params[:referee_email]
        to_email   = params[:referral][:email]

        from_user = User.find_by(email: from_email)
        to_user   = User.find_by(email: to_email)

        condition = !from_user.nil? && !to_user.nil? 

        {
            condition: condition,
            from_user: from_user
        }
    end

    def add_rewards
        orders = Customer.find_by(email: @referral.email).orders.where(purchased: true)
        
        orders.each do |o|
            Referral::AddRewards.new({order: o, uuid: nil, user_id: @referral.user_id}).call
        end
    end

end