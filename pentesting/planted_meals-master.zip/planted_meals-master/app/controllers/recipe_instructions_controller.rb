class RecipeInstructionsController < ApplicationController
  layout 'index_layout'

  def create
    @recipe = Recipe.find(params[:recipe_id])
    @recipe_instructions = @recipe.recipe_instructions.build(recipe_instructions_params)
    @recipe_instructions.save

    redirect_to recipe_path(@recipe.id)
  end

  def edit 
    @recipe = Recipe.find(params[:recipe_id])
    @recipe_instruction = RecipeInstruction.find(params[:id])
  end

  def update
    @recipe = Recipe.find(params[:recipe_id])
    @recipe_instruction = RecipeInstruction.find(params[:id])

    @recipe_instruction.update(recipe_instructions_params)
    redirect_to recipe_path(@recipe.id)
  end

  def destroy
    @recipe = Recipe.find(params[:recipe_id])
    @recipe_instruction = RecipeInstruction.find(params[:id])

    @recipe_instruction.destroy
    redirect_to recipe_path(@recipe.id)
  end

  private

  def recipe_instructions_params
    params.require(:recipe_instruction).permit(:step, :instruction, :recipe_id)
  end
end