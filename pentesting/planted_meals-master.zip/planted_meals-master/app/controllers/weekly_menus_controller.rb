class WeeklyMenusController < ApplicationController
	before_action :authenticate_admin

	def index
		@weekly_menus = WeeklyMenu.order(week_start: "DESC").limit(8)
	end

	def new
		@weekly_menu = WeeklyMenu.new
		@food_items = @weekly_menu.food_items.build 
	end

	def create
		@weekly_menu = WeeklyMenu.new(weekly_menu_params)

		if @weekly_menu.save
			redirect_to weekly_menus_path
			create_eating_order_template
			create_vendor_food_items
		else
			render :new
		end
	end

	def edit
		@weekly_menu = WeeklyMenu.find(params[:id])
	end

	def update
		@weekly_menu = WeeklyMenu.find(params[:id])

		if @weekly_menu.update_attributes(weekly_menu_params)
			if request.referrer.include?("edit")
				redirect_to weekly_menus_path
				update_eating_order_template
			else
				redirect_to weekly_menu_path(params[:id])
			end
		else
			render :edit
		end
	end

	def show
		@weekly_menu = WeeklyMenu.find(params[:id])
    food_ids                       = get_meals(@weekly_menu.id).pluck(:food_id)
    vendor_food_ids                = Food.where(vendor_menu: true).pluck(:id)
    other_food_ids                 = get_everything_but_meals(@weekly_menu.id).pluck(:food_id).uniq
    
    all_item_ids                   = food_ids + vendor_food_ids + other_food_ids
    all_recipe_ids                 = Recipe.where(food_id: all_item_ids.uniq)
    vendor_recipe_ids              = Recipe.where(food_id: vendor_food_ids)
    @recipe_ingredient_ids         = RecipeIngredient.where(recipe_id: all_recipe_ids).pluck(:ingredient_id).uniq
    @vendor_recipe_ingredient_ids  = RecipeIngredient.where(recipe_id: vendor_recipe_ids).pluck(:ingredient_id).uniq

    @weekend_inventory_ingredients = Ingredient.where(id: @recipe_ingredient_ids).order(:name)
	end

	def destroy
		@weekly_menu = WeeklyMenu.find(params[:id])
		@weekly_menu.destroy
		redirect_to weekly_menus_path
	end

	def create_menu_email_template
		@weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])
		create_eating_order_template
		redirect_to weekly_menus_path, notice: "created"
	end

	def vendor_order_list
		@weekly_menu = WeeklyMenu.find(params[:weekly_menu_id])

		food_ids                       = get_meals(@weekly_menu.id).pluck(:food_id)
    vendor_food_ids                = Food.where(vendor_menu: true).pluck(:id)
    other_food_ids                 = get_everything_but_meals(@weekly_menu.id).pluck(:food_id).uniq

		all_item_ids                   = food_ids + vendor_food_ids + other_food_ids
		all_recipe_ids                 = Recipe.where(food_id: all_item_ids.uniq)
		recipe_ingredient_ids          = RecipeIngredient.where(recipe_id: all_recipe_ids).pluck(:ingredient_id).uniq

		inventory_ingredients          = Ingredient.where(id: @recipe_ingredient_ids).order(:name)
	end

	private

	def weekly_menu_params
		params.require(:weekly_menu).permit(:mon, :tue, :wed, :thu, :fri, :week_start, :week_end, :sample, :labour_target_percentage,
																				food_items_attributes: [:id, :food_id, :weeklFooy_menu_id, :quantity, :eating_order, :vendor_order_quantity]
																				)
	end

	def create_eating_order_template
		meal_items
		add_on_items

		@menu_recommendation_rendered_html = render_to_string("layouts/send_menu_recommendation_template.html.erb", layout: false)
		email_template_record = EmailTemplate.create(html_code: @menu_recommendation_rendered_html, email_type: "eating_order", weekly_menu_id: @weekly_menu.id, subject: "Eating order for #{@weekly_menu.week_start} - #{@weekly_menu.week_end}")
		Klaviyo::CrudTemplate.new(email_template_record).create
		
		Klaviyo::GetEmailList.new(email_template_record).create_list

		create_weekly_menu_template
	end 

	def create_weekly_menu_template
		meal_items
		add_on_items

		@weekly_menu_w_account_rendered_html = render_to_string("layouts/weekly_menu_template.html.erb", layout: false)
		email_template_record = EmailTemplate.create(html_code: @weekly_menu_w_account_rendered_html, email_type: "weekly_menu", weekly_menu_id: @weekly_menu.id)

		Klaviyo::CrudTemplate.new(email_template_record).create
	end

	def update_eating_order_template
		meal_items
		add_on_items

		eating_order_email_template = EmailTemplate.find_by(weekly_menu_id: @weekly_menu.id, email_type: "eating_order")
		@menu_recommendation_rendered_html = render_to_string("layouts/send_menu_recommendation_template.html.erb", layout: false)

		updated_template_record = eating_order_email_template.update_columns(html_code: @menu_recommendation_rendered_html)
		Klaviyo::CrudTemplate.new(eating_order_email_template).update

		Klaviyo::GetEmailList.new(eating_order_email_template).create_list if eating_order_email_template.list_ref_id.nil?

		update_weekly_menu_template
	end

	def update_weekly_menu_template
		meal_items
		add_on_items

		weekly_menu_email_template = EmailTemplate.find_by(weekly_menu_id: @weekly_menu.id, email_type: "weekly_menu")
		@weekly_menu_w_account_rendered_html = render_to_string("layouts/weekly_menu_template.html.erb", layout: false)

		updated_template_record = weekly_menu_email_template.update_columns(html_code: @weekly_menu_w_account_rendered_html)
		Klaviyo::CrudTemplate.new(weekly_menu_email_template).update
	end

	def meal_items
		@meals = @weekly_menu.food_items.where(food_id: Food.where(food_type: "meal"), vendor_only: false)
		.joins("LEFT JOIN foods ON foods.id = food_items.food_id")
		.select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions")
		.order("eating_order" => "ASC")
	end

	def add_on_items
		@others = @weekly_menu.food_items.where.not(food_id: Food.where(food_type: "meal")).where.not(food_id: [89, 93, 92, 139])
		.joins("LEFT JOIN foods ON foods.id = food_items.food_id")
		.select("id", "weekly_menu_id","eating_order", "foods.name", "foods.description", "foods.kcal", "foods.fat", "foods.carbohydrates", "foods.protein", "foods.gluten_wise", "foods.id AS food_id", "foods.allergens", "foods.eating_instructions")
		.order("eating_order" => "ASC")
	end

	def create_vendor_food_items
		vendor_menus = Food.where(vendor_menu: true, food_type: "meal").where.not(id: 293)

		vendor_menus.each do |v|
			if !@weekly_menu.food_items.pluck(:food_id).include?(v.id)
				@weekly_menu.food_items.build(food_id: v.id, vendor_only: true).save
			end
		end
	end
end

