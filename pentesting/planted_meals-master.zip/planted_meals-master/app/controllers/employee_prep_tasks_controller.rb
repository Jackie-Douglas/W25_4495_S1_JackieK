class EmployeePrepTasksController < ApplicationController
  skip_before_action :authenticate_user!, only: [:update]
  before_action :get_weekly_menu_for_admin

  def new
    if is_between_weekly_date(params[:date].to_date)
      meals_with_vendor = Food.where(vendor_menu: true, food_type: "meal")
      employee_prep_tasks = EmployeePrepTask.where(weekly_menu_id: params[:weekly_menu_id], prep_date: weekday_date_range)

      @scheduled_employees = Employee.where(id: employee_prep_tasks.pluck(:employee_id).uniq)
      @find_assigned_employee_prep_tasks = employee_prep_tasks.group_by { |x| x.employee_id }
    else
      meals_with_vendor = Food.where(vendor_menu: true, food_type: "meal") + Food.where(id: get_meals(params[:weekly_menu_id]).pluck(:food_id))
      employee_prep_tasks = EmployeePrepTask.where(weekly_menu_id: params[:weekly_menu_id], prep_date: weekend_date_range)

      @scheduled_employees = Employee.where(id: employee_prep_tasks.pluck(:employee_id).uniq)
      @find_assigned_employee_prep_tasks = employee_prep_tasks.group_by { |x| x.employee_id }
    end

    @meals = meals_with_vendor.uniq
    @other_items = Food.where(id: get_everything_but_meals(params[:weekly_menu_id]).pluck(:food_id)) + @meals
    
    @employee_prep_task = EmployeePrepTask.new
    @employee = Employee.find(params[:employee_id])
  end

  def create
    # prep_task_ids = params[:employee_prep_task][:prep_task_id].map { |x| x.to_i }.reject {|x| x == 0}

    # prep_task_ids.each do |p|
    #   @employee_prep_task = EmployeePrepTask.new(employee_prep_task_params)
    #   @employee_prep_task.prep_task_id = p
    
    #   @employee_prep_task.save
    # end

    # redirect_to prep_tasks_path(date: @employee_prep_task.prep_date, weekly_menu_id: @employee_prep_task.weekly_menu_id)

    @employee_prep_task = EmployeePrepTask.new(employee_prep_task_params)

     prep_date = params.dig('employee_prep_task', 'prep_date')
    
    if @employee_prep_task.save
      respond_to do |format|
        format.html { redirect_to prep_tasks_path(date: @employee_prep_task.prep_date, weekly_menu_id: @employee_prep_task.weekly_menu_id) }
        format.js { @find_assigned_employee_prep_tasks = EmployeePrepTask.where(weekly_menu_id: @employee_prep_task.weekly_menu_id, prep_date: prep_date.to_date).group_by { |x| x.employee_id } }
      end
    end
  end

  def update
    @employee_prep_task = EmployeePrepTask.find(params[:id])

    if @employee_prep_task.update(employee_prep_task_params)
      if request.referer.include?("show_assigned_prep_tasks")
          respond_to do |format|
            format.html { redirect_to show_assigned_prep_tasks_path(employee_id: @employee_prep_task.employee_id) }
            format.js
          end
      elsif request.referer.include?("all_assigned_prep_tasks")
        redirect_to all_assigned_prep_tasks_path
      else
        redirect_to prep_tasks_path(date: @employee_prep_task.prep_date, weekly_menu_id: @employee_prep_task.weekly_menu_id)
      end
    end
  end

  private

  def employee_prep_task_params
    params.require(:employee_prep_task).permit(:prep_start_time, :prep_end_time, :precut_weight, :actual_weight, 
                                               :need_weight, :prep_task_id, :employee_id, :weekly_menu_id, :prep_date, 
                                               :status, :process_start_time, :process_end_time, :is_prioritize, :custom_need_amount, :prioritize_order)
  end
end
  
    