class GiftCard::DebitAmount

    def initialize(opts={})
        @user = opts[:user]
        @debit_amount = opts[:debit_amount].to_f
        @order = opts[:order]
    end

    def call
        gift_cards = @user.gift_cards.order(amount: :DESC)

        gift_cards.each do |x|
            
            left_over = @debit_amount - x.amount.to_f
            x.gift_card_transactions.build(order_ref_id: @order.id, debit_amount: @debit_amount, customer_ref_id: @user.id).save

            if left_over > 0.0
                x.update(amount: 0)
                @debit_amount = left_over

            elsif left_over.negative?
                x.update(amount: left_over.abs)
                @debit_amount = left_over.abs
            else
                x.update(amount: 0)
                @debit_amount = 0
            end

            break if left_over.negative? || left_over == 0.0
        end

    end

end