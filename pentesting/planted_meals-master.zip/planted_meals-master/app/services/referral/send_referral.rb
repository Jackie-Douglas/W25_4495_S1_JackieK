class Referral::SendReferral

    def initialize(opt={})
        @uuid = opt[:uuid]
        @email = opt[:email]
        @current_user = opt[:current_user]
        @weekly_menu_id = opt[:weekly_menu_id]
    end

    def send_email
        ReferralMailer.with(uuid: @uuid, email: @email, current_user: @current_user, weekly_menu_id: @weekly_menu_id).referral_email.deliver_now
        # schedule a reminder (send with, uuid, email, current_user)
        ReferralReminderWorker.perform_in(3.days, @uuid, @email, @current_user.id, @weekly_menu_id)
    end

    def send_sms
        puts ">>>>>>>>>>"
        puts "from send sms"
        puts ">>>>>>>>>>"
    end

end

