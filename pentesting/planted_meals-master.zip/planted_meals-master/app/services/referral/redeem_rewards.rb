class Referral::RedeemRewards

    def initialize(opts={})
        @current_user  = opts[:current_user]
        @credit_amount = opts[:credit_amount]
        @order         = opts[:order]
        @wallet        = @current_user.wallet
    end

    def call
        orignial_amount = @wallet.credit_amount.to_f
        new_amount = orignial_amount - @credit_amount.to_f

        referral_transaction = @wallet.referral_transactions.build(order_ref_id: @order.id, order_subtotal: @order.subtotal, credit_amount: @credit_amount, transaction_type: "reward")
        referral_transaction.save
    end
end