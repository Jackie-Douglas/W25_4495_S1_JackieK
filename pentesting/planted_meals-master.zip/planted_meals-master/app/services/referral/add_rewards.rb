class Referral::AddRewards
   # can sevices do a before action?

    def initialize(opts={})
      @uuid = opts[:uuid]
      @order = opts[:order]
      @referrer_user_id = opts[:user_id]
    end

    def call
      if @order.purchased
        update_or_create_wallet 
        update_redeem_column
      end
    end

    def update_or_create_wallet
      find_referrer

      if @referrer.wallet.nil?
          wallet = @referrer.create_wallet
          referral_transaction = wallet.referral_transactions.build(order_ref_id: @order.id, order_subtotal: @order.subtotal, credit_amount: calculated_reward, transaction_type: "reward")
          referral_transaction.save
      else
         wallet = @referrer.wallet
         referral_transaction = wallet.referral_transactions.build(order_ref_id: @order.id, order_subtotal: @order.subtotal, credit_amount: calculated_reward, transaction_type: "reward")
         referral_transaction.save
      end
    end

    def find_referrer
      if @uuid
        @referrer = Referral.find_by(uuid: @uuid).user
      else
        @referrer = User.find(@referrer_user_id)
      end
    end


    def calculated_reward
      reward = (@order.subtotal * 0.05).to_f.round(2)
    end

    def update_redeem_column
      begin
        Referral.find_by(uuid: @uuid).update_columns(redeemed: true)  
      rescue
        nil
      end
    end


    #### Things that are done ######
    # 1. Send emails to a person you would like to refer
    # 2. a referred customer can click the link from the email and purchase planted meals, 
    # once meal is purhcased credit will be applied to the account
    # 3. At any purchase it will check if that account was referred by anyone and if it is referred,
    # it will also apply credit to corresponding accont

    #### Things that are left todo #####
    # 1. able to send link via SMS
    # 2. show credit amount inside the dashboard
    # 3. able to use the credit to purchase a product

  


    



    


end