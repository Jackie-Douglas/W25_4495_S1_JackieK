class Klaviyo::CrudTemplate < Klaviyo::KlaviyoBase

	def initialize(email_template_record)
		super
		@email_template_record = email_template_record
		@temp_ref_id = @email_template_record.temp_ref_id
		@week_start_date = @email_template_record.weekly_menu.week_start.strftime("%b %d")
		@week_end_date = @email_template_record.weekly_menu.week_end.strftime("%b %d")
	end

	def create
		response = send_request({ url: "https://a.klaviyo.com/api/templates/", body: create_body_data, method: "Net::HTTP::Post" })

		@email_template_record.update_columns(temp_ref_id: parse_json(response).dig("data", "id"))
	end

	def update
		response = send_request({ url: "https://a.klaviyo.com/api/templates/#{@temp_ref_id}/", body: update_body_data, method: "Net::HTTP::Patch" })
	end

	def destroy
		response = send_request({ url: "https://a.klaviyo.com/api/templates/#{@temp_ref_id}/", method: "Net::HTTP::Delete" })
	end

	def create_body_data
		{
			data: {
				type: "template",
				attributes: {
					name: "#{@email_template_record.email_type}, #{@week_start_date} - #{@week_end_date}",
					editor_type: "CODE",
					html: @email_template_record.html_code,
					text: ""
				}
			}
		}
	end

	def update_body_data
		{
			data: {
				type: "template",
				id: @temp_ref_id,
				attributes: {
					name: "#{@email_template_record.email_type}, #{@week_start_date} - #{@week_end_date}",
					html: @email_template_record.html_code,
					text: ""
				}
			}
		}
	end
end 

