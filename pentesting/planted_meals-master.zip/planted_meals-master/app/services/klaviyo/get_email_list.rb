class Klaviyo::GetEmailList < Klaviyo::KlaviyoBase
    
	def initialize(email_template)
		super
		@email_template = email_template
	end

	def create_list
		response = send_request({ url: "https://a.klaviyo.com/api/lists/", body: create_list_body_data, method: "Net::HTTP::Post" })
		
		@email_template.update_columns(list_ref_id: parse_json(response).dig("data", "id"))
	end

	def create_email_lists
		list_id = @email_template.list_ref_id
		email_list_data = list_create_data(list_id, profile_list)

		response = send_request({ url: "https://a.klaviyo.com/api/profile-bulk-import-jobs/", body: email_list_data, method: "Net::HTTP::Post" })
	end

	def profile_list
		record = []
		
		customer_ids = WeeklyMenu.find(@email_template.weekly_menu_id).orders.where(purchased: true).pluck(:customer_id)
		customer_email = Customer.find(customer_ids).pluck(:email).compact.reject { |c| c.empty? }

		customer_email.each do |x|
				record << { type: "profile", attributes: { email: x } }
		end

		return record	
	end

	def create_records
		if @result.length > current_record_count
			@result.each do |record|
				email = record["email"]
				next if NewsletterEmail.find_by(email: email) != nil
				NewsletterEmail.create(ref_id: record["id"], email: email)
			end
		end
	end

	private

	def current_record_count
		NewsletterEmail.count
	end

	def list_create_data(list_id, profile_list)
		{
			data: {
				type: "profile-bulk-import-job",
				attributes: {
					profiles: {
						data: profile_list
					}
				},
				relationships: {
					lists: {
						data: [
							{
								type: "list",
								id: list_id
							}
						]
					}
				}
			}
		}
	end

	def create_list_body_data
		{
			data: {
				type: "list",
				attributes: {
					name: @email_template.subject
				}
			}
		}

	end

end