class Klaviyo::SendEatingOrderCampaign < Klaviyo::KlaviyoBase

	def initialize(email_campaign)
		super
		@email_campaign = email_campaign
		Klaviyo::GetEmailList.new(email_campaign).create_email_lists
	end

	def send_campaign
		ActiveRecord::Base.transaction do
			response = send_request({ url: "https://a.klaviyo.com/api/campaigns/", body: create_campaign_payload, method: "Net::HTTP::Post" })

			@message_id = parse_json(response).dig('data', 'relationships', 'campaign-messages', 'data')[0]["id"]

			response = send_request({ url: "https://a.klaviyo.com/api/campaign-message-assign-template/", body: assign_template_payload, method: "Net::HTTP::Post" })

			@campaign_id = parse_json(response).dig('data', 'relationships', 'campaign', 'data', 'id')

			response = send_request({ url: "https://a.klaviyo.com/api/campaign-send-jobs/", body: send_job_payload, method: "Net::HTTP::Post" })
									
			@email_campaign.update_columns(sent: true) if response.code == "202"
		end
	end

	def create_campaign_payload
		{
			"data": {
				"type": "campaign",
				"attributes": {
					"name": "My new campaign",
					"audiences": {
						"included": [
							@email_campaign.list_ref_id
						]
					},
					"send_strategy": {
						"method": "immediate"
					},
					"send_options": {
						"use_smart_sending": false
					},
					"tracking_options": {
						"is_add_utm": false
					},
					"campaign-messages": {
						"data": [
							{
								"type": "campaign-message",
								"attributes": {
									"channel": "email",
									"label": @email_campaign.subject,
									"content": {
										"subject": @email_campaign.subject,
										"from_email": "team@plantedmeals.ca",
										"from_label": "Planted Meals"
									}
								}
							}
						]
					}
				}
			}
		}
	end

	def assign_template_payload
		{
			data: {
				type: "campaign-message",
				id: @message_id,
				relationships: {
					template: {
						data: {
							type: "template",
							id: @email_campaign.temp_ref_id
						}
					}
				}
			}
		}
	end

	def send_job_payload
		{
			data: {
				type: "campaign-send-job",
				id: @campaign_id
			}
		}
	end
end

