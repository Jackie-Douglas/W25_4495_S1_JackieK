class Klaviyo::KlaviyoBase
    require 'resolv-replace'
    include HTTParty
    require 'uri'
    require 'net/http'

    def initialize(arg=nil)
        @api_key = Rails.application.credentials[:klaviyo]["#{Rails.env}_secret_key".to_sym]        
    end

    def send_request(arg=nil)
        url = URI(arg[:url])
        http = Net::HTTP.new(url.host, url.port)
        http.use_ssl = true
        http.open_timeout = 30

        request = arg[:method].constantize.new(url)
        request["accept"] = 'application/json'
        request["revision"] = '2024-07-15'
        request["content-type"] = 'application/json'
        request["Authorization"] = "Klaviyo-API-Key #{@api_key}"
        request.body = arg[:body].to_json unless arg[:method].include?("Delete")

        response = http.request(request)
    end

    def parse_json(response)
        JSON.parse(response.read_body)
    end

end