class Klaviyo::SendEvent < Klaviyo::KlaviyoBase

	def initialize(order)
		super
		@order = order
		@customer = order.customer
	end

  def successful_purchase
		response = send_request({ url: "https://a.klaviyo.com/api/events/", body: successful_purchase_event_data, method: "Net::HTTP::Post" })
	end

	def successful_purchase_event_data
		{
				data: {
						type: "event",
						attributes: {
								properties: {
										order_id: @order.id,
										value: @order.charged_amount.to_i / 100.00,
										discount_code: CouponUsage.find_by(order_ref_id: @order.id) == nil ? "N/A" : CouponUsage.find_by(order_ref_id: @order.id).coupon.coupon_code
								},
								time: date_time_with_time_zone,
								value: @order.charged_amount.to_i / 100.00,
								value_currency: "CAD",
								metric: {
										data: {
												type: "metric",
												attributes: {
														name: "successful purchase"
												}
										}
								},
								profile: {
										data: {
												type: "profile",
												attributes: {
														email: @customer.email,
														phone_number: "+1#{@customer.phone}",
														first_name: @customer.first_name,
														last_name: @customer.last_name,
														location: {
																address1: @customer.shipping_address,
																address2: @customer.unit,
																city: @customer.shipping_city,
																country: "canada",
																region: "BC",
																zip: @customer.shipping_postal_code
														}
		
												}
										}
								}            
						}
				}
			}
	end

  private

	def date_time_with_time_zone
		Time.zone = "Pacific Time (US & Canada)"
		Time.zone.now
	end
end