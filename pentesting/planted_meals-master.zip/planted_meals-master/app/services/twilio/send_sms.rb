require 'twilio-ruby'

class Twilio::SendSms

  def initialize(message)
    @message = message
    account_sid = Rails.application.credentials.ACCOUNT_SID
    auth_token = Rails.application.credentials.AUTH_TOKEN
    
    # set up a client to talk to the Twilio REST API
    @twilio = Twilio::REST::Client.new account_sid, auth_token
    # @clients = Customer.where(on_subscription: false)
  end

  def send_sms
    # @clients.each do |c|
    #   message = @twilio.messages.create(
    #                            body: reminder_text(c.first_name.titleize),
    #                            from: '+16042393698',
    #                            to: "+1#{c.phone}"
    #                          )

    # end

    message = @twilio.messages.create(
                               body: reminder_text,
                               from: '+16042393698',
                               to: "+16043693456"
                             )


  end

  def reminder_text
    <<-HEREDOC.strip_heredoc
      #{@message}
    HEREDOC
  end

end
