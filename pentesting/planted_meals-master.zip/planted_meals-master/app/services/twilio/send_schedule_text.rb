require 'twilio-ruby'

class Twilio::SendScheduleText

  def initialize(employee_id, root_url, week_start, week_end)
    @week_start = week_start
    @week_end   = week_end
    @employee = Employee.find(employee_id)
    @url = root_url + "work_schedules/#{@employee.uuid}?date=#{@week_start}"
    
    account_sid = Rails.application.credentials.ACCOUNT_SID
    auth_token = Rails.application.credentials.AUTH_TOKEN
    
    # set up a client to talk to the Twilio REST API
    @twilio = Twilio::REST::Client.new account_sid, auth_token
    # @clients = Customer.where(on_subscription: false)
  end

  def send_sms
    message = @twilio.messages.create(
                               body: text,
                               from: '+16042393698',
                               to: "+1#{@employee.customer.phone}"
                             )
  end

  def text
    <<-HEREDOC.strip_heredoc
      Hello Planter =)!
      Here is your schedule for #{@week_start} - #{@week_end}
      Please click the link below to review your schedule.
      #{@url}

      End time could change, Thanks!
    HEREDOC
  end

end
