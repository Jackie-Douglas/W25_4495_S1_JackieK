class Stripe::CreateStripeCustomer

    def initialize(current_user, order_info, token, root_url)
        @user = current_user
        @order_info = order_info
        @token = token

        Stripe.api_key = (Rails.env == "production" ? (root_url.include?("plantedmeals.io") ? "sk_test_Cho5zcx8EroV74ApGoBwkbuo" : Rails.application.credentials.stripe_secret_key) : "sk_test_Cho5zcx8EroV74ApGoBwkbuo")
    end

    def call
        email = @user.customer.email

        customer_from_stripe = Stripe::Customer.create({
                email: email,
                source: @token
            })
        @stripe_info = StripeInfo.create(
                credit_card_type: customer_from_stripe.sources.data[0].brand,
                last_4: customer_from_stripe.sources.data[0].last4,
                default_source:  customer_from_stripe.default_source,
                stripe_customer_id: customer_from_stripe.id,
                customer_id: @user.customer.id
        )
    end

end
