# class Stripe::Webhook < ApplicationController
#   # before_action :authenticate_user!
#
#   def webhook
#     render json: {
#     message: "from webhook",
#     status: 200
#   }.to_json
#   end
#
# end
