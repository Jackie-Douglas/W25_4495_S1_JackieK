class Stripe::ChargeCustomer

    def initialize(current_user, amount, order_info, coupon=nil, klaviyo=nil, credit_amount=nil, token=nil, gift_card_amount, root_url)
        @user = current_user
        @amount = amount
        @order_info = order_info
        @coupon = coupon
        @klaviyo = klaviyo
        @token = token
        @credit_amount = credit_amount
        @gift_card_amount = gift_card_amount

        Stripe.api_key = (Rails.env == "production" ? (root_url.include?("plantedmeals.io") ? "sk_test_Cho5zcx8EroV74ApGoBwkbuo" : Rails.application.credentials.stripe_secret_key) : "sk_test_Cho5zcx8EroV74ApGoBwkbuo")

        puts ">>>>>>>>>>stripe api key  from initialize>>>>>>>>>>>>>>>>"
        puts Stripe.api_key
        puts ">>>>>>>>>>>>>>>>>>>>>>>>>>"
        # Stripe.api_key = "sk_test_Cho5zcx8EroV74ApGoBwkbuo" 
    end

    def call
        begin
            source = @user.customer.stripe_info.default_source
            customer_id = @user.customer.stripe_info.stripe_customer_id
            charge = Stripe::Charge.create({
                    amount: @amount,
                    currency: 'cad',
                    description: charge_description,
                    source: source,
                    customer: customer_id
                })
                
            update_purchased_column_if_charge_status_is_successful(charge)
            return nil
        rescue Stripe::CardError => e
            return e
        rescue Stripe::InvalidRequestError => e
            return e
        end

    end

    def charge_gift_card
        begin
            customer_from_stripe = Stripe::Customer.create({
                    email: @user,
                    source: @token
                })
    
            gift_card_charge_description = "Planted Meals Gift Card: $#{@amount}"
    
    
            charge = Stripe::Charge.create({
                    amount: (@amount.to_f * 100).to_i,
                    currency: 'cad',
                    description: gift_card_charge_description,
                    source: customer_from_stripe.default_source,
                    customer: customer_from_stripe.id
                })

            return nil
        rescue Stripe::CardError => e
            return e
        rescue Stripe::InvalidRequestError => e
            return e
        end

    end


    def update_card_information
        customer_id = @user.customer.stripe_info.stripe_customer_id
        customer = @user.customer

        begin
            if customer_id.blank?
                customer_from_stripe = Stripe::Customer.create({
                    email: customer.email,
                    source: @token
                })
                customer.stripe_info.update_columns(
                    stripe_customer_id: customer_from_stripe.id,
                    credit_card_type: customer_from_stripe.sources.data[0].brand,
                    last_4: customer_from_stripe.sources.data[0].last4,
                    default_source: customer_from_stripe.default_source,
                )
            else
                updated_customer = Stripe::Customer.update(customer_id, {source: @token})
                customer.stripe_info.update_columns(
                    credit_card_type: updated_customer.sources.data[0].brand,
                    last_4: updated_customer.sources.data[0].last4,
                    default_source:  updated_customer.default_source,
                )
            end

            return nil
        rescue Stripe::CardError => e
            return e
        rescue Stripe::InvalidRequestError => e
            return e
        end
            


        # return order_id[:order_id] if order_id

        # if the person is on a sub, there will be no card attached
        # find the customer with email from stripe, and update the credit card info
        # customer_id = @user.customer.stripe_info.stripe_customer_id
        # customer = @user.customer

        # begin
        #     updated_customer = Stripe::Customer.update(customer_id, {source: @token})
        #     customer.stripe_info.update_columns(
        #         credit_card_type: updated_customer.sources.data[0].brand,
        #         last_4: updated_customer.sources.data[0].last4,
        #         default_source:  updated_customer.default_source,
        #     )
        # rescue
        #     customer_from_stripe = Stripe::Customer.create({
        #         email: customer.email,
        #         source: @token
        #     })
        #     customer.stripe_info.update_columns(
        #         credit_card_type: customer_from_stripe.sources.data[0].brand,
        #         last_4: customer_from_stripe.sources.data[0].last4,
        #         default_source:  customer_from_stripe.default_source,
        #     )
        # end
        
    end


    def update_purchased_column_if_charge_status_is_successful(charge)
        charge_status = charge.status
        charge_amount = charge.amount
        
        if charge_status.downcase == "succeeded"
            @order_info.update_columns(purchased: true, charged_amount: charge_amount) 
            CouponUsage.find_by(customer_id: @user.customer.id, coupon_id: @coupon.id).update_columns(purchased: true, order_ref_id: @order_info.id) if !@coupon.nil?    
            update_coupon_number_available_count if !@coupon.nil?
            PurchasedNotificationMailer.with(customer_info: @user.customer, order_info: @order_info).notification_email.deliver_now
            KlaviyoSendEventWorker.perform_async(@order_info.id) if Rails.env == "production"
            SendWeeklyFoodReviewWorker.perform_in(perform_in_day(@order_info).days, @order_info.id)
            # update or create bag that when out to the customer
            BagTracking::UpdateCounter.new(@order_info).call
            Referral::RedeemRewards.new({order: @order_info, current_user: @user, credit_amount: @credit_amount}).call if @credit_amount
            Referral::AddRewards.new({order: @order_info, uuid: nil, user_id: referral_exist[:user_id]}).call if referral_exist[:condition]
            GiftCard::DebitAmount.new(user: @user, debit_amount: @gift_card_amount, order: @order_info).call if @gift_card_amount != 0.0
        end
    end

    def referral_exist
        # find if the order was ever referrals by someone, this should be called if referral is found
            # get an email of a person that ordered
            # find referral with the email
            # get user of the referral

        email = @user.customer.email
        was_it_a_referral = Referral.find_by(email: email)

        if was_it_a_referral

            @referral_hash = {
                                condition: true,
                                user_id: was_it_a_referral.user.id
                             }
        else
            @referral_hash = {
                                condition: false,
                                user_id: nil
                             }
        end

    end


    def charge_description
        snacks = @order_info.line_items.includes(:food).where('foods.food_type = ?', 'snack', ).references(:food).map do |x|
                    "#{x.name} X #{x.quantity}\n"
                 end

        "Single Planted Meals X #{meal_count}\n
        #{snacks.join("\n")}
        Delivery Fee: $#{delivery_charge}\n
        Tax (5%)"
    end

    def delivery_charge
        @order_info.subtotal > 80 ? 0 : @user.customer.delivery.fee
    end

    def meal_count
        @order_info.total_meal_count
    end

    def update_coupon_number_available_count
        previous_count = @coupon.numbers_available
        new_count = previous_count - 1
        @coupon.update_columns(numbers_available: new_count)
    end

    def perform_in_day(order)
        Time.zone = "Pacific Time (US & Canada)"

		today = Time.zone.today
		((order.weekly_menu.week_end - 1.day) - today).to_i
	end
end