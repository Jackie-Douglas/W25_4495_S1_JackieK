class BagTracking::UpdateCounter

    def initialize(order)
        @order = order
        @customer_id = @order.customer_id
    end

    def call
        customer = find_customer
        bag_tracker = find_customer.bag_tracker
        
        if bag_tracker.nil?
            BagTracker.create(counter: 1, customer_id: @customer_id)
        else
            previous_count = bag_tracker.counter
            new_count = previous_count + 1
            bag_tracker.update_columns(counter: new_count)
        end

    end

    def find_customer
        Customer.find(@order.customer_id)
    end

end
