class Delivery::ImportFromCigo
  include HTTParty

	def initialize(weekly_menu_id)
		@weekly_menu = WeeklyMenu.find(weekly_menu_id)
		@sunday_delivery_date = (@weekly_menu.week_start - 1).to_s
		@monday_deliery_data = @weekly_menu.week_start.to_s
		@auth = { username: Rails.application.credentials[:cigo][:account_id], password: Rails.application.credentials[:cigo][:auth_key] }
	end

	def call
		[@sunday_delivery_date, @monday_deliery_data].each do |x|
			assign_drivers(x)
		end
	end

    def assign_drivers(date)
			json_response = get_itineraries_request(date)

			if json_response["itineraries"].empty?
				new_date = (date.to_date + 1.day).to_s
				json_response = get_itineraries_request(new_date)
			else
				json_response = get_itineraries_request(date)
			end

			parsed_json = JSON.parse(json_response.body)
			data_mapper(parsed_json)
    end

    def get_itineraries_request(date)
      HTTParty.get("https://cigotracker.com/api/v1/itineraries/date/#{date}", basic_auth: @auth)
    end

    def get_job_request(job_id)
      HTTParty.get("https://cigotracker.com/api/v1/jobs/id/#{job_id}", basic_auth: @auth)
    end

    def find_customer(email, first_name, last_name)
			if email.blank?
				Customer.find_by("first_name ILIKE ? AND last_name ILIKE ?", "%#{first_name}%", "%#{last_name}%")
			else
				Customer.find_by(email: email)
			end
    end

    def find_customer_and_update_delivery_information(customer_id, employee_id, position)
			begin
				@weekly_menu.orders.find_by(customer_id: customer_id, purchased: true).update_columns(employee_id: employee_id, position: position)
			rescue;end
    end

    def find_vendor_and_update_delivery_information(vendor_id, employee_id, position)
			begin
				vendor_cook_date = @weekly_menu.week_start - 1.day
				vendor_orders = TempOrder.where(cook_on: vendor_cook_date)

				vendor_orders.find_by(vendor_id: vendor_id).update_columns(employee_id: employee_id, position: position)
			rescue;end
    end


    def data_mapper(json_blob)
			json_blob.dig("itineraries").each do |x|
				employee_id = x.dig("operators")[0].dig("reference_id").to_i

				x.dig("stops").each do |j|
					begin
						parsed_json = JSON.parse(get_job_request(j.dig("job_id")).body)
						parsed_customer_id = parsed_json.dig("job", "invoices").first
						customer_id = parsed_customer_id.to_i
						position = j.dig("position")

						if parsed_customer_id.include?("vendor")
								vendor_id = parsed_customer_id.split(" ").last.to_i
								find_vendor_and_update_delivery_information(vendor_id, employee_id, position)
						else
								find_customer_and_update_delivery_information(customer_id, employee_id, position)
						end
					rescue;end
					end
			end
    end
end


# ** make this a background job! ** ##

# operator reference_id(from cigo) == employee_id
# use date to find out Sunday or Monday delivery(date format "2019-04-29")
# fetch from itinerary basic auth
    # url https://cigotracker.com/api/v1/itineraries/date/{date}
# Loop through driver
    # Retrive a job from job_id(use email to find customers order)
    # get weekly menu_id
    # find the order with the email address that is given
    # save the driver reference_id to the order
