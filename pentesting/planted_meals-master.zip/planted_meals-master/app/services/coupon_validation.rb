class CouponValidation
    include Rails.application.routes.url_helpers
    
    def initialize(opt={})
        @coupon_code = opt[:coupon_code]
        @order = Order.find(opt[:order_id])
        @customer = Customer.find(@order.customer_id)
    end

    def call
        if find_coupon
            validate_coupon_and_update_if_valid
        else
            return false
        end
    end

    def find_coupon
        Coupon.find_by(coupon_code: @coupon_code.downcase)
    end

    def find_special_coupons
        Coupon.where(special: true)
    end

    def coupon_not_used
        CouponUsage.where(customer_id: @order.customer_id, purchased: true).where.not(coupon_id: find_special_coupons.ids).blank?
    end

    def coupon_available
        find_coupon.numbers_available > 0
    end

    def special_coupon_not_used
        !CouponUsage.find_by(customer_id: @order.customer_id, purchased: true, coupon_id: find_coupon.id)
    end

    def special_coupon
        find_coupon.special
    end
    
    def validate_coupon_and_update_if_valid
                        
        if (coupon_not_used && coupon_available) || (special_coupon && coupon_available && special_coupon_not_used)
            @customer.coupons << find_coupon
            return true
        else
            return false
        end
            
    end

        
end