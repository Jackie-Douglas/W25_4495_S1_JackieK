class Calculation::Subtotal

	def initialize(order)
		@order = order
	end

	def get_subtotal
		# total_meal_subtotal    = @order.total_meal_count * 9.50
		# single_cookie_subtotal = zero_if_nil_or_blank(@order.single_cookie) * 2.10 
		# bundle_cookie_subtotal = zero_if_nil_or_blank(@order.bundle_cookie) * 11.50
		# ricotta_subtotal       = zero_if_nil_or_blank(@order.ricotta) * 9.95
		# brownie_subtotal       = zero_if_nil_or_blank(@order.brownie) * 3.45
		# cookie_dough_subtotal  = zero_if_nil_or_blank(@order.cookie_dough) * 14.99

		# subtotal = total_meal_subtotal + single_cookie_subtotal + bundle_cookie_subtotal + ricotta_subtotal + brownie_subtotal + cookie_dough_subtotal

		subtotal = calculate_quantity_and_price
	end

	def get_subtotal_new
		# @delivery_fee = @order.vendor_delivery_fee.blank? ? 0 : @order.vendor_delivery_fee
		# @order.line_items.sum(:price)

		# calculate_quantity_and_price + @delivery_fee
		calculate_quantity_and_price
	end

	def calculate_quantity_and_price
		@order.line_items.inject(0) do |result, element|
			add_ons = element.quantity * element.add_on_price if element.double_protein
			add_ons = add_ons.nil? ? 0 : add_ons
			result + ((element.quantity * element.price) + (add_ons))
		end
	end

	def zero_if_nil_or_blank(quantity)
		if quantity.nil? || quantity.blank?
			0
		else
			quantity
		end
	end

end