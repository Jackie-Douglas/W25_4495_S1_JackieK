class Calculation::GrandTotal
    include ProductsHelper

    def initialize(arg={})
        @order = arg[:order]
        @coupon_id = arg[:coupon_id]
        @credit_amount = arg[:credit_amount]
        @gift_card_credit_amount = arg[:gift_card_credit_amount]        
    end

    def get_subtotal
        subtotal = @order.subtotal
        discounted_amount_from_coupon = @coupon_id == nil ? 0.0 : discount_amount(@coupon_id, @order)
        referral_credit_amount = @credit_amount == nil ? 0.0 : @credit_amount.to_f

        calculated_subtotal = (subtotal + delivery_fee) - (discounted_amount_from_coupon + referral_credit_amount)
    end

    def get_grand_total
        subtotal = get_subtotal

        
        # gift_card_credit_amount = @gift_card_credit_amount == nil ? 0.0 : @gift_card_credit_amount.to_f


        # if @coupon_id
        #     calculated_subtotal = delivery_fee + discounted_price(@coupon_id, @order)
        # elsif @credit_amount
        #     calculated_subtotal = delivery_fee + (@order.subtotal - @credit_amount.to_f)
        # else
        #     calculated_subtotal = delivery_fee + @order.subtotal
        # end


        gst =  calculate_gst(subtotal)
        grand_total = subtotal + gst
        grand_total.to_f.round(2)
    end

    def get_gst_amount
        calculate_gst(get_subtotal)
    end

    def get_discount_amount
        discount_amount(@coupon_id, @order)
    end

    def get_discounted_price
        if @coupon_id
            discounted_price(@coupon_id, @order)
        else
             @order.subtotal - @credit_amount.to_f
        end
    end

    def delivery_charge
        delivery_fee
    end

    private 

    def delivery_fee
        @order.subtotal > 80 ? 0 : @order.customer.delivery.fee
    end

    def calculate_gst(subtotal)
        subtotal * 0.05
    end
    
    def get_discounted_price_with_credit

    end


end